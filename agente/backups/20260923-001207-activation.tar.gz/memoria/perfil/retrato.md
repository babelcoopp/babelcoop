---
id: retrato
type: profile
title: Retrato do Marcelo (compilado)
tags: [perfil, marcelo]
source: inference
generated: "2026-09-23T00:12:07-03:00"
---
# Retrato do Marcelo — compilado de 1 memórias (atualizado 23/09)

## Quem ele é
Marcelo Rocha (Maximus), fundador do Reino (network + IA Babel); lidera grandes grupos; não-dev; quer tudo pronto, em português, estilo WhatsApp; Diego é sócio…

## Como gosta de trabalhar
- (nenhuma preferência registrada ainda)

## Aprendi hoje
- nada ainda hoje

## Ainda quero aprender
1. Em que horário você prefere trabalhar comigo?
2. Por qual canal você prefere falar comigo (terminal, VS Code, celular)?
3. Qual meta do trimestre pesa mais para você agora?
