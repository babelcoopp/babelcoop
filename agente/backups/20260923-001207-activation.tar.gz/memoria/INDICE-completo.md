<!-- gerado por motor/refine.py em 2026-09-23T00:12:07-03:00 — não edite; use /lembrar, /esquecer e /evoluir -->
# Índice vivo do Gabriel — v0.1.1 · geração 1 · 2 memórias ativas · 0 projetos · 0 pendências

## Marcelo (retrato)

### Quem ele é
Marcelo Rocha (Maximus), fundador do Reino (network + IA Babel); lidera grandes grupos; não-dev; quer tudo pronto, em português, estilo WhatsApp; Diego é sócio…

### Como gosta de trabalhar
- (nenhuma preferência registrada ainda)

### Aprendi hoje
- nada ainda hoje

### Ainda quero aprender
1. Em que horário você prefere trabalhar comigo?
2. Por qual canal você prefere falar comigo (terminal, VS Code, celular)?
3. Qual meta do trimestre pesa mais para você agora?

## Projetos

## Decisões

## Memórias ativas
### fato (1)
- 23/09 [fato 0.8] O que é o babel-os (organismo vivo 'Gabriel'), primeira ativação em 22/09/2026 com ultrac… — auto-memory, babel, projeto (2026-09-23-projeto-babel-os)
### referência (1)
- 23/09 [referência 0.8] Onde estão as fontes do Reino (base de conhecimento, LP publicada, app, canal WhatsApp, d… — auto-memory, referencias, reino (2026-09-23-reino-referencias)

## Conhecimento (11)
- claude-code/changelog-e-boas-praticas — Claude Code 2.1.280 — changelog e boas práticas (changelog-e-boas-praticas) · 2026-09-22
- claude-code/diretorio-e-memoria — Claude Code 2.1.280 — diretório e memória (diretorio-e-memoria) · 2026-09-22
- claude-code/hooks — Claude Code 2.1.280 — hooks (ganchos) (hooks) · 2026-09-22
- claude-code/plugins-mcp — Claude Code 2.1.280 — plugins e MCP (plugins-mcp) · 2026-09-22
- claude-code/riscos-e-lacunas — Claude Code 2.1.280 — riscos e lacunas (riscos-e-lacunas) · 2026-09-22
- claude-code/settings — Claude Code 2.1.280 — settings (configurações) (settings) · 2026-09-22
- claude-code/skills-e-comandos — Claude Code 2.1.280 — skills e comandos (skills-e-comandos) · 2026-09-22
- claude-code/statusline-e-terminal — Claude Code 2.1.280 — status line e terminal (statusline-e-terminal) · 2026-09-22
- claude-code/subagentes — Claude Code 2.1.280 — subagentes (subagentes) · 2026-09-22
- claude-code/vscode-sessoes-checkpoints — Claude Code 2.1.280 — VS Code, sessões e checkpoints (vscode-sessoes-checkpoints) · 2026-09-22
- claude-code/workflows-e-automacao — Claude Code 2.1.280 — workflows e automação (workflows-e-automacao) · 2026-09-22

## Compactações

## Relatórios

## Superadas e arquivadas

## Pendências e agenda (abertas: 0 · vencidas: 0)
