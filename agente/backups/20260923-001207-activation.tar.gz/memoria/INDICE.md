<!-- gerado por motor/refine.py em 2026-09-23T00:12:07-03:00 — não edite; use /lembrar, /esquecer e /evoluir -->
# Índice vivo do Gabriel — v0.1.1 · geração 1 · 2 memórias ativas · 0 projetos · 0 pendências

## Marcelo (retrato · atualizado 23/09)
Marcelo Rocha (Maximus), fundador do Reino (network + IA Babel); lidera grandes grupos; não-dev; quer tudo pronto, em português, estilo WhatsApp; Diego é sócio… Detalhes: memoria/perfil/marcelo.md

## Projetos abertos
- (nenhum projeto aberto)

## Decisões que valem (fixadas + 5 últimas)

## Memórias fixadas
- [conhecimento] Claude Code 2.1.280 — riscos e lacunas (riscos-e-lacunas) — memoria/conhecimento/claude-code/riscos-e-lacunas.md
- [referência] Pedido original do Marcelo (CLAUDE.md de nascimento do Gabriel) (pedido-original) — memoria/origem/pedido-original.md

## Memórias recentes (2)
- 23/09 [fato 0.8] O que é o babel-os (organismo vivo 'Gabriel'), primeira ativação em 22/09/2026 com ultrac… — auto-memory, babel, projeto (2026-09-23-projeto-babel-os)
- 23/09 [referência 0.8] Onde estão as fontes do Reino (base de conhecimento, LP publicada, app, canal WhatsApp, d… — auto-memory, referencias, reino (2026-09-23-reino-referencias)

## Conhecimento (10) — detalhes em memoria/conhecimento/
- [conhecimento] claude-code/changelog-e-boas-praticas — Claude Code 2.1.280 — changelog e boas práticas (changelog-e-boas-praticas)
- [conhecimento] claude-code/diretorio-e-memoria — Claude Code 2.1.280 — diretório e memória (diretorio-e-memoria)
- [conhecimento] claude-code/hooks — Claude Code 2.1.280 — hooks (ganchos) (hooks)
- [conhecimento] claude-code/plugins-mcp — Claude Code 2.1.280 — plugins e MCP (plugins-mcp)
- [conhecimento] claude-code/settings — Claude Code 2.1.280 — settings (configurações) (settings)
- [conhecimento] claude-code/skills-e-comandos — Claude Code 2.1.280 — skills e comandos (skills-e-comandos)
- [conhecimento] claude-code/statusline-e-terminal — Claude Code 2.1.280 — status line e terminal (statusline-e-terminal)
- [conhecimento] claude-code/subagentes — Claude Code 2.1.280 — subagentes (subagentes)
- [conhecimento] claude-code/vscode-sessoes-checkpoints — Claude Code 2.1.280 — VS Code, sessões e checkpoints (vscode-sessoes-checkpoints)
- [conhecimento] claude-code/workflows-e-automacao — Claude Code 2.1.280 — workflows e automação (workflows-e-automacao)

## Pendências e agenda (abertas: 0 · vencidas: 0)

_+ 0 memórias fora deste índice (confiança < 0.4 ou superadas) — `/consultar <tema>` acha tudo._
