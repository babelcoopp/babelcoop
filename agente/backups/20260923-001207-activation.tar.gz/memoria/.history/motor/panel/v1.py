#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
panel.py — gera dashboard/data.js e dashboard/index.html (spec §11.13, objeto BABEL §3.9).

generate() -> bool. CLI sem argumentos. Nunca escreve corpo de memória, prompt inteiro,
conteúdo de arquivo, transcript_path nem segredo (tudo passa por common.redact()).
"""
import os, sys, json, time, collections, datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

SCRIPT = "panel.py"
P = common.P
MARKER = "/*__BABEL_DADOS__*/"
TIPS = [
    "O índice fixo (CLAUDE.md + INDICE.md) só recarrega em /clear, /compact ou ao reiniciar.",
    "Registre o que aprendeu com /lembrar; o painel e o índice mudam no mesmo instante.",
    "/consultar <tema> acha tudo, inclusive o que não coube no índice.",
    "Um arquivo PAUSA na raiz desliga os ganchos e a status line (/pausar).",
]
WARNING_TEXT = {
    "conhecimento_antigo": ("atencao", "O que sei de configuração do Claude Code já envelheceu: /pesquisar claude code atualiza."),
    "cache_regenerado": ("atencao", "Um cache de memoria/.cache/ estava ilegível e foi regenerado."),
    "config_corrompido": ("erro", "memoria/config.json estava corrompido: recriado com os padrões (cópia .corrupt-<ts>)."),
    "template_ausente": ("atencao", "dashboard/template.html sumiu: este painel usa o modelo mínimo embutido."),
    "indice_grande": ("atencao", "INDICE.md passou de 120 linhas: fixe menos, arquive mais."),
    "log_grande": ("atencao", "memoria/log/ passou de 15 MB: a manutenção vai rotacionar."),
    "iterm_cc_status": ("atencao", "Integração cc-status do iTerm2 quebrada (veja LEIA-ME)."),
    "pausa": ("atencao", "Organismo em pausa (arquivo PAUSA na raiz)."),
    "settings_invalido": ("erro", ".claude/settings.json inválido: os ganchos podem não rodar."),
    "minor_pending": ("atencao", "Bump de versão minor pendente: a manutenção conclui."),
    "refino_parcial": ("atencao", "O último refino estourou o tempo; a manutenção completa o resto."),
}
MINIMAL_TEMPLATE = u"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gabriel · Babel OS</title>
<style>
:root{--cyan:#3fe3ff;--blue:#3b82ff;--violet:#8b5cff;--magenta:#e04bff;--gold:#f5c76a;--green:#34e6a6;--text:#e6efff;--muted:#9fb3d9}
*{box-sizing:border-box}
body{margin:0;padding:16px;background:#030817;color:var(--text);font:15px/1.5 Inter,system-ui,sans-serif;min-width:360px}
h1{font-family:"Exo 2",system-ui,sans-serif;font-weight:600;color:var(--cyan);margin:0 0 4px;font-size:24px}
h2{font-family:"Exo 2",system-ui,sans-serif;font-weight:600;color:var(--cyan);font-size:16px;margin:0 0 8px}
.gold{color:var(--gold)} .muted{color:var(--muted);font-size:13px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin:16px 0}
.card{background:rgba(10,18,40,.55);border:1px solid rgba(63,227,255,.25);border-radius:14px;padding:14px;backdrop-filter:blur(12px)}
.big{font-family:"Exo 2",system-ui,sans-serif;font-size:28px;color:var(--gold)}
ul{margin:0;padding-left:18px} li{margin:2px 0}
.warn{color:var(--gold)} .err{color:var(--magenta)}
</style>
</head>
<body>
<h1>GABRIEL · Babel OS <span class="gold" id="ver"></span></h1>
<div class="muted" id="sub">modelo mínimo do painel (dashboard/template.html ausente)</div>
<div class="grid" id="tiles"></div>
<div class="card"><h2>O que eu sei de você</h2><ul id="portrait"></ul><h2>Ainda quero aprender</h2><ol id="want"></ol></div>
<div class="grid">
<div class="card"><h2>Projetos</h2><ul id="projects"></ul></div>
<div class="card"><h2>Pendências e agenda</h2><ul id="pending"></ul></div>
<div class="card"><h2>Linha da evolução</h2><ul id="mutations"></ul></div>
<div class="card"><h2>Saúde e avisos</h2><ul id="warnings"></ul></div>
</div>
<div class="muted" id="foot"></div>
<script id="babel-data">/*__BABEL_DADOS__*/</script>
<script>
(function(){
function el(tag,text,cls){var e=document.createElement(tag);if(text!==undefined&&text!==null)e.textContent=String(text);if(cls)e.className=cls;return e;}
function fill(id,items,fn){var u=document.getElementById(id);if(!u)return;while(u.firstChild)u.removeChild(u.firstChild);(items||[]).forEach(function(it){u.appendChild(fn(it));});if(!items||!items.length)u.appendChild(el('li','—','muted'));}
function tile(label,value){var c=el('div',null,'card');c.appendChild(el('div',value,'big'));c.appendChild(el('div',label,'muted'));return c;}
window.render=function(B){
 if(!B)return;var s=B.state||{},c=s.counts||{},h=B.health||{};
 document.getElementById('ver').textContent='v'+(B.identity&&B.identity.version||'?')+' · geração '+(B.identity&&B.identity.generation||0);
 document.getElementById('sub').textContent='vivo desde '+(B.identity&&B.identity.since||'?')+' · gerado em '+(B.generatedAt||'?')+(s.paused?' · ⏸ em pausa':'');
 var t=document.getElementById('tiles');while(t.firstChild)t.removeChild(t.firstChild);
 [['memórias',c.memories],['decisões',c.decisions],['projetos',c.projects],['conhecimento',c.knowledge],['pedidos',c.prompts],['sessões',c.sessions],['pendências',(B.pending||[]).length],['compactações',c.compactions]].forEach(function(p){t.appendChild(tile(p[0],p[1]==null?'—':p[1]));});
 fill('portrait',(B.profile||{}).portrait,function(x){return el('li',x);});
 fill('want',(B.profile||{}).wantToLearn,function(x){return el('li',x);});
 fill('projects',B.projects,function(p){return el('li',p.id+' ('+(p.situation||'')+') — '+(p.summary||''));});
 var pend=(B.pending||[]).map(function(p){return '[ ] '+p.project+': '+p.item;}).concat((B.agenda||[]).filter(function(a){return a.status==='open';}).map(function(a){return a.when+' · '+a.text;}));
 fill('pending',pend,function(x){return el('li',x);});
 fill('mutations',(B.mutations||[]).slice(-8).reverse(),function(m){return el('li',(m.ts||'').slice(0,16)+' '+m.versionBefore+' → '+m.versionAfter+' ('+(m.trigger||'')+')');});
 fill('warnings',B.warnings,function(w){return el('li',w.text,w.level==='erro'?'err':'warn');});
 document.getElementById('foot').textContent='órfãs '+(h.orphans||0)+' · duplicadas '+(h.duplicates||0)+' · similares '+(h.similar||0)+' · inválidas '+(h.invalid||0)+' · índice '+(h.index_lines||0)+'/'+(h.index_max_lines||150)+' linhas · '+((B.tips||[])[0]||'');
};
render(window.BABEL);
var n=0,last=window.BABEL&&window.BABEL.generatedAt;
setInterval(function(){n++;var old=document.getElementById('poll');if(old)old.parentNode.removeChild(old);var sc=document.createElement('script');sc.id='poll';sc.src='data.js?v='+n;sc.onload=function(){if(window.BABEL&&window.BABEL.generatedAt!==last){last=window.BABEL.generatedAt;render(window.BABEL);}};document.body.appendChild(sc);},5000);
})();
</script>
</body>
</html>
"""


def _tail(path, n, per_line=700):
    rows = common.tail_jsonl(path, max(4096, n * per_line))
    return [r for r in rows if isinstance(r, dict)][-n:]


def _rd(s, n=200):
    return common.truncate(common.redact(s), n) if s is not None else None


def _docs_cache():
    c = common.load_json(P["docs_json"], None, script=SCRIPT)
    out = []
    if isinstance(c, dict):
        for rel, e in c.items():
            if isinstance(e, dict) and isinstance(e.get("meta"), dict) and not e.get("invalid"):
                m = e["meta"]
                out.append({"id": e.get("id") or common.doc_id_from_path(rel), "collection": e.get("collection") or common.collection_of(os.path.join(common.ROOT, rel)),
                            "meta": m, "open": e.get("open") or [], "head": e.get("head") or "", "rel": rel})
        return out
    for path in common.list_docs():
        txt = common.read_text(path)
        if txt is None:
            continue
        meta, body = common.read_frontmatter(txt)
        if not isinstance(meta, dict):
            continue
        out.append({"id": common.doc_id_from_path(path), "collection": common.collection_of(path), "meta": meta, "open": [],
                    "head": body.strip()[:300], "rel": common.rel(path)})
    return out


def _date(iso):
    return str(iso or "")[:10]


def _memories(docs):
    items = []
    for d in docs:
        if d["collection"] not in ("memorias", "perfil", "origem"):
            continue
        m = d["meta"]
        items.append({"id": d["id"], "type": m.get("type"), "title": _rd(m.get("title"), 160), "tags": list(m.get("tags") or [])[:12],
                      "confidence": m.get("confidence", 0.7), "created": _date(m.get("created")), "status": m.get("status") or "active",
                      "pinned": bool(m.get("pinned")), "collection": d["collection"]})
    items.sort(key=lambda x: (x["created"], x["id"]), reverse=True)
    return items[:2000]


def _decisions(docs):
    items = [{"id": d["id"], "title": _rd(d["meta"].get("title"), 160), "created": _date(d["meta"].get("created")), "tags": list(d["meta"].get("tags") or [])[:12]}
             for d in docs if d["collection"] == "decisoes" and (d["meta"].get("status") or "active") == "active"]
    items.sort(key=lambda x: (x["created"], x["id"]), reverse=True)
    return items[:20]


def _projects(docs):
    items = []
    for d in docs:
        if d["collection"] != "projetos" or (d["meta"].get("status") or "active") != "active":
            continue
        m = d["meta"]
        items.append({"id": d["id"], "title": _rd(m.get("title"), 160), "summary": _rd(m.get("summary"), 200), "situation": m.get("situation") or "idea",
                      "next": [_rd(x, 160) for x in (d.get("open") or [])[:10]], "files": [str(x) for x in (m.get("files") or [])[:10]],
                      "updated": m.get("updated") or m.get("created")})
    order = {"in-progress": 0, "idea": 1, "paused": 2, "delivered": 3}
    items.sort(key=lambda p: (order.get(p["situation"], 9), str(p["updated"] or ""), p["id"]))
    return items


def _compactions(docs):
    items = [{"id": d["id"], "ts": d["meta"].get("created"), "session": d["meta"].get("session"), "head": _rd(d.get("head"), 300)}
             for d in docs if d["collection"] == "compactacoes"]
    items.sort(key=lambda x: (str(x["ts"] or ""), x["id"]), reverse=True)
    return items[:5]


def _agenda():
    items = collections.OrderedDict()
    for ev in common.read_jsonl(P["agenda"]):
        if not isinstance(ev, dict) or not ev.get("id"):
            continue
        aid = str(ev["id"])
        if ev.get("event") == "new":
            items[aid] = {"id": aid, "when": _date(ev.get("when")), "text": _rd(ev.get("text"), 160), "status": "open"}
        elif ev.get("event") == "done" and aid in items:
            items[aid]["status"] = "done"
    return sorted(items.values(), key=lambda a: (a["status"] != "open", a["when"] or "9999", a["id"]))


def _sessions():
    rows = common.read_jsonl(P["sessions"])
    starts, ends, order = {}, {}, []
    for r in rows:
        if not isinstance(r, dict) or not r.get("session"):
            continue
        sid = common.sid8(r["session"])
        if r.get("event") == "start":
            if r.get("init_only"):
                continue
            if sid not in starts:
                order.append(sid)
            starts[sid] = r
        elif r.get("event") == "end":
            ends[sid] = r
    out = []
    for sid in order[-20:]:
        s, e = starts[sid], ends.get(sid) or {}
        out.append({"id": sid, "start": s.get("ts"), "end": e.get("ts"), "prompts": e.get("prompts"), "newMemories": e.get("new_memories")})
    return out


def _deliveries():
    out = []
    base = P["entregas"]
    if not os.path.isdir(base):
        return out
    for dp, dn, fn in os.walk(base):
        dn[:] = sorted(d for d in dn if not d.startswith("."))
        for f in sorted(fn):
            if f.startswith("."):
                continue
            ap = os.path.join(dp, f)
            ext = os.path.splitext(f)[1].lower()
            kind = "site" if ext in (".html", ".htm") and os.path.basename(dp) == "sites" else ("sistema" if ext == ".md" else ("prototipo" if ext in (".html", ".htm") else "arquivo"))
            try:
                when = datetime.datetime.fromtimestamp(os.stat(ap).st_mtime).astimezone().isoformat(timespec="seconds")
            except Exception:
                when = None
            out.append({"name": f, "path": common.rel(ap), "type": kind, "when": when})
    out.sort(key=lambda d: (str(d["when"] or ""), d["path"]), reverse=True)
    return out[:300]


def _graph(graph):
    if not isinstance(graph, dict):
        return {"nodes": [], "edges": []}
    nodes = [n for n in (graph.get("nodes") or []) if isinstance(n, dict) and n.get("id")]
    edges = [e for e in (graph.get("edges") or []) if isinstance(e, dict) and e.get("from") and e.get("to")]
    orphans = set(graph.get("orphans") or [])
    if len(nodes) > 400:
        # prioridade: fixadas, depois mais recentes, depois maior grau (§3.7)
        nodes = sorted(nodes, key=lambda n: (0 if n.get("pinned") else 1, -_ord(n.get("created")), -(int(n.get("degree") or 0)), n["id"]))[:400]
    keep = set(n["id"] for n in nodes)
    edges = [e for e in edges if e["from"] in keep and e["to"] in keep]
    if len(edges) > 1200:
        edges.sort(key=lambda e: -float(e.get("weight") or 0))
        edges = edges[:1200]
    out_nodes = []
    for n in nodes:
        o = {"id": n["id"], "type": n.get("type"), "label": _rd(n.get("label"), 90), "degree": n.get("degree", 0)}
        if n.get("collection"):
            o["collection"] = n["collection"]
        if n.get("created"):
            o["created"] = n["created"]
        if n.get("status"):
            o["status"] = n["status"]
        if n["id"] in orphans:
            o["orphan"] = True
        out_nodes.append(o)
    return {"nodes": out_nodes, "edges": edges}


def _ord(iso):
    try:
        return int(str(iso or "0000-00-00")[:10].replace("-", ""))
    except Exception:
        return 0


def _warnings(health, state):
    out = []
    for w in (health.get("warnings") or []):
        key = str(w)
        base = key.split(":")[0]
        if base in WARNING_TEXT:
            level, text = WARNING_TEXT[base]
            if ":" in key:
                text += " (" + key.split(":", 1)[1] + ")"
        elif base.startswith("arroba_solto"):
            level, text = "atencao", "@ solto em %s: coloque entre crases para não virar import." % key.split(":", 1)[-1]
        elif base.startswith("tipo_invalido"):
            level, text = "atencao", "Tipo inválido em %s: tratado como fato." % key.split(":", 1)[-1]
        elif base.startswith("invalido"):
            level, text = "erro", "Frontmatter inválido em %s (não indexado)." % key.split(":", 1)[-1]
        else:
            level, text = "atencao", key
        out.append({"level": level, "text": text})
    if health.get("minor_pending"):
        out.append({"level": "atencao", "text": WARNING_TEXT["minor_pending"][1]})
    if state.get("paused"):
        out.append({"level": "atencao", "text": WARNING_TEXT["pausa"][1]})
    if health.get("orphans"):
        out.append({"level": "info", "text": "%d memória(s) órfã(s): ligue a um projeto com /lembrar --project." % health["orphans"]})
    if health.get("duplicates"):
        out.append({"level": "info", "text": "%d duplicata(s) exata(s) marcada(s) como superada(s) no lugar." % health["duplicates"]})
    if health.get("invalid"):
        out.append({"level": "erro", "text": "%d arquivo(s) com frontmatter inválido." % health["invalid"]})
    return out


def _json_for_html(obj):
    s = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    s = s.replace("</script", "<\\/script").replace("</Script", "<\\/Script").replace("</SCRIPT", "<\\/SCRIPT")
    s = s.replace(u"\u2028", "\\u2028").replace(u"\u2029", "\\u2029")
    return s


def build():
    """Monta o objeto BABEL (§3.9)."""
    state = common.load_json(P["state"], None, script=SCRIPT)
    if not isinstance(state, dict):
        state = {}
    cfg = common.load_config()
    cfg = dict((k, v) for k, v in cfg.items() if not k.startswith("_"))
    graph = common.load_json(P["graph"], None, script=SCRIPT)
    docs = _docs_cache()
    health = dict(state.get("health") or {})
    warnings_list = list(health.get("warnings") or [])
    template_missing = not os.path.exists(P["template"])
    if template_missing and "template_ausente" not in warnings_list:
        warnings_list.append("template_ausente")
    health["warnings"] = warnings_list
    prof = state.get("profile") or {}
    events = _tail(P["events"], 120)
    timeline = [{"ts": e.get("ts"), "session": e.get("session"), "event": e.get("event"), "tool": e.get("tool"), "file": e.get("file"),
                 "summary": _rd(e.get("summary"), 200), "agent": e.get("agent"), "denied": e.get("denied"), "blocked": e.get("blocked")} for e in events]
    recalls = [{"ts": r.get("ts"), "top": [[str(t[0]), t[1]] for t in (r.get("top") or []) if isinstance(t, (list, tuple)) and len(t) == 2][:10],
                "expanded": [str(x) for x in (r.get("expanded") or [])][:10], "chars": r.get("chars"), "ms": r.get("ms"),
                "history": r.get("history")} for r in _tail(P["recalls"], 30)]
    mutations = [{"ts": m.get("ts"), "versionBefore": m.get("version_before"), "versionAfter": m.get("version_after"), "new": (m.get("new") or [])[:20],
                  "changed": (m.get("changed") or [])[:20], "superseded": (m.get("superseded") or [])[:20], "trigger": m.get("trigger"),
                  "reason": _rd(m.get("reason"), 200)} for m in _tail(P["mutations"], 40, 1200)]
    refinements = [{"ts": r.get("ts"), "mode": r.get("mode"), "ms": r.get("ms"), "version": r.get("version"), "partial": r.get("partial"), "skipped": r.get("skipped")}
                   for r in _tail(P["refinements"], 200, 300)]
    heartbeats = [{"ts": h.get("ts"), "session": h.get("session"), "contextPct": h.get("context_pct"), "costUsd": h.get("cost_usd"),
                   "fiveHourPct": h.get("five_hour_pct"), "model": h.get("model"), "cacheWarm": h.get("cache_warm")} for h in _tail(P["heartbeats"], 200, 300)]
    cc = state.get("context_cost") or {}
    ident_since = _date(state.get("activated_at")) or common.today()
    babel = collections.OrderedDict()
    babel["generatedAt"] = common.now_iso()
    babel["identity"] = {"name": "Gabriel", "version": state.get("version") or "0.1.0", "generation": state.get("generation") or 0, "since": ident_since}
    babel["state"] = state
    babel["config"] = cfg
    babel["profile"] = {"summary": _rd(prof.get("summary"), 300), "portrait": [_rd(x, 120) for x in (prof.get("portrait") or [])][:12],
                        "learnedToday": [_rd(x, 120) for x in (prof.get("learned_today") or [])][:3], "wantToLearn": [_rd(x, 160) for x in (prof.get("want_to_learn") or [])][:3]}
    babel["memories"] = _memories(docs)
    babel["decisions"] = _decisions(docs)
    babel["projects"] = _projects(docs)
    babel["pending"] = [{"project": p.get("project"), "item": _rd(p.get("item"), 160), "since": p.get("since")} for p in (state.get("pending") or [])]
    babel["agenda"] = _agenda()
    babel["timeline"] = timeline
    babel["recalls"] = recalls
    babel["mutations"] = mutations
    babel["refinements"] = refinements
    babel["heartbeats"] = heartbeats
    babel["compactions"] = _compactions(docs)
    babel["sessions"] = _sessions()
    babel["deliveries"] = _deliveries()
    babel["graph"] = _graph(graph)
    babel["contextCost"] = {"claudeMdLines": cc.get("claude_md_lines", 0), "indexLines": cc.get("index_lines", 0), "rulesWithoutPaths": cc.get("rules_without_paths", 0),
                            "skillDescriptionsChars": cc.get("skill_descriptions_chars", 0), "skillDescriptionMaxChars": cc.get("skill_description_max_chars", 0),
                            "tokensPerSessionEst": cc.get("tokens_per_session_est", 0), "tokensPerTurnEst": cc.get("tokens_per_turn_est", 0),
                            "autoMemoryLines": health.get("auto_memory_lines", 0), "autoMemoryBytes": health.get("auto_memory_bytes", 0)}
    babel["health"] = health
    babel["warnings"] = _warnings(health, state)
    babel["tips"] = TIPS
    babel["templateMissing"] = template_missing
    return babel, template_missing


def generate():
    """Grava data.js e index.html atomicamente. Devolve True se gravou os dois."""
    t0 = time.monotonic()
    try:
        babel, template_missing = build()
        js = "window.BABEL = " + _json_for_html(babel) + ";"
        os.makedirs(P["dashboard"], exist_ok=True)
        common.write_atomic(P["data_js"], js + "\n")
        template = common.read_text(P["template"]) if not template_missing else None
        if template is None or MARKER not in template:
            if template is not None and MARKER not in template:
                common.log_error(SCRIPT, ValueError("template.html sem o marcador " + MARKER), extra={"file": "dashboard/template.html"})
            template = MINIMAL_TEMPLATE
        html = template.replace(MARKER, js, 1)
        common.write_atomic(P["index_html"], html)
        return True
    except BaseException as e:
        common.log_error(SCRIPT, e, extra={"message": "generate %d ms" % int((time.monotonic() - t0) * 1000)})
        return False


def main(argv):
    ok = generate()
    if "--json" in argv:
        print(json.dumps({"ok": ok, "index_html": common.rel(P["index_html"]), "data_js": common.rel(P["data_js"])}, ensure_ascii=False))
    elif "--quiet" not in argv:
        print(("painel gerado: %s e %s" % (common.rel(P["index_html"]), common.rel(P["data_js"]))) if ok else "painel: falhou (veja memoria/log/errors.jsonl)")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BaseException as e:
        common.log_error(SCRIPT, e)
    sys.exit(0)
