#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
wake.py --source <startup|resume|clear|compact|fork> --session <id> [--seconds-idle N]  (spec §11.4)

Monta o contexto do SessionStart (texto puro em stdout; o gancho embrulha em JSON, ≤ config.session_start_max_chars).
- startup/clear/fork: delega o bump de minor a refine.py --state-only --count-sessions --mark-session-start.
- source != compact: sessão-fantasma (.cache/setup-<sid8>.flag) → start init_only; senão start em sessions.jsonl,
  current-session.json e turn cache (só se não existir).
- snapshot diário (startup/fork) com timeout 3.
- compact: só o delta da sessão. Timeout interno 6 s. Nunca escreve state.json (só warnings_shown, sob lock lateral).
"""
import os, sys, io, re, json, time, datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

P = common.P
DEADLINE = 6.0
HEAD_CHARS = 160

WARN_PT = {
    "iterm_cc_status": "o anotador do iTerm2 (cc-status) aponta para pasta temporária; se aparecer 'hook error', não é o Gabriel (veja LEIA-ME, aviso 8a)",
    "hooks_desligados_global": "~/.claude/settings.json tem disableAllHooks: true — os hooks do organismo estão desligados",
    "block_reads_global": "~/.claude/settings.json bloqueia leituras fora da pasta — a memória automática fica inacessível",
    "settings_invalido": ".claude/settings.json inválido: nenhum hook está rodando",
    "settings_ausente": "não existe .claude/settings.json: os hooks do organismo não estão ligados",
    "hook_arquivo_ausente": "um hook do settings.json aponta para arquivo inexistente",
    "claude_dir_incompleto": "falta algo em .claude/ (hook, skills, agents ou rules); peça ao Gabriel para recriar com selftest.py antes",
    "motor_incompleto": "faltam scripts em motor/: rode /evoluir reparar",
    "frontmatter_invalido": "há memória com frontmatter inválido (/estado mostra qual)",
    "claude_md_import": "o CLAUDE.md não tem exatamente 1 @import relativo",
    "claude_md_linhas": "o CLAUDE.md passou de 180 linhas",
    "skill_descricao_longa": "há skill com description > 260 chars",
    "memory_md_grande": "o MEMORY.md da memória automática passou do limite (200 linhas / 25 KB)",
    "auto_memory_ausente": "a pasta da memória automática não existe (git init ou CLAUDE_CONFIG_DIR?)",
    "config_corrompido": "config.json estava corrompido e foi recriado",
    "state_corrompido": "state.json estava corrompido e foi refeito",
    "graph_corrompido": "graph.json estava corrompido e foi refeito",
    "cache_regenerado": "um cache ilegível foi regenerado",
    "events_grande": "events.jsonl passou de 20 MB; a manutenção rotaciona",
    "cwd_diferente": "o claude não foi aberto de dentro de babel-os",
    "template_ausente": "dashboard/template.html sumiu; painel mínimo em uso",
}
SKIP_WARN = ("pausa", "minor_pending", "conhecimento_antigo", "indice_grande", "offsets_zerado")


def _docs_meta():
    """[{id, title, type, collection, created, tags, project}] das coleções memorias/decisoes/projetos/perfil.
    Usa .cache/index.json quando existe; senão varre os .md."""
    out = []
    idx = common.load_json(P["index_json"], None, script="wake.py")
    if isinstance(idx, dict) and isinstance(idx.get("meta"), dict) and idx["meta"]:
        for did, m in idx["meta"].items():
            if not isinstance(m, dict) or did.startswith("prompt:"):
                continue
            if m.get("collection") not in ("memorias", "decisoes", "projetos", "perfil"):
                continue
            if m.get("status") not in (None, "active"):
                continue
            out.append({"id": did, "title": m.get("title") or did, "type": m.get("type"), "collection": m.get("collection"),
                        "created": str(m.get("created") or ""), "tags": m.get("tags") or [], "project": m.get("project")})
        if out:
            return out
    for path in common.list_docs():
        col = common.collection_of(path)
        if col not in ("memorias", "decisoes", "projetos", "perfil"):
            continue
        txt = common.read_text(path)
        if not txt:
            continue
        meta, body = common.read_frontmatter(txt)
        if not isinstance(meta, dict):
            continue
        if meta.get("status") not in (None, "active"):
            continue
        out.append({"id": meta.get("id") or common.doc_id_from_path(path), "title": meta.get("title") or common.doc_id_from_path(path),
                    "type": meta.get("type"), "collection": col, "created": str(meta.get("created") or ""),
                    "tags": meta.get("tags") or [], "project": meta.get("project")})
    return out


def agenda_items():
    """Resolve agenda.jsonl por id → [{id, when, text}] abertos."""
    items = {}
    for ev in common.read_jsonl(P["agenda"]):
        if not isinstance(ev, dict) or not ev.get("id"):
            continue
        if ev.get("event") == "new":
            items[ev["id"]] = {"id": ev["id"], "when": str(ev.get("when") or ""), "text": str(ev.get("text") or "")}
        elif ev.get("event") == "done":
            items.pop(ev["id"], None)
    return sorted(items.values(), key=lambda x: (x["when"], x["id"]))


def agenda_soon(items, days=7):
    today = common.today()
    try:
        limit = (common.now() + datetime.timedelta(days=days)).strftime("%Y-%m-%d")
    except Exception:
        limit = today
    out = []
    for it in items:
        w = it["when"][:10]
        if not w:
            continue
        if w < today:
            out.append((it, "vencido"))
        elif w <= limit:
            out.append((it, "hoje" if w == today else "em breve"))
    return out


def last_session_info(current_sid):
    """(dict|None): {id, end, prompts, new_memories, response_head, start}. Ignora init_only e sessões sem prompt."""
    ls = common.load_json(P["last_session"], None, script="wake.py")
    if isinstance(ls, dict) and ls.get("session") and ls.get("session") != current_sid and (ls.get("prompts") or 0) > 0:
        return {"id": ls.get("session"), "start": ls.get("start"), "end": ls.get("end"), "prompts": ls.get("prompts") or 0,
                "new_memories": ls.get("new_memories") or 0, "response_head": ls.get("response_head") or ""}
    ends = common.read_jsonl(P["sessions"], last=200)
    init_only = set(s.get("session") for s in ends if isinstance(s, dict) and s.get("init_only"))
    for s in reversed(ends):
        if not isinstance(s, dict) or s.get("event") != "end":
            continue
        if s.get("session") in init_only or s.get("session") == current_sid or not (s.get("prompts") or 0):
            continue
        head = ""
        for t in reversed(common.tail_jsonl(P["turns"], 16384)):
            if isinstance(t, dict) and t.get("session") == s.get("session") and t.get("response_head"):
                head = t["response_head"]; break
        return {"id": s.get("session"), "start": None, "end": s.get("ts"), "prompts": s.get("prompts") or 0,
                "new_memories": s.get("new_memories") or 0, "response_head": head}
    return None


def _clean(s, n):
    return common.truncate(common.escape_at(common.redact(str(s or "").replace("\n", " ").strip())), n)


def _pt_type(t):
    return common.label_type(t) if t else "memória"


def _update_warnings_shown(key, value):
    def _f(o):
        ws = o.get("warnings_shown") if isinstance(o.get("warnings_shown"), dict) else {}
        ws[key] = value
        o["warnings_shown"] = ws
    common.update_json_locked(P["state"], _f, script="wake.py")


def build_context(source, sid, seconds_idle, state, cfg, turn, t0):
    lines = []
    counts = state.get("counts") or {}
    health = state.get("health") or {}
    today = common.today()
    yesterday = (common.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")

    if source == "compact":
        delta = turn.get("compact_delta") if isinstance(turn.get("compact_delta"), dict) else None
        files, mems = [], []
        if delta:
            files = list(delta.get("files") or [])
            mems = list(delta.get("memories") or [])
        else:
            for k, v in sorted((turn.get("files_by_prompt") or {}).items()):
                files += [f for f in (v or []) if isinstance(f, str)]
            for k, v in sorted((turn.get("memories_by_prompt") or {}).items()):
                mems += [m for m in (v or []) if isinstance(m, str)]
        seen, uf = set(), []
        for f in files:
            if f not in seen:
                seen.add(f); uf.append(f)
        seen, um = set(), []
        for m in mems:
            if m not in seen and m != "cli":
                seen.add(m); um.append(m)
        lines.append("Gabriel, contexto compactado. Delta desta sessão (%s), %d pedido(s):" % (sid, turn.get("prompts") or 0))
        if uf:
            lines.append("- Arquivos tocados nesta sessão (%d): %s" % (len(uf), ", ".join(common.escape_at(f) for f in uf[:20])))
        if um:
            lines.append("- Memórias registradas nesta sessão: %s" % ", ".join(um[:20]))
        if turn.get("pending_reminder"):
            lines.append("- ⚠ Há alteração de arquivo sem memória registrada: registre com python3 motor/remember.py antes de seguir.")
        if turn.get("current_prompt"):
            lines.append("- Pedido atual: %s" % turn.get("current_prompt"))
        over = [(it, tag) for it, tag in agenda_soon(agenda_items(), 0) if tag == "vencido"]
        for it, tag in over[:5]:
            lines.append("- Lembrete vencido %s: %s (%s)" % (common.fmt_ddmm(it["when"]), _clean(it["text"], 100), it["id"]))
        if len(lines) == 1:
            lines.append("- Nada tocado ainda nesta sessão.")
        return lines

    # ---- startup / clear / fork / resume
    last = last_session_info(sid)
    head = "Organismo Gabriel v%s (geração %s) · %s memórias · %s projetos" % (
        state.get("version") or "0.1.0", state.get("generation") or 0, counts.get("memories", 0), counts.get("projects", 0))
    if last:
        head += " · última sessão %s (%d pedidos, %d memórias novas%s)" % (
            common.fmt_ddmm(last.get("end") or "", hora=True), last["prompts"], last["new_memories"],
            ("; terminou com: " + _clean(last["response_head"], HEAD_CHARS)) if last.get("response_head") else "")
    else:
        head += " · primeira sessão registrada"
    lines.append(head)
    if source == "resume":
        if seconds_idle is not None and seconds_idle > 0:
            mins = int(seconds_idle // 60)
            lines.append("Você voltou depois de %s; o índice pode ter mudado desde o início da sessão (só recarrega em /clear ou /compact)."
                         % ("%d min" % mins if mins < 180 else "%d h" % (mins // 60)))
        else:
            lines.append("Você voltou a uma sessão anterior; o índice pode ter mudado desde o início (só recarrega em /clear ou /compact).")

    if time.monotonic() - t0 < DEADLINE - 1.5:
        docs = _docs_meta()
        mems = [d for d in docs if d["collection"] in ("memorias", "decisoes")]
        mems.sort(key=lambda d: (d["created"], d["id"]), reverse=True)
        if mems:
            lines.append("Últimas memórias:")
            for d in mems[:5]:
                lines.append("- [%s] %s (%s)" % (_pt_type(d["type"]), _clean(d["title"], 90), d["id"]))
        learned = [d for d in docs if d["created"][:10] in (today, yesterday) and d["collection"] == "memorias"]
        learned.sort(key=lambda d: (d["created"], d["id"]), reverse=True)
        if learned:
            days = set(d["created"][:10] for d in learned[:3])
            lines.append("Aprendi %s:" % ("hoje" if days == set([today]) else ("ontem" if days == set([yesterday]) else "ontem/hoje")))
            for d in learned[:3]:
                lines.append("- %s (%s)" % (_clean(d["title"], 90), d["id"]))

    pend = [p for p in (state.get("pending") or []) if isinstance(p, dict)]
    if pend:
        lines.append("Pendências abertas (%d):" % len(pend))
        for p in pend[:8]:
            lines.append("- [ ] %s: %s%s" % (p.get("project") or "?", _clean(p.get("item"), 100),
                                             (" (desde %s)" % common.fmt_ddmm(p.get("since"))) if p.get("since") else ""))
    soon = agenda_soon(agenda_items(), 7)
    if soon:
        lines.append("Agenda (vencidos e próximos 7 dias):")
        for it, tag in soon[:5]:
            lines.append("- %s%s · %s (%s)" % (common.fmt_ddmm(it["when"]), " ⚠ vencido" if tag == "vencido" else "",
                                                 _clean(it["text"], 100), it["id"]))

    # ---- avisos de saúde
    warns = []
    codes = [w for w in (health.get("warnings") or []) if isinstance(w, str)]
    shown = state.get("warnings_shown") if isinstance(state.get("warnings_shown"), dict) else {}
    if common.paused():
        warns.append("arquivo PAUSA presente: hooks e linha de status parados (apague ou /pausar)")
    if health.get("minor_pending"):
        warns.append("versão minor pendente: a manutenção conclui no próximo início")
    idx_lines = health.get("index_lines") or 0
    if not idx_lines:
        try:
            idx_lines = (common.read_text(P["indice"]) or "").count("\n")
        except Exception:
            idx_lines = 0
    if idx_lines > 120:
        warns.append("INDICE.md com %d linhas (limite %d): fixe menos, arquive mais" % (idx_lines, cfg.get("index_max_lines", 150)))
    try:
        log_mb = sum(os.path.getsize(os.path.join(P["log"], f)) for f in os.listdir(P["log"]) if f.endswith(".jsonl")) / (1024.0 * 1024.0)
    except Exception:
        log_mb = 0
    if log_mb > 15:
        warns.append("logs com %.0f MB: a manutenção rotaciona acima de 20 MB" % log_mb)
    if "iterm_cc_status" in codes and shown.get("iterm_cc_status") != today:
        warns.append(WARN_PT["iterm_cc_status"])
        if os.path.exists(P["state"]):
            _update_warnings_shown("iterm_cc_status", today)
    age = health.get("knowledge_age_days")
    max_age = cfg.get("knowledge_max_age_days", 90)
    if isinstance(age, (int, float)) and age > max_age:
        last_shown = common.parse_iso(str(shown.get("knowledge_age") or ""))
        if last_shown is None or (common.now() - last_shown).total_seconds() > 7 * 86400:
            warns.append("o que sei de configuração do Claude Code tem %d dias; `/pesquisar claude code` atualiza" % int(age))
            if os.path.exists(P["state"]):
                _update_warnings_shown("knowledge_age", today)
    for c in codes:
        base = c.split(":")[0]
        if base in SKIP_WARN or base == "iterm_cc_status":
            continue
        txt = WARN_PT.get(base)
        if txt and txt not in warns:
            warns.append(txt)
    missing = []
    if not os.path.exists(P["hook"]):
        missing.append("hooks/hook.py")
    for k in ("skills", "agents", "rules"):
        if not os.path.isdir(P[k]):
            missing.append(k + "/")
    if missing and not any("falta algo em .claude/" in w for w in warns):
        warns.append("falta %s em .claude/; peça ao Gabriel para recriar com selftest.py antes" % ", ".join(missing))
    if warns:
        lines.append("Avisos de saúde:")
        for w in warns[:6]:
            lines.append("- ⚠ " + w)
    lines.append("Registre aprendizados com python3 motor/remember.py; o índice em CLAUDE.md recarrega no /clear.")
    return lines


def _fit(lines, max_chars):
    text = "\n".join(lines)
    while len(text) > max_chars and len(lines) > 1:
        lines = lines[:-1]
        text = "\n".join(lines)
    if len(text) > max_chars:
        text = common.truncate(text, max_chars)
    return text


def main(argv):
    t0 = time.monotonic()
    args = list(argv)

    def _opt(name, default=None):
        if name in args:
            i = args.index(name)
            if i + 1 < len(args):
                return args[i + 1]
        return default
    source = (_opt("--source") or "startup").strip().lower()
    if source not in ("startup", "resume", "clear", "compact", "fork"):
        source = "startup"
    session = _opt("--session") or common.session_id_fallback()
    sid = common.sid8(session)
    try:
        seconds_idle = float(_opt("--seconds-idle")) if _opt("--seconds-idle") is not None else None
    except Exception:
        seconds_idle = None
    cfg = common.load_config()
    common.ensure_dirs()

    # 2. bump de minor delegado ao refinador (nunca escreve state.json aqui)
    if source in ("startup", "clear", "fork") and os.path.exists(os.path.join(P["motor"], "refine.py")):
        common.run_motor("refine.py", ["--state-only", "--count-sessions", "--mark-session-start", "--session", sid,
                                       "--trigger", "SessionStart", "--quiet"], timeout=3.0)

    state = common.load_json(P["state"], {}, script="wake.py") or {}
    if not isinstance(state, dict):
        state = {}
    turn_path = os.path.join(P["cache"], "turn-%s.json" % sid)

    # 3. sessão-fantasma ou início normal
    init_only = False
    if source != "compact":
        flag = os.path.join(P["cache"], "setup-%s.flag" % sid)
        if os.path.exists(flag):
            init_only = True
            try:
                os.unlink(flag)
            except Exception:
                pass
        common.append_jsonl(P["sessions"], {"ts": common.now_iso(), "session": sid, "event": "start", "source": source,
                                            "model": os.environ.get("CLAUDE_MODEL") or None, "version": state.get("version"),
                                            "memories": (state.get("counts") or {}).get("memories", 0),
                                            "resumed": source == "resume", "init_only": init_only})
        if not init_only:
            try:
                common.save_json(P["current_session"], {"session": sid, "ts": common.now_iso(), "source": source})
            except Exception as e:
                common.log_error("wake.py", e, extra={"file": "current-session.json"})
            if not os.path.exists(turn_path):
                try:
                    common.save_json(turn_path, {"session": sid, "start": common.now_iso(), "prompts": 0, "current_prompt": None,
                                                 "permission_mode": None, "last_command": None, "files_by_prompt": {},
                                                 "memories_by_prompt": {}, "stop_blocks": {}, "pending_reminder": False,
                                                 "compact_delta": None, "subagents": {}})
                except Exception as e:
                    common.log_error("wake.py", e, extra={"file": "turn-%s.json" % sid})

    # 4. snapshot diário
    if (not init_only and source in ("startup", "fork") and cfg.get("daily_snapshot") and time.monotonic() - t0 < DEADLINE - 3.5):
        today_prefix = common.now().strftime("%Y%m%d")
        has_today = False
        try:
            has_today = any(f.startswith(today_prefix) and f.endswith(".tar.gz") for f in os.listdir(P["backups"]))
        except Exception:
            has_today = False
        if not has_today and os.path.exists(os.path.join(P["motor"], "snapshot.py")):
            rc, out, err = common.run_motor("snapshot.py", ["create", "--reason", "daily"], timeout=3.0)
            if rc is None:
                try:
                    common.write_atomic(os.path.join(P["cache"], "snapshot-pending.flag"), common.now_iso() + "\n")
                except Exception:
                    pass

    # 5. texto
    turn = common.load_json(turn_path, {}, script="wake.py") or {}
    if not isinstance(turn, dict):
        turn = {}
    lines = build_context(source, sid, seconds_idle, state, cfg, turn, t0)
    text = _fit(lines, int(cfg.get("session_start_max_chars", 3000)))
    # verificação final do @ (o gancho injeta isto no contexto; nunca um import acidental)
    if common.bare_at_lines(text):
        text = common.escape_at(text)
    sys.stdout.write(text)
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BaseException as e:
        common.log_error("wake.py", e)
    sys.exit(0)
