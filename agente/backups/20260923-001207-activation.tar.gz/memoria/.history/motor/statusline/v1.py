#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
statusline.py — linha de status do Gabriel (spec §12). Lê o JSON do Claude Code em stdin (todo campo pode
faltar ou ser null) e imprime 2 linhas em pt-BR (a 2ª some se COLUMNS < 90). Nunca stdout vazio, nunca exit != 0.
Batimento em heartbeats.jsonl no máximo 1×/60 s por sessão (.cache/heartbeat-<sid8>.txt).
"""
import os, sys, io, re, json, time, unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import common
except Exception:
    common = None

ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
CYAN, GOLD, GRAY, GREEN, YELLOW, RED, RESET = "\033[36m", "\033[33m", "\033[90m", "\033[32m", "\033[33m", "\033[31m", "\033[0m"
EFFORTS = {"low": "leve", "medium": "médio", "high": "alto", "xhigh": "ultra", "max": "máximo"}
MODES = {"default": "manual", "acceptEdits": "aceitar edições", "plan": "plano", "auto": "auto",
         "dontAsk": "sem perguntar", "bypassPermissions": "sem permissões"}
FALLBACK = "🧬 Gabriel"


def _out(s):
    try:
        sys.stdout.write(s if s.strip() else FALLBACK)
        sys.stdout.write("\n")
        sys.stdout.flush()
    except Exception:
        pass


def vis_len(s):
    s = ANSI_RE.sub("", s)
    n = 0
    for ch in s:
        if unicodedata.combining(ch) or ch in ("️", "‍"):
            continue
        n += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return n


def cut_visible(s, width):
    """Corta a string em `width` colunas visíveis, preservando/fechando ANSI."""
    if vis_len(s) <= width:
        return s
    out, n, i = [], 0, 0
    while i < len(s):
        m = ANSI_RE.match(s, i)
        if m:
            out.append(m.group(0)); i = m.end(); continue
        ch = s[i]
        w = 0 if (unicodedata.combining(ch) or ch in ("️", "‍")) else (2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1)
        if n + w > width:
            break
        out.append(ch); n += w; i += 1
    return "".join(out).rstrip() + RESET


def _join(segs):
    out = ""
    for s in segs:
        if not out:
            out = s
        elif s.startswith("│"):
            out += " " + s
        else:
            out += " · " + s
    return out


def fit(segments, width, keep=1):
    """Junta segmentos com ' · ' (o bloco '│ …' entra com espaço); corta da direita para a esquerda;
    os `keep` primeiros nunca somem."""
    segs = [s for s in segments if s]
    while segs:
        line = _join(segs)
        if vis_len(line) <= width or len(segs) <= keep:
            return cut_visible(line, width)
        segs.pop()
    return ""


def _num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _plural(n, one, many):
    return "%d %s" % (n, one if n == 1 else many)


def build(d, cols):
    P = common.P
    width = max(20, cols - 2)
    state = common.load_json(P["state"], {}, script="statusline.py") or {}
    if not isinstance(state, dict):
        state = {}
    counts = state.get("counts") or {}
    health = state.get("health") or {}
    warnings = health.get("warnings") or []
    version = state.get("version") or "0.0.0"
    mem_n = counts.get("memories")
    pend_n = len(state.get("pending") or [])
    ag_n = state.get("agenda_open") or 0
    ag_over = state.get("agenda_overdue") or 0

    sid = common.sid8(d.get("session_id") or common.session_id_fallback())
    model = ((d.get("model") or {}).get("display_name")) if isinstance(d.get("model"), dict) else None
    effort = ((d.get("effort") or {}).get("level")) if isinstance(d.get("effort"), dict) else None
    cw = d.get("context_window") if isinstance(d.get("context_window"), dict) else {}
    pct = _num(cw.get("used_percentage"))
    cost = d.get("cost") if isinstance(d.get("cost"), dict) else {}
    usd = _num(cost.get("total_cost_usd"))
    dur = _num(cost.get("total_duration_ms"))
    pc = d.get("prompt_cache") if isinstance(d.get("prompt_cache"), dict) else None
    warm = pc.get("warm") if pc else None
    rl = d.get("rate_limits") if isinstance(d.get("rate_limits"), dict) else {}
    five = (rl.get("five_hour") or {}) if isinstance(rl.get("five_hour"), dict) else {}
    five_pct = _num(five.get("used_percentage"))
    session_name = d.get("session_name") if isinstance(d.get("session_name"), str) else None

    turn = common.load_json(os.path.join(P["cache"], "turn-%s.json" % sid), {}, script="statusline.py") or {}
    mode = turn.get("permission_mode") if isinstance(turn, dict) else None

    # ---- linha 1
    ctx_s = ("ctx %d%%" % int(round(pct))) if pct is not None else "ctx —"
    seg1 = [CYAN + "🧬 Gabriel" + RESET + " " + GOLD + "v%s" % version + RESET]
    if cols < 90:
        seg1.append(ctx_s)
    if mem_n is not None:
        seg1.append("🧠 %d mem" % int(mem_n))
    if pend_n:
        seg1.append("📌 " + _plural(pend_n, "pendência", "pendências"))
    if ag_n:
        seg1.append("🗓 " + _plural(int(ag_n), "lembrete", "lembretes") + ((" (%d vencido%s)" % (ag_over, "" if ag_over == 1 else "s")) if ag_over else ""))
    right1 = []
    if model:
        right1.append("cérebro %s" % model)
    if effort:
        right1.append("esforço %s" % EFFORTS.get(str(effort), str(effort)))
    if mode:
        right1.append("modo %s" % MODES.get(str(mode), str(mode)))
    if session_name:
        right1.append(common.truncate(session_name, 24))
    if right1:
        seg1.append("│ " + " · ".join(right1))
    line1 = fit(seg1, width, keep=2 if cols < 90 else 1)

    # ---- linha 2
    if pct is not None:
        p = max(0, min(100, pct))
        filled = int(round(p / 10.0))
        color = GREEN if p < 70 else (YELLOW if p < 90 else RED)
        bar = color + "▓" * filled + "░" * (10 - filled) + RESET + " memória %d%%" % int(round(p))
    else:
        bar = GRAY + "░░░░░░░░░░" + RESET + " memória —"
    seg2 = [bar]
    if usd is not None:
        seg2.append(common.fmt_brl(usd))
    if dur is not None and dur > 0:
        seg2.append("%d min" % int(dur / 60000))
    if warm is True:
        seg2.append("⚡ cache quente")
    elif warm is False:
        seg2.append("cache frio")
    if five_pct is not None:
        seg2.append("limite 5h %d%%" % int(round(five_pct)))
    # lembrou há N min
    try:
        rec = common.tail_jsonl(P["recalls"], 4096)
        last_ts = None
        for r in reversed(rec):
            if isinstance(r, dict) and r.get("ts"):
                last_ts = r["ts"]; break
        if last_ts:
            dd = common.parse_iso(last_ts)
            if dd:
                mins = int((common.now() - dd).total_seconds() // 60)
                seg2.append("lembrou há %s" % ("%d min" % mins if mins < 120 else "%d h" % (mins // 60)))
    except Exception:
        pass
    # falha recente de API
    try:
        lf = common.load_json(P["last_failure"], None, script="statusline.py")
        if isinstance(lf, dict) and lf.get("ts"):
            dd = common.parse_iso(lf["ts"])
            if dd and (common.now() - dd).total_seconds() < 300:
                seg2.append(RED + "⚠ API: %s" % common.truncate(common.redact(str(lf.get("error") or "erro")), 40) + RESET)
    except Exception:
        pass
    # dicas (fim da linha 2)
    if pct is not None and pct >= 80:
        hint = YELLOW + "⚠️ memória cheia: /compact guarda tudo antes" + RESET
    elif "iterm_cc_status" in warnings:
        hint = YELLOW + "⚠ iTerm (veja LEIA-ME)" + RESET
    elif warnings:
        hint = YELLOW + "⚠️ /estado tem um aviso" + RESET
    else:
        hint = GRAY + "Shift+Tab modo · Esc Esc voltar · /ajuda" + RESET
    seg2.append("│ " + hint)
    line2 = fit(seg2, width, keep=1) if cols >= 90 else ""

    # ---- batimento (≤ 1/60 s por sessão)
    try:
        stamp = os.path.join(P["cache"], "heartbeat-%s.txt" % sid)
        age = None
        try:
            age = time.time() - os.path.getmtime(stamp)
        except Exception:
            age = None
        if age is None or age > 60:
            os.makedirs(P["cache"], exist_ok=True)
            common.append_jsonl(P["heartbeats"], {"ts": common.now_iso(), "session": sid, "model": model,
                                                  "context_pct": pct, "cost_usd": usd, "cache_warm": warm,
                                                  "five_hour_pct": five_pct, "effort": effort})
            with io.open(stamp, "w", encoding="utf-8") as f:
                f.write(common.now_iso())
    except Exception:
        pass

    return line1, line2


def main():
    raw = ""
    try:
        raw = sys.stdin.read()
    except Exception:
        raw = ""
    try:
        d = json.loads(raw)
        if not isinstance(d, dict):
            raise ValueError("stdin não é objeto")
    except Exception:
        _out("🧬 Gabriel · aquecendo…")
        return
    if common is None:
        _out(FALLBACK)
        return
    if common.paused():
        _out("⏸ Gabriel em pausa (apague o arquivo PAUSA ou /pausar)")
        return
    try:
        cols = int(os.environ.get("COLUMNS") or 0)
    except Exception:
        cols = 0
    if cols <= 0:
        cols = 120
    line1, line2 = build(d, cols)
    text = line1 if not line2 else line1 + "\n" + line2
    _out(text)


if __name__ == "__main__":
    try:
        main()
    except BaseException as e:
        try:
            if common is not None:
                common.log_error("statusline.py", e)
        except Exception:
            pass
        _out(FALLBACK)
    sys.exit(0)
