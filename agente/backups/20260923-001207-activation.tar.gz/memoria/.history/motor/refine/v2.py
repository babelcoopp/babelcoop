#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
refine.py — o refinador determinístico do organismo Gabriel (spec §11.6).

--quick            (Stop) assinatura rápida; deadline 1,5 s; lock refine com espera 0,5 s
--full [--report]  tudo + Jaccard de quase-duplicatas; deadline 20 s
--major "motivo"   evolução maior (major += 1) + snapshot evolve
--state-only [--count-sessions] [--mark-session-start] [--session SID8]
--trigger X        origem do refino (Stop, remember, agenda, maintenance...)
--quiet            sem stdout

Funções de módulo usadas por outros scripts:
  build_index(deadline=None, write=True) -> dict (§3.8)
  load_index() -> dict | None
  load_state() -> dict
  run(mode, trigger=None, report=False, reason=None, count_sessions=False,
      mark_session_start=False, session=None, quiet=False) -> dict
"""
import os, sys, io, re, json, time, math, datetime, collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

SCRIPT = "refine.py"
DEADLINE_QUICK = 1.5
DEADLINE_FULL = 20.0
BODY_INDEX_CHARS = 600
HEAD_CHARS = 600
MAX_PROMPT_DOCS = 3000
STATE_SKELETON = {
    "version": "0.1.0", "generation": 0, "activated_at": None,
    "counts": {}, "by_type": {}, "last_session": None, "counts_at_session_start": None,
    "last_refinement": None, "last_full_refinement": None, "last_snapshot": None,
    "sessions_counted": [], "profile": {"summary": "", "learned_today": [], "want_to_learn": []},
    "pending": [], "agenda_open": 0, "agenda_overdue": 0,
    "health": {}, "warnings_shown": {}, "imports": {}, "context_cost": {}, "paused": False,
}
DEFAULT_TYPE_BY_COLLECTION = {
    "perfil": "profile", "memorias": "fact", "decisoes": "decision", "projetos": "project",
    "conhecimento": "knowledge", "compactacoes": "compaction", "relatorios": "report", "origem": "reference",
}
SITUATIONS = ["idea", "in-progress", "delivered", "paused"]
SITUATION_LABELS = {"idea": "ideia", "in-progress": "em andamento", "delivered": "entregue", "paused": "pausado"}
MEMORY_TYPE_ORDER = ["preference", "profile", "fact", "learning", "idea", "reference"]
# avisos que este script calcula (os demais em health.warnings são preservados: verify.py os grava)
OWN_WARNING_PREFIXES = ("conhecimento_antigo", "cache_regenerado", "config_corrompido", "config_tipo_errado",
                        "arroba_solto:", "tipo_invalido:", "template_ausente", "indice_grande", "log_grande",
                        "invalido:", "refino_parcial")
# lista fixa das 10 lacunas de perfil (§11.6 passo 9): (pergunta, tags-gatilho)
PROFILE_GAPS = [
    ("Em que horário você prefere trabalhar comigo?", ["horario", "horarios", "rotina", "manha", "noite", "madrugada"]),
    ("Por qual canal você prefere falar comigo (terminal, VS Code, celular)?", ["canal", "canais", "terminal", "vscode", "celular", "whatsapp-canal"]),
    ("Qual meta do trimestre pesa mais para você agora?", ["meta", "metas", "trimestre", "objetivo", "objetivos", "kpi"]),
    ("Quem além do Diego decide com você?", ["socios", "socio", "equipe", "time", "decisores", "pessoas-chave"]),
    ("Que tom de copy você quer nas LPs: mais provocador ou mais sóbrio?", ["copy", "tom", "voz", "escrita", "tom-de-voz"]),
    ("Qual orçamento típico você reserva para um site ou campanha?", ["orcamento", "budget", "investimento", "custo", "preco"]),
    ("Qual público é prioridade agora (porte, região, segmento)?", ["publico", "publico-alvo", "persona", "audiencia", "segmento"]),
    ("Quais ferramentas você usa no dia a dia (CRM, planilhas, WhatsApp Business)?", ["ferramentas", "ferramenta", "crm", "stack", "apps"]),
    ("Como você costuma decidir: sozinho, com o Diego ou em reunião?", ["ritual", "rituais", "reuniao", "reunioes", "processo-decisorio", "como-decide"]),
    ("O que você não quer nunca em uma entrega?", ["nunca", "restricao", "restricoes", "veto", "limite", "proibido"]),
]

P = common.P


# --------------------------------------------------------------------------- utilidades locais
class Deadline(object):
    def __init__(self, seconds):
        self.t0 = time.monotonic()
        self.limit = float(seconds) if seconds else None

    def over(self):
        return self.limit is not None and (time.monotonic() - self.t0) > self.limit

    def ms(self):
        return int((time.monotonic() - self.t0) * 1000)


def _rel(path):
    return common.rel(path) or os.path.basename(path)


def _abs(rel):
    return os.path.join(common.ROOT, rel)


def _date_part(iso):
    s = str(iso or "")
    return s[:10] if len(s) >= 10 else s


def _month_part(iso):
    s = str(iso or "")
    return s[:7]


def _iso_from_mtime(mtime):
    try:
        return datetime.datetime.fromtimestamp(mtime).astimezone().isoformat(timespec="seconds")
    except Exception:
        return common.now_iso()


def _as_list(v):
    if v is None:
        return []
    if isinstance(v, list):
        return [str(x).strip() for x in v if x is not None and str(x).strip() != ""]
    s = str(v).strip()
    if not s:
        return []
    return [x.strip() for x in s.split(",") if x.strip()]


def _tag_norm(t):
    return common.slug(t, 40)


def _to_float(v, default):
    try:
        if isinstance(v, bool):
            return default
        return float(v)
    except Exception:
        return default


def _to_int(v, default):
    try:
        if isinstance(v, bool):
            return default
        return int(v)
    except Exception:
        return default


def _tf(text, expand=True):
    """Contagem de termos (mesma normalização de common.tokenize, mas contando repetições)."""
    counts = collections.Counter()
    if not text:
        return counts
    t = common._fold(text)
    stop = common._stopwords()
    syn = common._synonyms()
    for w in re.findall(r"[a-z0-9]+", t):
        if w in stop:
            continue
        if len(w) < 3 and not w.isdigit() and w not in syn:
            continue
        s = common.stem(w)
        counts[s] += 1
        if expand:
            for extra in (syn.get(w) or syn.get(s) or []):
                counts[common.stem(common._fold(extra))] += 1
    return counts


def _first_heading(body):
    for line in (body or "").split("\n"):
        m = re.match(r"^#\s+(.+?)\s*$", line)
        if m:
            return m.group(1).strip()
    return None


def _first_sentence(body, n=90):
    for line in (body or "").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith("```") or s.startswith("---"):
            continue
        s = re.sub(r"[*_`>]+", "", s)
        m = re.match(r"^(.+?[.!?])(\s|$)", s)
        s = m.group(1) if m else s
        return common.truncate(s, n)
    return None


def _open_items(body):
    """Itens '- [ ]' (abertos) e '- [x]' (feitos) da seção '## Próximos passos' (ou do corpo todo se não houver)."""
    lines = (body or "").split("\n")
    sec = []
    inside = False
    has_section = False
    for line in lines:
        if line.startswith("## "):
            inside = "próximos passos" in common._fold(line) or "proximos passos" in common._fold(line)
            has_section = has_section or inside
            continue
        if inside:
            sec.append(line)
    src = sec if has_section else lines
    open_, done = [], []
    for line in src:
        m = re.match(r"^\s*[-*]\s+\[( |x|X)\]\s+(.*?)\s*$", line)
        if not m:
            continue
        (open_ if m.group(1) == " " else done).append(m.group(2))
    return open_, done


def _wikilinks(body):
    return [m.group(1).strip() for m in re.finditer(r"\[\[([^\]\n]+)\]\]", body or "")]


def _sha256_file(path):
    import hashlib
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ""


# --------------------------------------------------------------------------- estado / cache
def _default_state():
    return json.loads(json.dumps(STATE_SKELETON))


def load_state():
    st = common.load_json(P["state"], None, script=SCRIPT)
    base = _default_state()
    if isinstance(st, dict):
        for k, v in st.items():
            base[k] = v
    for k in ("counts", "by_type", "health", "warnings_shown", "imports", "context_cost", "profile"):
        if not isinstance(base.get(k), dict):
            base[k] = dict(STATE_SKELETON.get(k) or {})
    for k in ("sessions_counted", "pending"):
        if not isinstance(base.get(k), list):
            base[k] = []
    if not isinstance(base.get("version"), str) or not re.fullmatch(r"\d+\.\d+\.\d+", base["version"]):
        base["version"] = "0.1.0"
    if not base.get("activated_at"):
        base["activated_at"] = common.now_iso()
    base["generation"] = _to_int(base.get("generation"), 0)
    return base


def _save_state(state):
    common.save_json(P["state"], state)


def load_index():
    idx = common.load_json(P["index_json"], None, script=SCRIPT)
    if isinstance(idx, dict) and isinstance(idx.get("postings"), dict) and isinstance(idx.get("docs"), list):
        return idx
    return None


def _load_cache(warnings):
    """docs.json: {rel: {mtime, size, hash, meta, head, tf, open, done, bare_at, invalid, collection, id}}."""
    existed = os.path.exists(P["docs_json"])
    c = common.load_json(P["docs_json"], None, script=SCRIPT)
    if not isinstance(c, dict):
        if existed:
            warnings.add("cache_regenerado")
        return {}
    return c


def _load_offsets(warnings):
    existed = os.path.exists(P["offsets_json"])
    o = common.load_json(P["offsets_json"], None, script=SCRIPT)
    if not isinstance(o, dict):
        if existed:
            warnings.add("cache_regenerado")
        return {"offset": 0, "prompts": {}}
    o.setdefault("offset", 0)
    o.setdefault("prompts", {})
    if not isinstance(o["prompts"], dict):
        o["prompts"] = {}
    o["offset"] = _to_int(o.get("offset"), 0)
    return o


# --------------------------------------------------------------------------- assinatura (passo 1)
def _signature():
    files = {}
    for path in common.list_docs():
        try:
            st = os.stat(path)
            files[_rel(path)] = [int(st.st_mtime), st.st_size]
        except Exception:
            continue
    sizes = {}
    for key in ("agenda", "prompts"):
        try:
            sizes[key] = os.path.getsize(P[key])
        except Exception:
            sizes[key] = 0
    try:
        sizes["template"] = int(os.stat(P["template"]).st_mtime)
    except Exception:
        sizes["template"] = 0
    try:
        sizes["config"] = int(os.stat(P["config"]).st_mtime)
    except Exception:
        sizes["config"] = 0
    return {"files": files, "sizes": sizes}


def _derived_signature():
    """Impressão dos derivados que o refino grava: corrompidos ou apagados → o caminho 'sem mudança' não vale."""
    sig = {}
    for key in ("docs_json", "index_json", "state"):
        try:
            st = os.stat(P[key])
            sig[key] = [int(st.st_mtime), st.st_size]
        except Exception:
            sig[key] = None
    return sig


def _panel_signature():
    """Batimentos e turn caches: quando só isso muda, apenas o painel é regravado."""
    sig = {}
    try:
        sig["heartbeats"] = os.path.getsize(P["heartbeats"])
    except Exception:
        sig["heartbeats"] = 0
    try:
        for name in sorted(os.listdir(P["cache"])):
            if name.startswith("turn-") and name.endswith(".json"):
                sig[name] = int(os.stat(os.path.join(P["cache"], name)).st_mtime)
    except Exception:
        pass
    return sig


# --------------------------------------------------------------------------- normalização (passo 3)
def _normalize(meta, body, path, collection, mtime, warnings):
    """Aplica §3.1. Devolve (meta_normalizado, body_normalizado). Nunca lança."""
    m = dict(meta or {})
    doc_id = common.doc_id_from_path(path)
    m["id"] = doc_id
    t = str(m.get("type") or "").strip().lower()
    type_invalid = False
    if t not in common.TYPES:
        if t:
            warnings.add("tipo_invalido:" + doc_id)
            type_invalid = True
            t = "fact"
        else:
            t = DEFAULT_TYPE_BY_COLLECTION.get(collection, "fact")
    m["type"] = t
    title = m.get("title")
    title = str(title).strip() if title is not None else ""
    if not title:
        title = _first_heading(body) or _first_sentence(body) or doc_id
    m["title"] = common.truncate(title, 160)
    tags = set(_tag_norm(x) for x in _as_list(m.get("tags")))
    tags.add(_tag_norm(t))
    project = m.get("project")
    project = common.slug(project) if project else None
    if project:
        m["project"] = project
        tags.add(project)
    elif "project" in m:
        m["project"] = None
    m["tags"] = sorted(x for x in tags if x and x != "sem-nome")
    conf = _to_float(m.get("confidence"), 0.7)
    m["confidence"] = round(min(1.0, max(0.0, conf)), 2)
    status = str(m.get("status") or "active").strip().lower()
    if status not in ("active", "superseded", "archived"):
        status = "active"
    m["status"] = status
    if status == "superseded" and "superseded_by" not in m:
        m["superseded_by"] = None
    if m.get("superseded_by") is not None:
        m["superseded_by"] = str(m["superseded_by"]).strip() or None
    links = _as_list(m.get("links"))
    for wl in _wikilinks(body):
        if wl and wl not in links:
            links.append(wl)
    if links or "links" in m:
        m["links"] = links
    if "supersedes" in m:
        sup = m.get("supersedes")
        m["supersedes"] = (str(sup).strip() or None) if sup not in (None, [], "") else None
        if isinstance(sup, list):
            m["supersedes"] = str(sup[0]).strip() if sup else None
    if m.get("pinned") is not None:
        m["pinned"] = bool(m.get("pinned")) if not isinstance(m.get("pinned"), str) else m["pinned"].lower() in ("true", "yes", "on", "1")
    else:
        m["pinned"] = False
    if m.get("session") is not None:
        m["session"] = common.sid8(m["session"])
    for key in ("files", "similar_to", "sources"):
        if key in m:
            m[key] = _as_list(m.get(key))
    if t == "project":
        sit = str(m.get("situation") or "idea").strip().lower()
        m["situation"] = sit if sit in SITUATIONS else "idea"
        m.setdefault("files", [])
    if t in ("profile", "project"):
        summ = m.get("summary")
        summ = str(summ).strip() if summ is not None else ""
        if not summ:
            summ = _first_sentence(body, 160) or m["title"]
        m["summary"] = common.truncate(re.sub(r"\s+", " ", summ), 160)
    elif m.get("summary") is not None:
        m["summary"] = common.truncate(re.sub(r"\s+", " ", str(m["summary"])), 160)
    created = m.get("created")
    if not created or not common.parse_iso(created):
        created = _iso_from_mtime(mtime)
    m["created"] = str(created)
    updated = m.get("updated")
    if not updated or not common.parse_iso(updated):
        updated = m["created"]
    m["updated"] = str(updated)
    m["version"] = max(1, _to_int(m.get("version"), 1))
    if collection == "perfil":
        body = common.escape_at(body)
        m["title"] = common.escape_at(m["title"])
        if m.get("summary"):
            m["summary"] = common.escape_at(m["summary"])
    m["hash"] = common.body_hash(body)
    return m, body, type_invalid


def _parse_doc(path, collection, cache_entry, deadline_unused, warnings, now):
    """Lê, normaliza, versiona e (se preciso) reescreve UM arquivo. Devolve a entrada nova do docs.json."""
    rel = _rel(path)
    doc_id = common.doc_id_from_path(path)
    try:
        st = os.stat(path)
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"file": rel})
        return None
    raw = common.read_text(path)
    if raw is None:
        return {"id": doc_id, "collection": collection, "mtime": st.st_mtime, "size": st.st_size, "hash": "",
                "meta": {}, "head": "", "tf": {}, "open": [], "done": [], "bare_at": False, "invalid": "ilegivel"}
    meta, body = common.read_frontmatter(raw)
    if meta is None:
        warnings.add("invalido:" + doc_id)
        return {"id": doc_id, "collection": collection, "mtime": st.st_mtime, "size": st.st_size, "hash": "",
                "meta": {}, "head": "", "tf": {}, "open": [], "done": [], "bare_at": False,
                "invalid": "frontmatter aberto sem fechar"}
    meta, body, type_invalid = _normalize(meta, body, path, collection, st.st_mtime, warnings)
    old_hash = None
    old_version = meta["version"]
    if isinstance(cache_entry, dict) and cache_entry.get("hash"):
        old_hash = cache_entry.get("hash")
        old_version = _to_int((cache_entry.get("meta") or {}).get("version"), old_version)
    seen_path = os.path.join(P["cache_texts"], doc_id + ".md")
    seen = common.read_text(seen_path)
    if old_hash and old_hash != meta["hash"]:
        # corpo mudou desde a última vez que o refinador o viu: versão anterior vai para .history/
        meta["version"] = max(meta["version"], old_version) + 1 if seen is not None else max(meta["version"], old_version + 1)
        meta["updated"] = now
    text = common.write_frontmatter(meta, body)
    if text != raw:
        try:
            common.write_atomic(path, text)
            st = os.stat(path)
        except Exception as e:
            common.log_error(SCRIPT, e, extra={"file": rel, "message": "nao consegui normalizar"})
    if seen != text:
        common.history_snapshot(doc_id, text, old_version)
    bare = bool(common.bare_at_lines(body)) if collection != "perfil" else False
    if bare:
        warnings.add("arroba_solto:" + doc_id)
    open_, done = _open_items(body) if meta["type"] == "project" else ([], [])
    head = re.sub(r"\s+", " ", body.strip())[:HEAD_CHARS]
    return {"id": doc_id, "collection": collection, "mtime": st.st_mtime, "size": st.st_size, "hash": meta["hash"],
            "meta": meta, "head": head, "tf": _doc_tf(meta, body), "open": open_, "done": done,
            "bare_at": bare, "type_invalid": type_invalid, "invalid": None}


def _doc_tf(meta, body):
    """tf_w = 3·título + 3·tags + 1·corpo(600) + 1,5·links (§3.8)."""
    w = collections.Counter()
    for term, n in _tf(meta.get("title") or "").items():
        w[term] += 3.0 * n
    for term, n in _tf(" ".join(meta.get("tags") or []), expand=False).items():
        w[term] += 3.0 * n
    for term, n in _tf((body or "")[:BODY_INDEX_CHARS]).items():
        w[term] += 1.0 * n
    links = list(meta.get("links") or [])
    if meta.get("project"):
        links.append(meta["project"])
    for term, n in _tf(" ".join(links), expand=False).items():
        w[term] += 1.5 * n
    return {k: round(v, 2) for k, v in w.items()}


def _rewrite_meta(entry, changes, now):
    """Reescreve o frontmatter de um doc já carregado (dedup/supersessão/similar_to). Corpo intacto."""
    path = _abs(entry["rel"])
    raw = common.read_text(path)
    if raw is None:
        return False
    meta, body = common.read_frontmatter(raw)
    if meta is None:
        return False
    meta.update(entry["meta"])
    meta.update(changes)
    entry["meta"].update(changes)
    text = common.write_frontmatter(meta, body)
    if text == raw:
        return False
    try:
        common.write_atomic(path, text)
        st = os.stat(path)
        entry["mtime"], entry["size"] = st.st_mtime, st.st_size
        seen = common.read_text(os.path.join(P["cache_texts"], entry["id"] + ".md"))
        if seen != text:
            common.history_snapshot(entry["id"], text, _to_int(meta.get("version"), 1))
        return True
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"file": entry["rel"]})
        return False


def _scan(cache, deadline, warnings, force_all=False):
    """Passos 2–3: lista os .md, reparseia só o que mudou. Devolve (docs_dict_por_rel, partial)."""
    now = common.now_iso()
    out = {}
    partial = False
    for path in common.list_docs():
        rel = _rel(path)
        col = common.collection_of(path)
        if not col:
            continue
        old = cache.get(rel)
        try:
            st = os.stat(path)
        except Exception:
            continue
        if (not force_all and isinstance(old, dict) and old.get("meta") is not None
                and abs(float(old.get("mtime") or 0) - st.st_mtime) < 1e-6 and old.get("size") == st.st_size
                and isinstance(old.get("tf"), dict)):
            entry = dict(old)
        else:
            if deadline.over():
                partial = True
                if isinstance(old, dict):
                    entry = dict(old)
                else:
                    continue
            else:
                entry = _parse_doc(path, col, old, deadline, warnings, now)
                if entry is None:
                    continue
        entry["rel"] = rel
        entry["collection"] = col
        entry["id"] = common.doc_id_from_path(path)
        out[rel] = entry
    return out, partial


def _valid(docs):
    return [d for d in docs.values() if not d.get("invalid") and isinstance(d.get("meta"), dict)]


def _by_id(docs):
    return dict((d["id"], d) for d in _valid(docs))


# --------------------------------------------------------------------------- dedup / supersessão / Jaccard
def _dedup(docs, now):
    groups = collections.defaultdict(list)
    for d in _valid(docs):
        if d.get("hash") and d["collection"] not in ("compactacoes", "relatorios"):
            groups[d["hash"]].append(d)
    dup = 0
    for h, items in groups.items():
        if len(items) < 2:
            continue
        items.sort(key=lambda d: (str(d["meta"].get("created") or ""), d["id"]))
        original = items[0]
        for d in items[1:]:
            dup += 1
            if d["meta"].get("status") == "superseded" and d["meta"].get("superseded_by") == original["id"]:
                continue
            links = list(d["meta"].get("links") or [])
            if original["id"] not in links:
                links.append(original["id"])
            _rewrite_meta(d, {"status": "superseded", "superseded_by": original["id"], "links": links}, now)
    return dup


def _supersede(docs, now):
    ids = _by_id(docs)
    n = 0
    for d in list(ids.values()):
        target = d["meta"].get("supersedes")
        if not target or target not in ids or target == d["id"]:
            continue
        t = ids[target]
        if t["meta"].get("status") == "superseded" and t["meta"].get("superseded_by") == d["id"]:
            continue
        if _rewrite_meta(t, {"status": "superseded", "superseded_by": d["id"]}, now):
            n += 1
    return n


def _jaccard(docs, deadline, now):
    """Só em --full: pares com >= 2 tags em comum ou mesma coleção+mês; Jaccard >= 0,85 -> similar_to."""
    valid = [d for d in _valid(docs) if d["meta"].get("status") == "active"]
    tokens = {}
    for d in valid:
        if deadline.over():
            return -1
        raw = common.read_text(_abs(d["rel"]))
        if raw is None:
            continue
        _, body = common.read_frontmatter(raw)
        tokens[d["id"]] = set(common.tokenize((d["meta"].get("title") or "") + " " + (body or ""), expand=False))
    by_tag = collections.defaultdict(list)
    by_bucket = collections.defaultdict(list)
    for d in valid:
        for t in d["meta"].get("tags") or []:
            by_tag[t].append(d["id"])
        by_bucket[(d["collection"], _month_part(d["meta"].get("created")))].append(d["id"])
    pair_tags = collections.Counter()
    for t, ids in by_tag.items():
        if len(ids) > 200:
            continue
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                pair_tags[(min(ids[i], ids[j]), max(ids[i], ids[j]))] += 1
    candidates = set(p for p, n in pair_tags.items() if n >= 2)
    for ids in by_bucket.values():
        if len(ids) > 300:
            continue
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                candidates.add((min(ids[i], ids[j]), max(ids[i], ids[j])))
    similar = collections.defaultdict(set)
    for a, b in candidates:
        if deadline.over():
            return -1
        ta, tb = tokens.get(a), tokens.get(b)
        if not ta or not tb:
            continue
        inter = len(ta & tb)
        union = len(ta | tb)
        if union and inter / float(union) >= 0.85:
            similar[a].add(b)
            similar[b].add(a)
    ids = _by_id(docs)
    for did, d in ids.items():
        if d["meta"].get("status") != "active":
            continue
        new = sorted(similar.get(did, set()))
        old = sorted(d["meta"].get("similar_to") or [])
        if new != old:
            if new or "similar_to" in d["meta"]:
                _rewrite_meta(d, {"similar_to": new}, now)
    return sum(1 for d in valid if similar.get(d["id"]))


# --------------------------------------------------------------------------- índice (passo 7)
def _index_prompts(offsets, deadline):
    """prompts.jsonl indexado a partir do offset salvo (offset > tamanho -> 0)."""
    path = P["prompts"]
    try:
        size = os.path.getsize(path)
    except Exception:
        size = 0
    off = offsets.get("offset", 0)
    if off > size:
        off = 0
        offsets["prompts"] = {}
    prompts = offsets["prompts"]
    if size > off:
        try:
            with io.open(path, "rb") as f:
                f.seek(off)
                pos = off
                while True:
                    line = f.readline()
                    if not line:
                        break
                    if not line.endswith(b"\n"):
                        break  # linha ainda sendo escrita: fica para a próxima
                    pos += len(line)
                    try:
                        obj = json.loads(line.decode("utf-8", errors="replace"))
                    except Exception:
                        continue
                    if not isinstance(obj, dict):
                        continue
                    pid = str(obj.get("prompt_id") or ("l%d" % pos))
                    terms = obj.get("terms")
                    if not isinstance(terms, list) or not terms:
                        terms = common.tokenize(obj.get("text") or "")
                    prompts[pid] = {"t": [str(x) for x in terms][:60], "c": _date_part(obj.get("ts")),
                                    "s": common.sid8(obj.get("session")), "h": common.truncate(common.redact(obj.get("text") or ""), 80)}
                    if deadline is not None and deadline.over():
                        break
                off = pos
        except Exception as e:
            common.log_error(SCRIPT, e, extra={"file": "memoria/log/prompts.jsonl"})
    if len(prompts) > MAX_PROMPT_DOCS:
        keep = sorted(prompts.items(), key=lambda kv: (kv[1].get("c") or "", kv[0]))[-MAX_PROMPT_DOCS:]
        offsets["prompts"] = dict(keep)
    offsets["offset"] = off
    return offsets


def _build_index_from(docs, offsets):
    doc_ids, meta, postings, lens = [], {}, collections.defaultdict(list), []
    for d in sorted(_valid(docs), key=lambda d: d["id"]):
        m = d["meta"]
        if m.get("status") != "active":
            continue
        idx = len(doc_ids)
        doc_ids.append(d["id"])
        tf = d.get("tf") or {}
        length = int(sum(1 for _ in tf)) or 1
        lens.append(length)
        meta[d["id"]] = {"collection": d["collection"], "type": m.get("type"), "title": m.get("title"),
                         "tags": m.get("tags") or [], "confidence": m.get("confidence", 0.7),
                         "created": _date_part(m.get("created")), "status": m.get("status"), "pinned": bool(m.get("pinned")),
                         "len": length, "project": m.get("project"), "situation": m.get("situation"),
                         "path": d["rel"], "head": common.truncate(d.get("head") or "", 200), "summary": m.get("summary"),
                         "links": m.get("links") or [], "open": d.get("open") or []}
        for term, w in tf.items():
            postings[term].append([idx, w])
    for pid, pr in sorted((offsets.get("prompts") or {}).items(), key=lambda kv: (kv[1].get("c") or "", kv[0])):
        did = "prompt:" + pid
        idx = len(doc_ids)
        doc_ids.append(did)
        terms = pr.get("t") or []
        lens.append(len(terms) or 1)
        meta[did] = {"collection": "prompts", "type": "prompt", "title": pr.get("h") or "", "tags": [], "confidence": 1.0,
                     "created": pr.get("c") or "", "status": "active", "pinned": False, "len": len(terms) or 1,
                     "session": pr.get("s"), "path": None, "head": ""}
        for term, n in collections.Counter(terms).items():
            postings[term].append([idx, float(n)])
    n = len(doc_ids)
    avgdl = (sum(lens) / float(n)) if n else 0.0
    return {"format": 1, "generated": common.now_iso(), "N": n, "avgdl": round(avgdl, 2), "docs": doc_ids,
            "meta": meta, "df": dict((t, len(p)) for t, p in postings.items()), "postings": dict(postings)}


def build_index(deadline=None, write=True):
    """Constrói o índice §3.8 a partir do docs.json (ou varrendo os .md se o cache faltar). Nunca lança."""
    try:
        dl = deadline if isinstance(deadline, Deadline) else Deadline(deadline)
        warnings = set()
        cache = _load_cache(warnings)
        docs, _ = _scan(cache, dl, warnings)
        offsets = _index_prompts(_load_offsets(warnings), dl)
        index = _build_index_from(docs, offsets)
        if write:
            common.save_json(P["index_json"], index)
            common.save_json(P["docs_json"], docs)
            common.save_json(P["offsets_json"], offsets)
        return index
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"message": "build_index"})
        return {"format": 1, "generated": common.now_iso(), "N": 0, "avgdl": 0.0, "docs": [], "meta": {}, "df": {}, "postings": {}}


# --------------------------------------------------------------------------- grafo (passo 8)
def _build_graph(docs):
    valid = _valid(docs)
    ids = dict((d["id"], d) for d in valid)
    nodes, edges = {}, []
    degree = collections.Counter()
    projects = dict((d["id"], d) for d in valid if d["collection"] == "projetos")
    for d in valid:
        m = d["meta"]
        nodes[d["id"]] = {"id": d["id"], "type": m.get("type"), "label": common.truncate(m.get("title") or d["id"], 90),
                          "collection": d["collection"], "degree": 0, "created": _date_part(m.get("created")),
                          "status": m.get("status"), "pinned": bool(m.get("pinned"))}
    for pid, d in projects.items():
        nodes["project:" + pid] = {"id": "project:" + pid, "type": "project", "label": common.truncate(d["meta"].get("title") or pid, 90), "degree": 0}
    tag_count = collections.Counter()
    for d in valid:
        if d["meta"].get("status") != "active":
            continue
        for t in set(d["meta"].get("tags") or []):
            tag_count[t] += 1
    for t, n in tag_count.items():
        if n >= 2:
            nodes["tag:" + t] = {"id": "tag:" + t, "type": "tag", "label": t, "degree": 0}

    def add(frm, to, typ, w):
        edges.append({"from": frm, "to": to, "type": typ, "weight": round(w, 3)})
        degree[frm] += 1
        degree[to] += 1

    linked = set()
    for d in sorted(valid, key=lambda d: d["id"]):
        m = d["meta"]
        if m.get("status") == "active":
            for l in sorted(set(m.get("links") or [])):
                if l in ids and l != d["id"]:
                    add(d["id"], l, "link", 1.0)
                    linked.add(d["id"]); linked.add(l)
                elif l in projects:
                    pass
            pr = m.get("project")
            if pr and pr in projects and pr != d["id"]:
                add(d["id"], "project:" + pr, "project", 0.8)
                linked.add(d["id"]); linked.add(pr)
            for t in sorted(set(m.get("tags") or [])):
                if ("tag:" + t) in nodes:
                    add(d["id"], "tag:" + t, "tag", 1.0 / tag_count[t])
        sup = m.get("supersedes")
        if sup and sup in ids and sup != d["id"]:
            add(d["id"], sup, "supersedes", 1.0)
    for nid, n in nodes.items():
        n["degree"] = degree.get(nid, 0)
    orphans = sorted(d["id"] for d in valid if d["meta"].get("status") == "active"
                     and d["collection"] not in ("compactacoes", "relatorios", "conhecimento", "origem", "perfil") and d["id"] not in linked)
    return {"generated": common.now_iso(), "nodes": [nodes[k] for k in sorted(nodes)], "edges": edges, "orphans": orphans}


# --------------------------------------------------------------------------- retrato (passo 9)
def _profile_sort(d):
    m = d["meta"]
    return (0 if m.get("pinned") else 1, -float(m.get("confidence") or 0), _neg_date(m.get("created")), d["id"])


class _neg_date(object):
    """Ordena datas ISO em ordem decrescente dentro de uma tupla (sem inverter o id)."""
    def __init__(self, iso):
        self.s = str(iso or "")

    def __lt__(self, other):
        return self.s > other.s

    def __eq__(self, other):
        return self.s == other.s


def _profile_docs(docs, typ):
    return sorted([d for d in _valid(docs) if d["meta"].get("status") == "active" and d["meta"].get("type") == typ
                   and d["collection"] in ("memorias", "perfil") and d["id"] not in ("marcelo", "retrato")], key=_profile_sort)


def _marcelo_summary(docs):
    ids = _by_id(docs)
    d = ids.get("marcelo")
    if d and d["meta"].get("summary"):
        return common.escape_at(str(d["meta"]["summary"]))
    return "(ainda sem resumo em memoria/perfil/marcelo.md)"


def _want_to_learn(docs):
    tags = set()
    for d in _valid(docs):
        m = d["meta"]
        if m.get("status") == "active" and m.get("type") in ("profile", "preference"):
            tags.update(m.get("tags") or [])
    out = []
    for question, triggers in PROFILE_GAPS:
        if not any(t in tags for t in triggers):
            out.append(question)
        if len(out) >= 3:
            break
    return out


def _build_retrato(docs, today):
    profiles = _profile_docs(docs, "profile")
    prefs = _profile_docs(docs, "preference")
    total = len(profiles) + len(prefs) + (1 if "marcelo" in _by_id(docs) else 0)
    today_items = [d for d in profiles + prefs if _date_part(d["meta"].get("created")) == today]
    today_items.sort(key=_profile_sort)
    want = _want_to_learn(docs)
    d_ddmm = common.fmt_ddmm(common.now_iso())
    L = ["# Retrato do Marcelo — compilado de %d memórias (atualizado %s)" % (total, d_ddmm), "", "## Quem ele é",
         common.truncate(_marcelo_summary(docs), 160)]
    for d in profiles[:6]:
        L.append(common.truncate(common.escape_at("- %s (%s)" % (d["meta"].get("title"), d["id"])), 160))
    L += ["", "## Como gosta de trabalhar"]
    for d in prefs[:6]:
        L.append(common.truncate(common.escape_at("- %s (%s)" % (d["meta"].get("title"), d["id"])), 160))
    if not prefs:
        L.append("- (nenhuma preferência registrada ainda)")
    L += ["", "## Aprendi hoje"]
    if today_items:
        for d in today_items[:3]:
            L.append(common.truncate(common.escape_at("- %s (%s)" % (d["meta"].get("title"), d["id"])), 160))
    else:
        L.append("- nada ainda hoje")
    L += ["", "## Ainda quero aprender"]
    for i, q in enumerate(want, 1):
        L.append("%d. %s" % (i, q))
    if not want:
        L.append("1. (as 10 lacunas de perfil já têm resposta)")
    body = "\n".join(L) + "\n"
    meta = {"id": "retrato", "type": "profile", "title": "Retrato do Marcelo (compilado)", "tags": ["perfil", "marcelo"],
            "source": "inference", "generated": common.now_iso()}
    text = common.write_frontmatter(meta, body)
    profile = {"summary": common.truncate(_marcelo_summary(docs), 300),
               "portrait": [common.truncate(common.escape_at(str(d["meta"].get("title"))), 120) for d in (profiles + prefs)[:12]],
               "learned_today": [common.truncate(str(d["meta"].get("title")), 120) for d in today_items[:3]],
               "want_to_learn": want}
    return text, profile


# --------------------------------------------------------------------------- estado (passo 10)
def _agenda_items():
    items = collections.OrderedDict()
    for ev in common.read_jsonl(P["agenda"]):
        if not isinstance(ev, dict) or not ev.get("id"):
            continue
        aid = str(ev["id"])
        if ev.get("event") == "new":
            items[aid] = {"id": aid, "when": _date_part(ev.get("when")), "text": common.truncate(common.redact(ev.get("text") or ""), 160),
                          "status": "open", "session": ev.get("session")}
        elif ev.get("event") == "done" and aid in items:
            items[aid]["status"] = "done"
        elif ev.get("event") == "done":
            items[aid] = {"id": aid, "when": "", "text": "", "status": "done"}
    return list(items.values())


def _session_stats():
    """Sessões distintas (sem init_only), última sessão real e ids init_only."""
    rows = common.read_jsonl(P["sessions"])
    init_only, distinct = set(), set()
    starts = {}
    ends = {}
    for r in rows:
        if not isinstance(r, dict) or not r.get("session"):
            continue
        sid = common.sid8(r["session"])
        if r.get("event") == "start":
            if r.get("init_only"):
                init_only.add(sid)
                continue
            distinct.add(sid)
            starts[sid] = r
        elif r.get("event") == "end":
            ends[sid] = r
    last = None
    order = [common.sid8(r["session"]) for r in rows if isinstance(r, dict) and r.get("event") == "start" and r.get("session")]
    for sid in reversed(order):
        if sid in init_only or sid not in starts:
            continue
        e = ends.get(sid)
        if e is not None and _to_int(e.get("prompts"), 0) == 0:
            continue
        s = starts[sid]
        summary = None
        ls = common.load_json(P["last_session"], None, script=SCRIPT)
        if isinstance(ls, dict) and common.sid8(ls.get("session")) == sid and ls.get("response_head"):
            summary = common.truncate(common.redact(ls.get("response_head")), 160)
        if not summary:
            for t in reversed(common.tail_jsonl(P["turns"], 16384)):
                if common.sid8(t.get("session")) == sid and t.get("response_head"):
                    summary = common.truncate(common.redact(t.get("response_head")), 160)
                    break
        last = {"id": sid, "start": s.get("ts"), "end": (e or {}).get("ts"), "source": s.get("source"), "summary": summary}
        break
    return {"count": len(distinct), "last": last, "init_only": init_only}


def _auto_memory_stats():
    path = os.path.join(P["auto_memory"], "MEMORY.md")
    try:
        txt = common.read_text(path)
        if txt is None:
            return 0, 0
        return txt.count("\n") + (1 if txt and not txt.endswith("\n") else 0), len(txt.encode("utf-8"))
    except Exception:
        return 0, 0


def _log_mb():
    total = 0
    try:
        for dp, dn, fn in os.walk(P["log"]):
            for f in fn:
                try:
                    total += os.path.getsize(os.path.join(dp, f))
                except Exception:
                    pass
    except Exception:
        pass
    return round(total / 1048576.0, 2)


def _context_cost(index_lines, cfg):
    claude = common.read_text(P["claude_md"]) or ""
    claude_lines = claude.count("\n") + (1 if claude and not claude.endswith("\n") else 0)
    chars = len(claude)
    rules_without = 0
    try:
        for f in sorted(os.listdir(P["rules"])):
            if not f.endswith(".md"):
                continue
            txt = common.read_text(os.path.join(P["rules"], f)) or ""
            meta, body = common.read_frontmatter(txt)
            if not meta or "paths" not in meta:
                rules_without += 1
                chars += len(body)
    except Exception:
        pass
    idx_txt = common.read_text(P["indice"]) or ""
    chars += len(idx_txt)
    desc_total, desc_max = 0, 0
    try:
        for name in sorted(os.listdir(P["skills"])):
            sk = os.path.join(P["skills"], name, "SKILL.md")
            txt = common.read_text(sk)
            if txt is None:
                continue
            meta, _ = common.read_frontmatter(txt)
            if not meta:
                continue
            dmi = meta.get("disable-model-invocation")
            if dmi is True or str(dmi).lower() == "true":
                continue
            n = len(str(meta.get("description") or ""))
            desc_total += n
            desc_max = max(desc_max, n)
    except Exception:
        pass
    recall_chars = 0
    rec = common.tail_jsonl(P["recalls"], 8192)
    if rec:
        vals = [_to_int(r.get("chars"), 0) for r in rec if isinstance(r, dict)]
        recall_chars = int(sum(vals) / float(len(vals))) if vals else 0
    return {"claude_md_lines": claude_lines, "index_lines": index_lines, "rules_without_paths": rules_without,
            "skill_descriptions_chars": desc_total, "skill_description_max_chars": desc_max,
            "tokens_per_session_est": int(chars / 4), "tokens_per_turn_est": int((desc_total + recall_chars) / 4)}


def _knowledge_age(docs):
    newest = None
    for d in _valid(docs):
        if d["collection"] == "conhecimento" and d["rel"].startswith(os.path.join("memoria", "conhecimento", "claude-code") + os.sep):
            u = d["meta"].get("updated") or d["meta"].get("created")
            if u and (newest is None or str(u) > str(newest)):
                newest = u
    if newest is None:
        return None
    dd = common.dias_desde(newest)
    return int(dd) if dd is not None else None


def _compute_counts(docs):
    valid = _valid(docs)
    act = [d for d in valid if d["meta"].get("status") == "active"]
    col = collections.Counter(d["collection"] for d in act)
    tags = set()
    for d in act:
        tags.update(d["meta"].get("tags") or [])
    by_type = collections.Counter(d["meta"].get("type") for d in act if d["collection"] in ("memorias", "perfil"))
    counts = {"memories": col.get("memorias", 0), "decisions": col.get("decisoes", 0), "projects": col.get("projetos", 0),
              "knowledge": col.get("conhecimento", 0), "compactions": col.get("compactacoes", 0),
              "reports": col.get("relatorios", 0), "prompts": common.count_jsonl(P["prompts"]), "sessions": 0,
              "tags": len(tags)}
    return counts, dict(sorted(by_type.items()))


def _pending(docs):
    out = []
    for d in sorted(_valid(docs), key=lambda d: d["id"]):
        m = d["meta"]
        if d["collection"] != "projetos" or m.get("status") != "active" or m.get("situation") == "delivered":
            continue
        since = _date_part(m.get("updated") or m.get("created"))
        for item in d.get("open") or []:
            out.append({"project": d["id"], "item": common.truncate(common.redact(item), 160), "since": since})
    return out


def _compute_state(state, docs, graph, cfg, extra, warnings, today):
    """Passo 10 sem a parte de versão (feita em run). Devolve o state atualizado no lugar."""
    counts, by_type = _compute_counts(docs)
    ss = _session_stats()
    counts["sessions"] = ss["count"]
    state["counts"] = counts
    state["by_type"] = by_type
    state["last_session"] = ss["last"]
    agenda = _agenda_items()
    open_items = [a for a in agenda if a["status"] == "open"]
    state["agenda_open"] = len(open_items)
    state["agenda_overdue"] = len([a for a in open_items if a.get("when") and a["when"] < today])
    state["pending"] = _pending(docs)
    if extra.get("profile") is not None:
        state["profile"] = extra["profile"]
    idx_txt = common.read_text(P["indice"]) or ""
    index_lines = idx_txt.count("\n") + (1 if idx_txt and not idx_txt.endswith("\n") else 0)
    index_bytes = len(idx_txt.encode("utf-8"))
    kage = _knowledge_age(docs)
    if kage is not None and kage > _to_int(cfg.get("knowledge_max_age_days"), 90):
        warnings.add("conhecimento_antigo")
    for w in (cfg.get("_warnings") or []):
        warnings.add(w)
    if index_lines > 120:
        warnings.add("indice_grande")
    if not os.path.exists(P["template"]):
        warnings.add("template_ausente")
    log_mb = _log_mb()
    if log_mb > 15:
        warnings.add("log_grande")
    for d in docs.values():
        if not isinstance(d, dict):
            continue
        did = d.get("id") or "?"
        if d.get("invalid"):
            warnings.add("invalido:" + did)
        if d.get("bare_at"):
            warnings.add("arroba_solto:" + did)
        if d.get("type_invalid"):
            warnings.add("tipo_invalido:" + did)
    old_health = state.get("health") if isinstance(state.get("health"), dict) else {}
    kept = [w for w in (old_health.get("warnings") or []) if isinstance(w, str) and not w.startswith(OWN_WARNING_PREFIXES)]
    am_lines, am_bytes = _auto_memory_stats()
    invalid = [d["id"] for d in docs.values() if d.get("invalid")]
    health = {"orphans": len(graph.get("orphans") or []) if graph else _to_int(old_health.get("orphans"), 0),
              "duplicates": _to_int(extra.get("duplicates"), _to_int(old_health.get("duplicates"), 0)),
              "similar": _to_int(extra.get("similar"), _to_int(old_health.get("similar"), 0)),
              "invalid": len(invalid), "index_lines": index_lines, "index_bytes": index_bytes,
              "index_max_lines": _to_int(cfg.get("index_max_lines"), 150), "log_mb": log_mb,
              "auto_memory_lines": am_lines, "auto_memory_bytes": am_bytes, "knowledge_age_days": kage,
              "minor_pending": bool(old_health.get("minor_pending")) if extra.get("minor_pending") is None else bool(extra.get("minor_pending")),
              "warnings": sorted(set(kept) | set(warnings))}
    if old_health.get("snapshot_pending"):
        health["snapshot_pending"] = True
    state["health"] = health
    state["context_cost"] = _context_cost(index_lines, cfg)
    last = common.load_json(os.path.join(P["backups"], "last.json"), None, script=SCRIPT)
    if isinstance(last, dict) and last.get("ts"):
        state["last_snapshot"] = last.get("ts")
    state["paused"] = common.paused()
    return state


# --------------------------------------------------------------------------- INDICE (passo 11)
def _item_line(d, with_date=True):
    m = d["meta"]
    typ = common.label_type(m.get("type"))
    conf = m.get("confidence")
    tags = [t for t in (m.get("tags") or []) if t != _tag_norm(m.get("type") or "")][:6]
    parts = []
    if with_date:
        parts.append(common.fmt_ddmm(m.get("created")))
    parts.append("[%s %.1f]" % (typ, float(conf if conf is not None else 0.7)))
    parts.append(common.truncate(str(m.get("title") or d["id"]), 110))
    line = "- " + " ".join(parts)
    if tags:
        line += " — " + ", ".join(tags)
    line += " (%s)" % d["id"]
    return common.escape_at(line)


def _decision_line(d):
    m = d["meta"]
    return common.escape_at("- %s · %s (%s)" % (_date_part(m.get("created")), common.truncate(str(m.get("title") or d["id"]), 120), d["id"]))


def _project_line(d):
    m = d["meta"]
    sit = SITUATION_LABELS.get(m.get("situation"), m.get("situation") or "ideia")
    line = "- **%s** (%s) — %s" % (d["id"], sit, common.truncate(str(m.get("summary") or m.get("title") or ""), 120))
    if d.get("open"):
        line += " · próximo: " + common.truncate(d["open"][0], 80)
    files = m.get("files") or []
    if files:
        line += " · " + common.truncate(str(files[0]), 80)
    return common.escape_at(line)


def _know_key(d):
    topic = d["meta"].get("topic")
    if not topic:
        parts = d["rel"].split(os.sep)
        topic = parts[2] if len(parts) > 3 else "geral"
    short = d["id"]
    if short.startswith(str(topic) + "-"):
        short = short[len(str(topic)) + 1:]
    return "%s/%s" % (topic, short)


def _knowledge_line(d):
    return common.escape_at("- [conhecimento] %s — %s (%s)" % (_know_key(d), common.truncate(str(d["meta"].get("title") or ""), 100), d["id"]))


def _pinned_line(d):
    m = d["meta"]
    return common.escape_at("- [%s] %s (%s) — %s" % (common.label_type(m.get("type")), common.truncate(str(m.get("title") or ""), 110), d["id"], d["rel"]))


def _agenda_line(a):
    return common.escape_at("- %s · %s (%s)" % (common.fmt_ddmm(a.get("when")) if a.get("when") else "sem data", a.get("text") or "", a["id"]))


def _header(state, active_mem, projects_open, pending_n, ts):
    return ["<!-- gerado por motor/refine.py em %s — não edite; use /lembrar, /esquecer e /evoluir -->" % ts,
            "# Índice vivo do Gabriel — v%s · geração %s · %d memória%s ativa%s · %d projeto%s · %d pendência%s"
            % (state.get("version"), state.get("generation"), active_mem, "" if active_mem == 1 else "s", "" if active_mem == 1 else "s",
               projects_open, "" if projects_open == 1 else "s", pending_n, "" if pending_n == 1 else "s")]


def _sorted_desc(items, key_iso, tiebreak=lambda d: d["id"]):
    return sorted(items, key=lambda d: (_neg_date(key_iso(d)), tiebreak(d)))


def _fix_at(text):
    """Verificação final determinística: qualquer @ solto que sobrou vira (at)."""
    lines = text.split("\n")
    for n in common.bare_at_lines(text):
        i = n - 1
        if 0 <= i < len(lines):
            lines[i] = re.sub(r"(^|[^`])@(?=[^ `])", lambda m: m.group(1) + "(at)", lines[i])
    return "\n".join(lines)


def _render_indice(state, docs, agenda, cfg, retrato_summary, ts):
    valid = _valid(docs)
    act = [d for d in valid if d["meta"].get("status") == "active"]
    mem = [d for d in act if d["collection"] == "memorias"]
    projects = [d for d in act if d["collection"] == "projetos"]
    projects_open = [d for d in projects if d["meta"].get("situation") != "delivered"]
    order = {"in-progress": 0, "idea": 1, "paused": 2, "delivered": 3}
    projects_open.sort(key=lambda d: (order.get(d["meta"].get("situation"), 9), _neg_date(d["meta"].get("updated")), d["id"]))
    pending = state.get("pending") or []
    open_ag = [a for a in agenda if a["status"] == "open"]
    today = common.today()
    overdue = [a for a in open_ag if a.get("when") and a["when"] < today]
    upcoming = [a for a in open_ag if a not in overdue]
    overdue.sort(key=lambda a: (a.get("when") or "", a["id"]))
    upcoming.sort(key=lambda a: (a.get("when") or "9999", a["id"]))

    sec = collections.OrderedDict()
    prof = [d for d in mem if d["meta"].get("type") in ("profile", "preference")]
    prof.sort(key=_profile_sort)
    ret = ["## Marcelo (retrato · atualizado %s)" % common.fmt_ddmm(ts),
           common.truncate(common.escape_at(retrato_summary), 300) + " Detalhes: memoria/perfil/marcelo.md"]
    for d in prof[:6]:
        ret.append(common.escape_at("- [%s %.1f] %s (%s)" % (common.label_type(d["meta"].get("type")), float(d["meta"].get("confidence") or 0.7),
                                                             common.truncate(str(d["meta"].get("title")), 110), d["id"])))
    sec["retrato"] = ret
    pr = ["## Projetos abertos"] + [_project_line(d) for d in projects_open]
    if not projects_open:
        pr.append("- (nenhum projeto aberto)")
    sec["projetos"] = pr
    decisions = [d for d in act if d["collection"] == "decisoes"]
    dec_pinned = _sorted_desc([d for d in decisions if d["meta"].get("pinned")], lambda d: d["meta"].get("created"))
    dec_recent = _sorted_desc([d for d in decisions if not d["meta"].get("pinned")], lambda d: d["meta"].get("created"))[:5]
    sec["decisoes"] = ["## Decisões que valem (fixadas + 5 últimas)"] + [_decision_line(d) for d in dec_pinned + dec_recent]
    pinned = _sorted_desc([d for d in act if d["meta"].get("pinned") and d["collection"] in ("memorias", "origem", "conhecimento", "relatorios", "compactacoes")],
                          lambda d: d["meta"].get("created"))
    sec["fixadas"] = ["## Memórias fixadas"] + [_pinned_line(d) for d in pinned]
    shown = set(d["id"] for d in prof[:6]) | set(d["id"] for d in pinned)
    recent_pool = [d for d in mem if d["id"] not in shown and float(d["meta"].get("confidence") or 0.7) >= 0.4]
    recent = _sorted_desc(recent_pool, lambda d: d["meta"].get("created"))[:15]
    sec["recentes"] = ["## Memórias recentes (%d)" % len(recent)] + [_item_line(d) for d in recent]
    know = [d for d in act if d["collection"] == "conhecimento" and not d["meta"].get("pinned")]
    know.sort(key=lambda d: (d["rel"], d["id"]))
    sec["conhecimento"] = ["## Conhecimento (%d) — detalhes em memoria/conhecimento/" % len(know)] + [_knowledge_line(d) for d in know]
    pend = ["## Pendências e agenda (abertas: %d · vencidas: %d)" % (len(open_ag), len(overdue))]
    pend += [common.escape_at("- [ ] %s: %s" % (p["project"], p["item"])) for p in pending]
    pend += [_agenda_line(a) for a in overdue + upcoming]
    sec["pendencias"] = pend
    outside = len([d for d in mem if d["id"] not in shown and d not in recent]) + len([d for d in valid if d["collection"] == "memorias" and d["meta"].get("status") != "active"])

    max_lines = _to_int(cfg.get("index_max_lines"), 150)
    max_chars = _to_int(cfg.get("index_max_chars"), 12000)
    cut_order = ["conhecimento", "recentes", "decisoes", "pendencias"]
    cut_count = collections.Counter()

    def assemble():
        L = _header(state, len(mem), len(projects_open), len(pending), ts)
        for k, lines in sec.items():
            L.append("")
            L.extend(lines)
        L.append("")
        L.append("_+ %d memórias fora deste índice (confiança < 0.4 ou superadas) — `/consultar <tema>` acha tudo._" % (outside + cut_count["recentes"]))
        return "\n".join(L) + "\n"

    text = assemble()
    while (text.count("\n") > max_lines or len(text.encode("utf-8")) > max_chars):
        cut = False
        for k in cut_order:
            if len(sec[k]) > 1:
                sec[k].pop()
                cut_count[k] += 1
                cut = True
                break
        if not cut:
            break
        if cut_count["conhecimento"]:
            sec["conhecimento"][0] = "## Conhecimento (%d de %d) — detalhes em memoria/conhecimento/" % (len(sec["conhecimento"]) - 1, len(know))
        if cut_count["recentes"]:
            sec["recentes"][0] = "## Memórias recentes (%d)" % (len(sec["recentes"]) - 1)
        text = assemble()
    return _fix_at(text)


def _render_completo(state, docs, agenda, retrato_text, ts):
    valid = _valid(docs)
    act = [d for d in valid if d["meta"].get("status") == "active"]
    mem = [d for d in act if d["collection"] == "memorias"]
    projects = [d for d in act if d["collection"] == "projetos"]
    projects_open = [d for d in projects if d["meta"].get("situation") != "delivered"]
    pending = state.get("pending") or []
    L = _header(state, len(mem), len(projects_open), len(pending), ts)
    L += ["", "## Marcelo (retrato)"]
    _, rbody = common.read_frontmatter(retrato_text)
    L += [("#" + l if l.startswith("## ") else l) for l in (rbody or "").rstrip("\n").split("\n") if not l.startswith("# ")]
    order = {"in-progress": 0, "idea": 1, "paused": 2, "delivered": 3}
    L += ["", "## Projetos"]
    for d in sorted(projects, key=lambda d: (order.get(d["meta"].get("situation"), 9), _neg_date(d["meta"].get("updated")), d["id"])):
        L.append(_project_line(d))
    L += ["", "## Decisões"]
    for d in _sorted_desc([d for d in act if d["collection"] == "decisoes"], lambda d: d["meta"].get("created")):
        L.append(_decision_line(d))
    L += ["", "## Memórias ativas"]
    for typ in MEMORY_TYPE_ORDER + [t for t in common.TYPES if t not in MEMORY_TYPE_ORDER]:
        group = _sorted_desc([d for d in mem if d["meta"].get("type") == typ], lambda d: d["meta"].get("created"))
        if not group:
            continue
        L.append("### %s (%d)" % (common.label_type(typ), len(group)))
        L += [_item_line(d) for d in group]
    know = [d for d in act if d["collection"] == "conhecimento"]
    L += ["", "## Conhecimento (%d)" % len(know)]
    for d in sorted(know, key=lambda d: (d["rel"], d["id"])):
        L.append(common.escape_at("- %s — %s (%s) · %s" % (_know_key(d), common.truncate(str(d["meta"].get("title") or ""), 100), d["id"], _date_part(d["meta"].get("created")))))
    L += ["", "## Compactações"]
    for d in _sorted_desc([d for d in act if d["collection"] == "compactacoes"], lambda d: d["meta"].get("created")):
        L.append(common.escape_at("- %s (%s)" % (common.truncate(str(d["meta"].get("title") or ""), 110), d["id"])))
    L += ["", "## Relatórios"]
    for d in _sorted_desc([d for d in act if d["collection"] == "relatorios"], lambda d: d["meta"].get("created")):
        L.append(common.escape_at("- %s (%s)" % (common.truncate(str(d["meta"].get("title") or ""), 110), d["id"])))
    L += ["", "## Superadas e arquivadas"]
    for d in sorted([d for d in valid if d["meta"].get("status") != "active"], key=lambda d: d["id"]):
        L.append(common.escape_at("- %s → superseded_by: %s" % (d["id"], d["meta"].get("superseded_by") or "—")))
    open_ag = [a for a in agenda if a["status"] == "open"]
    today = common.today()
    overdue = sorted([a for a in open_ag if a.get("when") and a["when"] < today], key=lambda a: (a["when"], a["id"]))
    rest = sorted([a for a in open_ag if a not in overdue], key=lambda a: (a.get("when") or "9999", a["id"]))
    L += ["", "## Pendências e agenda (abertas: %d · vencidas: %d)" % (len(open_ag), len(overdue))]
    L += [common.escape_at("- [ ] %s: %s" % (p["project"], p["item"])) for p in pending]
    L += [_agenda_line(a) for a in overdue + rest]
    return _fix_at("\n".join(L) + "\n")


# --------------------------------------------------------------------------- versão / mutações
def _bump(version, part):
    try:
        ma, mi, pa = [int(x) for x in version.split(".")]
    except Exception:
        ma, mi, pa = 0, 1, 0
    if part == "major":
        return "%d.0.0" % (ma + 1)
    if part == "minor":
        return "%d.%d.0" % (ma, mi + 1)
    return "%d.%d.%d" % (ma, mi, pa + 1)


def _diff_docs(old_cache, docs):
    old = {}
    for rel, e in (old_cache or {}).items():
        if isinstance(e, dict) and e.get("hash") and isinstance(e.get("meta"), dict):
            old[e.get("id") or common.doc_id_from_path(rel)] = (e.get("hash"), (e.get("meta") or {}).get("status"))
    new, changed, superseded = [], [], []
    for d in sorted(_valid(docs), key=lambda d: d["id"]):
        st = d["meta"].get("status")
        if d["id"] not in old:
            new.append(d["id"])
            continue
        oh, os_ = old[d["id"]]
        if oh != d["hash"]:
            changed.append(d["id"])
        if st == "superseded" and os_ != "superseded":
            superseded.append(d["id"])
    return new, changed, superseded


def _mutation(state, before, after, trigger, session, new, changed, superseded, reason, sessions=None):
    obj = {"ts": common.now_iso(), "trigger": trigger, "session": session, "version_before": before, "version_after": after,
           "generation": state.get("generation"), "new": new[:50], "changed": changed[:50], "superseded": superseded[:50], "reason": reason}
    if sessions:
        obj["sessions"] = sessions
    common.append_jsonl(P["mutations"], obj, max_chars=4000)


def _count_sessions(state, docs, current, init_only):
    """Bump de minor por lote (§3.6/§11.4): sessões com docs ainda não contadas."""
    counted = set(str(s) for s in (state.get("sessions_counted") or []))
    per = collections.Counter()
    for d in _valid(docs):
        if d["collection"] not in ("memorias", "decisoes", "projetos"):
            continue
        s = d["meta"].get("session")
        if not s or s == "unknown":
            continue
        s = common.sid8(s)
        if s in counted or s == current or s in init_only:
            continue
        per[s] += 1
    return dict(per)


def _panel():
    try:
        import panel
        return bool(panel.generate())
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"message": "panel.generate"})
        return False


# --------------------------------------------------------------------------- run
def run(mode, trigger=None, report=False, reason=None, count_sessions=False, mark_session_start=False, session=None, quiet=False):
    """Executa um refino. mode: quick | full | major | state-only. Devolve um resumo (dict). Nunca lança."""
    t0 = time.monotonic()
    session = common.sid8(session) if session else common.sid8(common.session_id_fallback())
    trigger = trigger or mode
    summary = {"mode": mode, "skipped": False, "partial": False, "changed": False}
    try:
        common.ensure_dirs()
        cfg = common.load_config()
        if mode == "state-only":
            return _run_state_only(cfg, trigger, session, count_sessions, mark_session_start, summary, t0, quiet)
        quick = mode == "quick"
        deadline = Deadline(DEADLINE_QUICK if quick else DEADLINE_FULL)
        sig_now = _signature()
        psig_now = _panel_signature()
        if quick:
            old_sig = common.load_json(P["signature_json"], None, script=SCRIPT)
            if isinstance(old_sig, dict) and old_sig.get("files") == sig_now["files"] and old_sig.get("sizes") == sig_now["sizes"] \
                    and old_sig.get("derived") == _derived_signature() and os.path.exists(P["index_json"]) and os.path.exists(P["state"]):
                if old_sig.get("panel") != psig_now:
                    if _panel():
                        old_sig["panel"] = psig_now
                        common.save_json(P["signature_json"], old_sig)
                summary.update({"ms": int((time.monotonic() - t0) * 1000), "unchanged": True})
                return summary
        with common.exclusive_lock("refine", wait=0.5 if quick else 0.0) as ok:
            if not ok:
                summary["skipped"] = True
                common.append_jsonl(P["refinements"], {"ts": common.now_iso(), "session": session, "mode": mode, "trigger": trigger,
                                                       "ms": int((time.monotonic() - t0) * 1000), "skipped": True})
                if not quiet:
                    print("refino pulado: outro refino em andamento")
                return summary
            return _run_locked(mode, cfg, deadline, sig_now, psig_now, trigger, session, report, reason, summary, t0, quiet)
    except BaseException as e:
        common.log_error(SCRIPT, e, extra={"message": "run " + str(mode)})
        summary["error"] = type(e).__name__
        return summary


def _run_locked(mode, cfg, deadline, sig_now, psig_now, trigger, session, report, reason, summary, t0, quiet):
    quick = mode == "quick"
    today = common.today()
    now = common.now_iso()
    warnings = set()
    state = load_state()
    old_cache = _load_cache(warnings)
    old_sig = common.load_json(P["signature_json"], None, script=SCRIPT)
    if os.path.exists(P["signature_json"]) and not isinstance(old_sig, dict):
        warnings.add("cache_regenerado")
    before = {"version": state.get("version"), "memories": (state.get("counts") or {}).get("memories", 0),
              "orphans": (state.get("health") or {}).get("orphans", 0), "similar": (state.get("health") or {}).get("similar", 0),
              "index_lines": (state.get("health") or {}).get("index_lines", 0)}
    # passos 2–3
    docs, partial = _scan(old_cache, deadline, warnings)
    # passos 4–5
    dup = _dedup(docs, now)
    _supersede(docs, now)
    similar = None
    if mode in ("full", "major") and not deadline.over():
        similar = _jaccard(docs, deadline, now)
        if similar is not None and similar < 0:
            similar = None
            partial = True
    # passo 7
    offsets = _index_prompts(_load_offsets(warnings), deadline)
    index = _build_index_from(docs, offsets)
    common.save_json(P["index_json"], index)
    common.save_json(P["docs_json"], docs)
    common.save_json(P["offsets_json"], offsets)
    new, changed, superseded = _diff_docs(old_cache, docs)
    if not old_cache and _to_int(state.get("generation"), 0) > 0:
        # cache ausente/ilegível fora da primeira ativação (rebuild, corrupção): a linha de base é refeita
        # sem bump — a versão semântica nunca é recomputada de trás para frente (§11.12)
        new, changed, superseded = [], [], []
    version_before = state.get("version")
    if new or changed or superseded or mode == "major":
        if mode == "major":
            state["version"] = _bump(state["version"], "major")
        else:
            state["version"] = _bump(state["version"], "patch")
        state["generation"] = _to_int(state.get("generation"), 0) + 1
        summary["changed"] = True
    if deadline.over():
        partial = True
    graph = None
    retrato_text, profile = None, None
    indice_written = False
    if not partial:
        # passo 8
        graph = _build_graph(docs)
        common.save_json(P["graph"], graph)
        # passo 9
        retrato_text, profile = _build_retrato(docs, today)
        common.write_if_changed(P["retrato"], retrato_text, ignore_line_prefix="generated:")
    # passo 10
    extra = {"duplicates": dup, "similar": similar, "profile": profile}
    _compute_state(state, docs, graph, cfg, extra, warnings, today)
    if partial:
        state["health"]["warnings"] = sorted(set(state["health"].get("warnings") or []) | {"refino_parcial"})
    agenda = _agenda_items()
    if not partial:
        # passo 11
        ts = common.now_iso()
        indice = _render_indice(state, docs, agenda, cfg, state.get("profile", {}).get("summary") or _marcelo_summary(docs), ts)
        indice_written = common.write_if_changed(P["indice"], indice, ignore_line_prefix="<!-- gerado por")
        completo = _render_completo(state, docs, agenda, retrato_text, ts)
        common.write_if_changed(P["indice_completo"], completo, ignore_line_prefix="<!-- gerado por")
        idx_txt = indice
        state["health"]["index_lines"] = idx_txt.count("\n")
        state["health"]["index_bytes"] = len(idx_txt.encode("utf-8"))
        state["context_cost"]["index_lines"] = state["health"]["index_lines"]
    ms = int((time.monotonic() - t0) * 1000)
    state["last_refinement"] = {"ts": now, "mode": mode, "ms": ms, "partial": bool(partial)}
    if mode in ("full", "major") and not partial:
        state["last_full_refinement"] = now
    if summary["changed"]:
        _mutation(state, version_before, state["version"], trigger, session, new, changed, superseded, reason)
    _save_state(state)
    if mode == "major":
        common.run_motor("snapshot.py", ["create", "--reason", "evolve"], timeout=15.0)
        last = common.load_json(os.path.join(P["backups"], "last.json"), None, script=SCRIPT)
        if isinstance(last, dict) and last.get("ts"):
            state["last_snapshot"] = last["ts"]
            _save_state(state)
    # passo 12
    if not partial:
        _panel()
    # passo 13 (assinatura recalculada depois das escritas: a normalização muda mtimes)
    sig_now = _signature()
    sig_now["panel"] = _panel_signature()
    sig_now["derived"] = _derived_signature()
    if not partial:
        common.save_json(P["signature_json"], sig_now)
    else:
        try:
            os.unlink(P["signature_json"])
        except Exception:
            pass
    ms = int((time.monotonic() - t0) * 1000)
    line = {"ts": common.now_iso(), "session": session, "mode": mode, "trigger": trigger, "ms": ms, "docs": len(docs), "new": len(new),
            "changed": len(changed), "superseded": len(superseded), "version": state["version"],
            "index_lines": state["health"].get("index_lines"), "partial": bool(partial)}
    common.append_jsonl(P["refinements"], line)
    summary.update({"ms": ms, "partial": bool(partial), "docs": len(docs), "new": new, "changed_ids": changed, "superseded": superseded,
                    "version": state["version"], "generation": state["generation"], "index_lines": state["health"].get("index_lines"),
                    "indice_written": indice_written, "duplicates": dup, "similar": similar, "orphans": state["health"].get("orphans")})
    if report and not quiet:
        print(_report_text(before, state, new, changed, superseded, similar, ms, partial))
    elif not quiet:
        print("refino %s %d ms · v%s · %d docs · +%d novas · %d alteradas · %d superadas%s"
              % (mode, ms, state["version"], len(docs), len(new), len(changed), len(superseded), " · PARCIAL" if partial else ""))
    return summary


def _report_text(before, state, new, changed, superseded, similar, ms, partial):
    c = state.get("counts") or {}
    h = state.get("health") or {}
    L = ["Refino completo em %d ms%s" % (ms, " (parcial: o resto fica para a manutenção)" if partial else ""),
         "- versão: %s → %s (geração %s)" % (before["version"], state["version"], state.get("generation")),
         "- memórias ativas: %s → %s · decisões %s · projetos %s · conhecimento %s" % (before["memories"], c.get("memories"), c.get("decisions"), c.get("projects"), c.get("knowledge")),
         "- novas: %d · alteradas: %d · superadas: %d" % (len(new), len(changed), len(superseded)),
         "- similares: %s → %s · órfãs: %s → %s · duplicatas: %s · inválidas: %s" % (before["similar"], h.get("similar"), before["orphans"], h.get("orphans"), h.get("duplicates"), h.get("invalid")),
         "- índice: %s → %s linhas (%s bytes) · limite %s" % (before["index_lines"], h.get("index_lines"), h.get("index_bytes"), h.get("index_max_lines"))]
    if h.get("warnings"):
        L.append("- avisos: " + ", ".join(h["warnings"]))
    for i in new[:10]:
        L.append("  + " + i)
    for i in changed[:10]:
        L.append("  ~ " + i)
    for i in superseded[:10]:
        L.append("  x " + i)
    return "\n".join(L)


def _run_state_only(cfg, trigger, session, count_sessions, mark_session_start, summary, t0, quiet):
    wait = 2.0 if count_sessions else 0.0
    with common.exclusive_lock("refine", wait=wait) as ok:
        if not ok:
            summary["skipped"] = True
            if count_sessions:
                def _flag(o):
                    o.setdefault("health", {})
                    if isinstance(o["health"], dict):
                        o["health"]["minor_pending"] = True
                common.update_json_locked(P["state"], _flag, default=_default_state(), script=SCRIPT)
            common.append_jsonl(P["refinements"], {"ts": common.now_iso(), "session": session, "mode": "state-only", "trigger": trigger,
                                                   "ms": int((time.monotonic() - t0) * 1000), "skipped": True})
            if not quiet:
                print("estado: refinador ocupado" + (" (minor pendente)" if count_sessions else ""))
            return summary
        warnings = set()
        state = load_state()
        docs = _load_cache(warnings)
        if not docs and common.list_docs():
            # cache ausente/ilegível: varre os .md (deadline curto) para o estado não sair zerado
            docs, _ = _scan({}, Deadline(2.5), warnings)
            common.save_json(P["docs_json"], docs)
        for rel, e in list(docs.items()):
            if isinstance(e, dict):
                e.setdefault("rel", rel)
                e.setdefault("id", common.doc_id_from_path(rel))
                e.setdefault("collection", common.collection_of(_abs(rel)) or "memorias")
            else:
                docs.pop(rel, None)
        graph = common.load_json(P["graph"], None, script=SCRIPT)
        if not isinstance(graph, dict):
            graph = None
        extra = {"minor_pending": None}
        sessions_hit = {}
        version_before = state.get("version")
        if count_sessions:
            ss = _session_stats()
            sessions_hit = _count_sessions(state, docs, session, ss["init_only"])
            if sessions_hit:
                state["version"] = _bump(state["version"], "minor")
                state["generation"] = _to_int(state.get("generation"), 0) + 1
                state["sessions_counted"] = sorted(set(str(s) for s in (state.get("sessions_counted") or [])) | set(sessions_hit))
                summary["changed"] = True
            extra["minor_pending"] = False
        _compute_state(state, docs, graph, cfg, extra, warnings, common.today())
        if mark_session_start:
            cs = dict(state.get("counts") or {})
            cs.update({"ts": common.now_iso(), "session": session})
            state["counts_at_session_start"] = cs
        ms = int((time.monotonic() - t0) * 1000)
        if summary["changed"]:
            sess = sorted(sessions_hit)
            total = sum(sessions_hit.values())
            _mutation(state, version_before, state["version"], "SessionStart", session, [], [], [],
                      "sessões %s deixaram %d memória%s" % (", ".join(sess), total, "" if total == 1 else "s"), sessions=sess)
        _save_state(state)
        _panel()
        common.append_jsonl(P["refinements"], {"ts": common.now_iso(), "session": session, "mode": "state-only", "trigger": trigger, "ms": ms,
                                               "docs": len(docs), "new": 0, "superseded": 0, "version": state["version"],
                                               "index_lines": (state.get("health") or {}).get("index_lines"), "partial": False,
                                               "sessions_counted": sorted(sessions_hit) if sessions_hit else []})
        summary.update({"ms": ms, "version": state["version"], "generation": state["generation"], "sessions": sorted(sessions_hit)})
        if not quiet:
            print("estado v%s · geração %s%s" % (state["version"], state["generation"],
                                                 (" · minor +1 (sessões %s)" % ", ".join(sorted(sessions_hit))) if sessions_hit else ""))
        return summary


# --------------------------------------------------------------------------- CLI
def main(argv):
    mode = None
    trigger = None
    report = False
    reason = None
    count_sessions = False
    mark = False
    session = None
    quiet = False
    as_json = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--quick":
            mode = "quick"
        elif a == "--full":
            mode = "full"
        elif a == "--major":
            mode = "major"
            if i + 1 < len(argv) and not argv[i + 1].startswith("--"):
                i += 1
                reason = argv[i]
        elif a == "--state-only":
            mode = "state-only"
        elif a == "--report":
            report = True
        elif a == "--count-sessions":
            count_sessions = True
        elif a == "--mark-session-start":
            mark = True
        elif a == "--session" and i + 1 < len(argv):
            i += 1
            session = argv[i]
        elif a == "--trigger" and i + 1 < len(argv):
            i += 1
            trigger = argv[i]
        elif a == "--quiet":
            quiet = True
        elif a == "--json":
            as_json = True
        i += 1
    if mode is None:
        mode = "quick"
    if mode == "major" and not reason:
        reason = "evolução maior pedida pelo Marcelo"
    r = run(mode, trigger=trigger, report=report, reason=reason, count_sessions=count_sessions,
            mark_session_start=mark, session=session, quiet=quiet or as_json)
    if as_json:
        print(json.dumps(r, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BaseException as e:
        common.log_error(SCRIPT, e)
    sys.exit(0)
