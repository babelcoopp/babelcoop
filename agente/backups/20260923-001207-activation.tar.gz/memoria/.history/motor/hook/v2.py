#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
hook.py — o ÚNICO gancho do organismo Gabriel (babel-os). Spec §4 e §11.2.

Contrato:
- lê o JSON inteiro do stdin (sem limite); PAUSA → sai 0 sem logar nada;
- `--maintenance` → motor/maintenance.py (limite 60 s) e sai;
- registra UMA linha por evento em memoria/log/events.jsonl (formato §3.3);
- despacha por hook_event_name (16 eventos de §4);
- stdout vazio OU exatamente um objeto JSON (json.dumps, ensure_ascii=False);
- exit 0 sempre: toda exceção vira 1 linha em memoria/log/errors.jsonl.
Trabalho pesado vai para motor/*.py por subprocess com timeout (common.run_motor).
"""
import os
import sys
import re
import json
import time
import shlex

ROOT = os.environ.get("BABEL_ROOT") or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.abspath(ROOT)
sys.path.insert(0, os.path.join(ROOT, "motor"))
try:
    import common
except Exception:
    try:
        sys.stderr.write("hook.py: nao consegui importar motor/common.py\n")
    except Exception:
        pass
    sys.exit(0)

P = common.P
SCRIPT = "hook.py"

# limites de tempo dos subprocessos (spec §4/§11.2); sempre abaixo de 80 % do timeout do settings
T_VERIFY = 3.0
T_WAKE = 8.0
T_RECALL = 5.0
T_REFINE = 2.0
T_SNAPSHOT = 15.0
T_SETUP = 25.0
T_MAINT = 60.0
CAP_SESSION_START = 3000
CAP_PROMPT = 6000
SUMMARY_MAX = 200

EDIT_TOOLS = ("Write", "Edit", "NotebookEdit")
MEM_PREFIXES = ("memoria/memorias/", "memoria/decisoes/", "memoria/projetos/", "memoria/perfil/", "memoria/conhecimento/")
GATE_EXEMPT = ("memoria/", "dashboard/", "planos/", "backups/")
MEM_SKILLS = ("lembrar", "decidir", "lembrete")
MEM_SCRIPTS_RE = re.compile(r"motor/(remember|correct|agenda)\.py")
GENERATED_FILES = ("memoria/state.json", "memoria/graph.json", "memoria/perfil/retrato.md",
                   "dashboard/index.html", "dashboard/data.js")
PROTECTED_DIRS_EDIT = ("memoria/origem/", "memoria/.cache/", "memoria/.history/", "backups/")
PLAIN_REDIRECTS = (">", ">>", "1>", "1>>", "&>", "&>>")

REASON_RM = "rm recursivo fora de entregas/: mova para memoria/.lixeira/"
REASON_GENERATED = "arquivo gerado/protegido: use o motor"
REASON_SECRET = "parece segredo; não gravo isso na memória"
REASON_SUDO = "sudo não é permitido"
REASON_PIPE = "download executado direto (curl/wget | sh) não é permitido"
REASON_CHMOD = "chmod -R 777 não é permitido"
GATE_REASON = ("Gabriel, antes de parar: este pedido mexeu em {n} arquivo(s) ({files}) e nada foi registrado na memória. "
               "Registre em uma linha o que aprendeu (python3 motor/remember.py --type learning|preference|decision|project …) "
               "e feche com 📌 Anotei: …. Se não houver nada novo de verdade, responda exatamente 'nada novo a registrar' e pare.")
REMINDER = "⚠ O pedido anterior mudou {n} arquivo(s) sem registrar memória: registre com python3 motor/remember.py antes de seguir"

_SUDO_RE = re.compile(r"(^|[\s;&|(`])sudo(\s|$)")
_PIPE_SH_RE = re.compile(r"\b(curl|wget)\b[^|\n]*\|\s*(sudo\s+)?(ba|z|da|k)?sh\b")
_REDIR_RE = re.compile(r"""(?<![<>&])(&>>?|\d*>>?)\s*(?:"([^"]*)"|'([^']*)'|([^\s;&|<>"']+))""")
_ENV_ASSIGN_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=")
_SED_INPLACE_RE = re.compile(r"^-[A-Za-z]*i")
_RM_FLAG_RE = re.compile(r"^-[A-Za-z]*[rRf]")


# --------------------------------------------------------------------------- utilidades locais
def _s(v):
    return "" if v is None else str(v)


def _dict(obj, key):
    v = obj.get(key)
    if not isinstance(v, dict):
        v = {}
        obj[key] = v
    return v


def _list(obj, key):
    v = obj.get(key)
    if not isinstance(v, list):
        v = []
        obj[key] = v
    return v


def _int(v, default=0):
    try:
        if isinstance(v, bool):
            return default
        return int(v)
    except Exception:
        return default


def _norm_rel(path):
    """Caminho relativo ao projeto com '/', ou None; 'outside:<nome>' fica como está."""
    r = common.rel(path)
    if r is None:
        return None
    return r.replace(os.sep, "/")


def _rel_or_none(path):
    if not path:
        return None
    try:
        ap = os.path.normpath(os.path.abspath(os.path.expanduser(str(path))))
    except Exception:
        return None
    return _norm_rel(ap)


def _fmt_kb(n):
    return "%.1f KB" % (float(n) / 1024.0)


def _summary(text):
    return common.truncate(common.redact(_s(text)), SUMMARY_MAX)


def _domain(url):
    try:
        from urllib.parse import urlsplit
        return urlsplit(_s(url)).netloc or "?"
    except Exception:
        return "?"


def _file_ts():
    return common.now().strftime("%Y-%m-%dT%H-%M-%S")


def _flatten_unique(d):
    out = []
    if isinstance(d, dict):
        for k in d:
            v = d.get(k)
            if isinstance(v, list):
                for f in v:
                    if isinstance(f, str) and f not in out:
                        out.append(f)
    return out


def _touched(t, p):
    """Arquivos do prompt p que contam para o portão (fora de memoria/, dashboard/, planos/, backups/)."""
    if not p:
        return []
    fb = t.get("files_by_prompt")
    lst = fb.get(p) if isinstance(fb, dict) else None
    if not isinstance(lst, list):
        return []
    out = []
    for f in lst:
        if isinstance(f, str) and f and not f.startswith(GATE_EXEMPT) and f not in out:
            out.append(f)
    return out


def _hook_output(ev_name, **fields):
    hso = {"hookEventName": ev_name}
    hso.update(fields)
    return {"hookSpecificOutput": hso}


# --------------------------------------------------------------------------- análise de comandos Bash
def split_subcommands(cmd):
    """Divide em subcomandos por &&, ||, ;, | e quebra de linha, respeitando aspas."""
    parts, cur, q = [], [], None
    i, n = 0, len(cmd)
    while i < n:
        ch = cmd[i]
        if q:
            cur.append(ch)
            if ch == q:
                q = None
            elif ch == "\\" and q == '"' and i + 1 < n:
                cur.append(cmd[i + 1])
                i += 1
        elif ch in ("'", '"'):
            q = ch
            cur.append(ch)
        elif ch == "\\" and i + 1 < n:
            cur.append(ch)
            cur.append(cmd[i + 1])
            i += 1
        elif cmd.startswith("&&", i) or cmd.startswith("||", i):
            parts.append("".join(cur))
            cur = []
            i += 1
        elif ch in ";|\n":
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
        i += 1
    parts.append("".join(cur))
    return [p.strip() for p in parts if p.strip()]


def tokens_of(sub):
    try:
        return shlex.split(sub, posix=True)
    except Exception:
        return sub.split()


def cmd_name(tokens):
    """Nome do comando (sem caminho), pulando atribuições de ambiente."""
    for t in tokens:
        if _ENV_ASSIGN_RE.match(t):
            continue
        return os.path.basename(t)
    return ""


def resolve_path(p, base):
    """Caminho absoluto normalizado; None em dúvida (variável, crase, flag)."""
    p = _s(p).strip()
    if not p or "$" in p or "`" in p or p.startswith("-"):
        return None
    try:
        if p.startswith("~"):
            p = os.path.expanduser(p)
        ap = p if os.path.isabs(p) else os.path.join(base, p)
        return os.path.normpath(ap)
    except Exception:
        return None


def redirect_targets(sub, plain_only=False):
    out = []
    for m in _REDIR_RE.finditer(sub):
        op = m.group(1)
        if plain_only and op not in PLAIN_REDIRECTS:
            continue
        path = m.group(2) or m.group(3) or m.group(4)
        if path:
            out.append(path)
    return out


def tee_target(tokens):
    for i, t in enumerate(tokens):
        if os.path.basename(t) == "tee":
            for tok in tokens[i + 1:]:
                if tok.startswith("-"):
                    continue
                return tok
            return None
    return None


def sed_inplace_target(tokens):
    if cmd_name(tokens) != "sed":
        return None
    flags = [t for t in tokens[1:] if t.startswith("-")]
    if not any(_SED_INPLACE_RE.match(f) or f.startswith("--in-place") for f in flags):
        return None
    has_script_flag = any(f in ("-e", "-f", "--expression", "--file") or f.startswith("--expression=") or f.startswith("--file=") for f in flags)
    non_flags = []
    skip = False
    for t in tokens[1:]:
        if skip:
            skip = False
            continue
        if t in ("-e", "-f", "--expression", "--file"):
            skip = True
            continue
        if t.startswith("-") or t == "":
            continue
        non_flags.append(t)
    if not non_flags:
        return None
    if not has_script_flag and len(non_flags) < 2:
        return None
    return non_flags[-1]


def mv_cp_target(tokens):
    if cmd_name(tokens) not in ("mv", "cp"):
        return None
    non_flags = [t for t in tokens[1:] if not t.startswith("-") and t != ""]
    if len(non_flags) < 2:
        return None
    return non_flags[-1]


def write_targets(sub, tokens):
    """Todos os alvos de escrita de um subcomando (redirecionamentos, tee, sed -i)."""
    out = list(redirect_targets(sub))
    t = tee_target(tokens)
    if t:
        out.append(t)
    t = sed_inplace_target(tokens)
    if t:
        out.append(t)
    return out


def bash_base(payload):
    cwd = payload.get("cwd")
    if isinstance(cwd, str) and cwd and os.path.isabs(cwd):
        r = _norm_rel(cwd)
        if r is not None and not r.startswith("outside:"):
            return os.path.normpath(cwd)
    return common.ROOT


def bash_touched_file(command, base):
    """Heurística explícita (§11.2) sobre o ÚLTIMO subcomando com operador; dúvida → None."""
    subs = split_subcommands(command)
    for sub in reversed(subs):
        tokens = tokens_of(sub)
        candidate = None
        name = cmd_name(tokens)
        if name in ("mv", "cp"):
            candidate = mv_cp_target(tokens)
        elif name == "sed" and sed_inplace_target(tokens):
            candidate = sed_inplace_target(tokens)
        elif name == "tee" or any(os.path.basename(t) == "tee" for t in tokens):
            candidate = tee_target(tokens)
        else:
            reds = redirect_targets(sub, plain_only=True)
            if reds:
                candidate = reds[-1]
            elif redirect_targets(sub):
                return None  # só redireciona stderr/fd: dúvida
            else:
                continue
        if not candidate:
            return None
        ap = resolve_path(candidate, base)
        if not ap:
            return None
        r = _norm_rel(ap)
        if not r or r.startswith("outside:") or r in (".", ""):
            return None
        return r
    return None


# --------------------------------------------------------------------------- protect() (só deny)
def _is_generated(ap):
    r = _norm_rel(ap)
    if r and not r.startswith("outside:"):
        if r == "memoria/log" or r.startswith("memoria/log/"):
            return True
        if r in GENERATED_FILES:
            return True
        if re.match(r"^memoria/INDICE[^/]*\.md$", r):
            return True
    try:
        home = os.path.expanduser("~")
        if os.path.normpath(ap) in (os.path.join(home, ".claude", "settings.json"), os.path.join(home, ".claude.json")):
            return True
    except Exception:
        pass
    return False


def _is_protected_dir_edit(ap):
    r = _norm_rel(ap)
    if not r or r.startswith("outside:"):
        return False
    for d in PROTECTED_DIRS_EDIT:
        if r == d.rstrip("/") or r.startswith(d):
            return True
    return False


def _check_rm(tokens, base):
    flags = [t for t in tokens[1:] if t.startswith("-") and t != "--"]
    if not any(_RM_FLAG_RE.match(f) or f in ("--recursive", "--force") for f in flags):
        return None
    targets = [t for t in tokens[1:] if not t.startswith("-") and t != ""]
    for t in targets:
        if "$" in t or "`" in t:
            continue  # variável: dúvida → silêncio
        if t == "~" or t.startswith("~/"):
            return REASON_RM
        ap = resolve_path(t, base)
        if ap is None:
            continue
        r = _norm_rel(ap)
        if r is None or r.startswith("outside:"):
            return REASON_RM
        if r.startswith("entregas/") or r == "memoria/.lixeira" or r.startswith("memoria/.lixeira/"):
            continue
        return REASON_RM
    return None


def protect(tool, ti, payload):
    """Devolve o motivo (pt-BR) de um deny, ou None. Nunca allow/ask; em dúvida, silêncio."""
    if tool == "Bash":
        cmd = _s(ti.get("command"))
        if not cmd.strip():
            return None
        if _SUDO_RE.search(cmd):
            return REASON_SUDO
        if _PIPE_SH_RE.search(cmd):
            return REASON_PIPE
        base = bash_base(payload)
        for sub in split_subcommands(cmd):
            tokens = tokens_of(sub)
            if not tokens:
                continue
            name = cmd_name(tokens)
            if name == "rm":
                r = _check_rm(tokens, base)
                if r:
                    return r
            if name == "chmod":
                flags = [t for t in tokens[1:] if t.startswith("-")]
                if any("R" in f for f in flags) and "777" in tokens:
                    return REASON_CHMOD
            for target in write_targets(sub, tokens):
                ap = resolve_path(target, base)
                if ap and _is_generated(ap):
                    return REASON_GENERATED
        return None
    if tool in EDIT_TOOLS:
        fp = ti.get("file_path") or ti.get("notebook_path")
        if not fp:
            return None
        try:
            ap = os.path.normpath(os.path.abspath(os.path.expanduser(_s(fp))))
        except Exception:
            return None
        if _is_generated(ap) or _is_protected_dir_edit(ap):
            return REASON_GENERATED
        r = _norm_rel(ap)
        if r and r.startswith("memoria/"):
            for key in ("content", "new_string", "new_source"):
                text = ti.get(key)
                if isinstance(text, str) and text and common.redact(text) != text:
                    return REASON_SECRET
    return None


# --------------------------------------------------------------------------- cópia de segurança (PreToolUse)
def safety_copy(ti):
    """Write/Edit/NotebookEdit em .md existente sob memoria/ → .history/<id>/v<version>.md + .cache/texts/<id>.md."""
    fp = ti.get("file_path") or ti.get("notebook_path")
    if not fp:
        return
    ap = os.path.normpath(os.path.abspath(os.path.expanduser(_s(fp))))
    r = _norm_rel(ap)
    if not r or r.startswith("outside:") or not r.endswith(".md"):
        return
    parts = r.split("/")
    if parts[0] != "memoria" or len(parts) < 3:
        return
    if parts[1] in ("log", ".cache", ".history", ".lixeira") or parts[1].startswith(".restoring-"):
        return
    if not os.path.isfile(ap):
        return
    text = common.read_text(ap)
    if text is None:
        return
    meta, _body = common.read_frontmatter(text)
    version = 0
    if isinstance(meta, dict):
        version = _int(meta.get("version"), 0)
    doc_id = common.doc_id_from_path(ap)
    hdir = os.path.join(P["history"], doc_id)
    os.makedirs(hdir, exist_ok=True)
    target = os.path.join(hdir, "v%d.md" % version)
    if os.path.exists(target):
        if common.body_hash(common.read_text(target) or "") != common.body_hash(text):
            n = 0
            while os.path.exists(os.path.join(hdir, "v%d-%d.md" % (version, n))):
                n += 1
            target = os.path.join(hdir, "v%d-%d.md" % (version, n))
        else:
            target = None
    if target:
        common.write_atomic(target, text)
    common.history_snapshot(doc_id, text, version)


# --------------------------------------------------------------------------- contexto do evento
class Ctx(object):
    def __init__(self, payload, ev, t0):
        self.payload = payload
        self.ev = ev
        self.t0 = t0
        self.session_id = _s(payload.get("session_id")) or _s(common.session_id_fallback())
        self.sid = common.sid8(self.session_id)
        pid = payload.get("prompt_id")
        self.prompt_id = _s(pid) if pid else None
        self.turn_path = os.path.join(P["cache"], "turn-%s.json" % self.sid)
        self._cfg = None

    def cfg(self):
        if self._cfg is None:
            self._cfg = common.load_config()
        return self._cfg

    def update_turn(self, fn):
        return common.update_json_locked(self.turn_path, fn, script=SCRIPT)

    def load_turn(self):
        t = common.load_json(self.turn_path, {}, script=SCRIPT)
        return t if isinstance(t, dict) else {}


def base_event(ctx):
    ev = {"ts": common.now_iso(), "session": ctx.sid}
    if ctx.prompt_id:
        ev["prompt_id"] = ctx.prompt_id
    ev["event"] = ctx.ev
    ev["agent"] = ctx.payload.get("agent_type") or None
    if "agent_id" in ctx.payload:
        ev["agent_id"] = ctx.payload.get("agent_id")
    return ev


# --------------------------------------------------------------------------- handlers
def h_setup(ctx, ev):
    payload = ctx.payload
    trigger = payload.get("trigger")
    ev["trigger"] = trigger
    try:
        common.write_atomic(os.path.join(P["cache"], "setup-%s.flag" % ctx.sid), common.now_iso() + "\n")
    except Exception as e:
        common.log_error(SCRIPT, e, event=ctx.ev)
    if trigger in (None, "init"):
        args = ["--install"] if not os.path.exists(P["state"]) else ["--repair"]
        rc, _out, _err = common.run_motor("verify.py", args, timeout=T_SETUP)
        ev["summary"] = "verify %s rc=%s" % (args[0], rc)
    elif trigger == "maintenance":
        rc1, _o, _e = common.run_motor("verify.py", ["--repair"], timeout=5.0)
        rc2, _o, _e = common.run_motor("maintenance.py", [], timeout=20.0)
        ev["summary"] = "verify --repair rc=%s; maintenance rc=%s" % (rc1, rc2)
    else:
        ev["summary"] = "trigger desconhecido"
    return None


def h_session_start(ctx, ev):
    payload = ctx.payload
    source = _s(payload.get("source")) or "startup"
    ev["source"] = source
    if payload.get("model"):
        ev["model"] = _s(payload.get("model"))
    common.run_motor("verify.py", ["--repair", "--quiet"], timeout=T_VERIFY)
    args = ["--source", source, "--session", ctx.session_id]
    idle = payload.get("seconds_since_last_response")
    if isinstance(idle, (int, float)) and not isinstance(idle, bool):
        args += ["--seconds-idle", str(int(idle))]
    rc, out, _err = common.run_motor("wake.py", args, timeout=T_WAKE)
    text = (out or "").strip()
    if rc != 0 or not text:
        ev["chars"] = 0
        ev["summary"] = "wake sem contexto (rc=%s)" % rc
        return None
    context = common.truncate(text, CAP_SESSION_START)
    ev["chars"] = len(context)
    ev["summary"] = "contexto de %d chars" % len(context)
    return _hook_output(ctx.ev, additionalContext=context)


def looks_like_skill_body(prompt):
    """Fallback determinístico (§11.2): 1ª linha do prompt == 1ª linha do corpo de uma SKILL.md → nome da skill."""
    heads = common.load_json(P["skill_heads"], None, script=SCRIPT)
    if not isinstance(heads, dict) or not heads:
        return None
    first = ""
    for line in prompt.split("\n"):
        if line.strip():
            first = line.strip()
            break
    if not first:
        return None
    for k, v in heads.items():
        if isinstance(v, str) and v.strip() and v.strip() == first:
            return _s(k)
        if isinstance(k, str) and k.strip() == first and isinstance(v, str) and v.strip():
            return v.strip()
    return None


def h_user_prompt_submit(ctx, ev):
    payload = ctx.payload
    prompt = _s(payload.get("prompt"))
    cfg = ctx.cfg()
    mode = payload.get("permission_mode")
    box = {"had": False, "n": 0, "pid": ctx.prompt_id}

    def fn(t):
        prev = t.get("current_prompt")
        t.setdefault("session", ctx.sid)
        if not t.get("start"):
            t["start"] = common.now_iso()
        t["prompts"] = _int(t.get("prompts"), 0) + 1
        if not box["pid"]:
            box["pid"] = "p_%d" % t["prompts"]
        pid = box["pid"]
        t["current_prompt"] = pid
        _list(_dict(t, "files_by_prompt"), pid)
        _list(_dict(t, "memories_by_prompt"), pid)
        _dict(t, "stop_blocks")
        if mode:
            t["permission_mode"] = mode
        box["had"] = bool(t.get("pending_reminder"))
        if box["had"]:
            box["n"] = len(_touched(t, prev))
        t["pending_reminder"] = False
        t.setdefault("compact_delta", None)
        _dict(t, "subagents")

    ctx.update_turn(fn)
    pid = box["pid"] or "unknown"
    reminder = None
    if box["had"]:
        reminder = common.truncate(REMINDER.format(n=max(1, box["n"])), _int(cfg.get("reminder_reserved_chars"), 300))

    stripped = prompt.lstrip()
    cmd = None
    if stripped.startswith("/"):
        head = stripped[1:].split()
        cmd = head[0] if head else None
        is_cmd = True
    else:
        skill = looks_like_skill_body(prompt)
        if skill:
            cmd = skill
            is_cmd = True
        else:
            is_cmd = False
    words = len(prompt.split())
    min_words = _int(cfg.get("recall_min_words"), 4)
    try:
        terms = common.tokenize(prompt, expand=False)[:40]
    except Exception:
        terms = []
    line = {"ts": common.now_iso(), "session": ctx.sid, "prompt_id": pid,
            "text": common.truncate(common.redact(prompt), _int(cfg.get("prompt_max_chars"), 1500)),
            "chars": len(prompt), "command": cmd, "terms": terms, "mode": mode, "injected": []}
    ev["chars"] = len(prompt)
    ev["words"] = words
    if cmd:
        ev["command"] = cmd
    ev["summary"] = _summary(prompt)

    if is_cmd or words < min_words:
        common.append_jsonl(P["prompts"], line, max_chars=2200)
        ev["injected"] = 0
        if reminder:
            ev["reminder"] = True
            return _hook_output(ctx.ev, additionalContext=reminder)
        return None

    budget = _int(cfg.get("recall_budget_chars"), 6000)
    if reminder:
        budget -= _int(cfg.get("reminder_reserved_chars"), 300)
    t1 = time.monotonic()
    rc, out, _err = common.run_motor("recall.py", ["--prompt-stdin", "--json", "--session", ctx.session_id, "--budget", str(budget)],
                                     timeout=T_RECALL, stdin_text=prompt)
    recall_ms = int((time.monotonic() - t1) * 1000)
    r = {}
    if rc == 0 and (out or "").strip():
        try:
            parsed = json.loads(out)
            if isinstance(parsed, dict):
                r = parsed
        except Exception as e:
            common.log_error(SCRIPT, e, event=ctx.ev, extra={"message": "recall.py devolveu JSON invalido"})
    context = _s(r.get("context"))
    raw_ids = r.get("ids") if isinstance(r.get("ids"), list) else []
    ids = []
    for item in raw_ids:
        if isinstance(item, (list, tuple)) and item:
            ids.append(_s(item[0]))
        elif isinstance(item, str):
            ids.append(item)
    top = r.get("top") if isinstance(r.get("top"), list) else [[i, None] for i in ids]
    if reminder and context:
        final = reminder + "\n\n" + context
    else:
        final = reminder or context
    final = common.truncate(final, CAP_PROMPT)
    line["injected"] = ids
    common.append_jsonl(P["prompts"], line, max_chars=2200)
    # recalls.jsonl e gravado pelo proprio recall.py (--prompt-stdin); nada a fazer aqui.
    ev["injected"] = len(ids)
    ev["recall_ms"] = recall_ms
    if reminder:
        ev["reminder"] = True
    if final:
        return _hook_output(ctx.ev, additionalContext=final)
    return None


def h_user_prompt_expansion(ctx, ev):
    payload = ctx.payload
    name = payload.get("command_name")
    ev["command_name"] = _s(name) or None
    ev["command_args"] = common.truncate(common.redact(_s(payload.get("command_args"))), 120)
    ev["expansion_type"] = payload.get("expansion_type")
    ev["summary"] = _summary("comando /%s" % _s(name))

    def fn(t):
        t["last_command"] = _s(name) or None

    ctx.update_turn(fn)
    return None


def h_pre_tool_use(ctx, ev):
    payload = ctx.payload
    tool = _s(payload.get("tool_name"))
    ti = payload.get("tool_input")
    ti = ti if isinstance(ti, dict) else {}
    ev["tool"] = tool
    if tool in EDIT_TOOLS:
        fp = ti.get("file_path") or ti.get("notebook_path")
        ev["file"] = _rel_or_none(fp)
        try:
            safety_copy(ti)
        except Exception as e:
            common.log_error(SCRIPT, e, event=ctx.ev, extra={"file": _rel_or_none(fp)})
    reason = None
    try:
        reason = protect(tool, ti, payload)
    except Exception as e:
        common.log_error(SCRIPT, e, event=ctx.ev, extra={"message": "protect falhou; silencio"})
        reason = None
    if reason:
        ev["summary"] = _summary("deny: " + reason)
        ev["denied"] = True
        return _hook_output(ctx.ev, permissionDecision="deny", permissionDecisionReason=reason)
    if tool == "Bash":
        ev["summary"] = _summary(ti.get("command"))
    else:
        ev["summary"] = _summary("%s %s" % (tool, ev.get("file") or ""))
    return None


def _write_report(ctx, ev, ti):
    msg = _s(ti.get("message"))
    if not msg.strip():
        ev["summary"] = "handback vazio"
        return
    agent = common.slug(_s(ctx.payload.get("agent_type")) or "subagente", 40) or "subagente"
    doc_id = "%s-%s" % (_file_ts(), agent)
    path = os.path.join(P["relatorios"], doc_id + ".md")
    body = common.escape_at(common.redact(msg)[:40000])
    now = common.now_iso()
    meta = {"id": doc_id, "type": "report", "title": common.escape_at("Relatório %s %s" % (agent, common.now().strftime("%d/%m"))),
            "tags": ["relatorio", agent], "status": "active", "source": "subagent:" + agent, "session": ctx.sid,
            "agent": agent, "created": now, "updated": now, "version": 1, "hash": common.body_hash(body)}
    common.write_atomic(path, common.write_frontmatter(meta, body))
    ev["file"] = _norm_rel(path)
    ev["summary"] = _summary("relatorio %s -> %s" % (_fmt_kb(len(msg)), ev["file"]))


def h_post_tool_use(ctx, ev):
    payload = ctx.payload
    tool = _s(payload.get("tool_name"))
    ti = payload.get("tool_input")
    ti = ti if isinstance(ti, dict) else {}
    tr = payload.get("tool_response")
    tr = tr if isinstance(tr, dict) else {}
    ev["tool"] = tool
    dur = payload.get("duration_ms")
    if isinstance(dur, (int, float)) and not isinstance(dur, bool):
        ev["ms"] = int(dur)
    file_ = None
    command = ""
    skill_name = None
    summary = tool
    if tool in ("Write", "Edit", "NotebookEdit", "Read"):
        file_ = _rel_or_none(ti.get("file_path") or ti.get("notebook_path"))
        if tool == "Write":
            summary = "Write %s" % _fmt_kb(len(_s(ti.get("content"))))
        elif tool == "Edit":
            summary = "Edit -%d +%d chars" % (len(_s(ti.get("old_string"))), len(_s(ti.get("new_string"))))
        elif tool == "NotebookEdit":
            summary = "NotebookEdit %s" % (_s(ti.get("edit_mode")) or "replace")
        else:
            summary = "Read %s" % (file_ or "?")
    elif tool == "Bash":
        command = _s(ti.get("command"))
        try:
            file_ = bash_touched_file(command, bash_base(payload))
        except Exception as e:
            common.log_error(SCRIPT, e, event=ctx.ev, extra={"message": "heuristica bash"})
            file_ = None
        stdout = tr.get("stdout")
        ev["stdout_chars"] = len(stdout) if isinstance(stdout, str) else 0
        summary = command
    elif tool == "Agent":
        summary = "Agent %s: %s" % (_s(ti.get("subagent_type")) or "?", _s(ti.get("description")))
    elif tool == "Skill":
        skill_name = _s(ti.get("skill") or ti.get("name") or ti.get("command")).strip().lstrip("/") or None
        summary = "Skill %s %s" % (skill_name or "?", common.truncate(common.redact(_s(ti.get("args"))), 120))
    elif tool == "WebSearch":
        summary = "WebSearch %s" % _s(ti.get("query"))
    elif tool == "WebFetch":
        summary = "WebFetch %s" % _domain(ti.get("url"))
    elif tool == "SubagentHandback":
        pass
    elif tool == "Workflow":
        summary = "Workflow %s" % (_s(ti.get("name") or ti.get("workflow")) or "?")
    ev["file"] = file_
    if tool == "SubagentHandback":
        try:
            _write_report(ctx, ev, ti)
        except Exception as e:
            common.log_error(SCRIPT, e, event=ctx.ev, extra={"message": "relatorio do subagente"})
            ev["summary"] = "relatorio falhou"
    else:
        ev["summary"] = _summary(summary)

    # marcação do turno (lock lateral)
    mode = payload.get("permission_mode")
    mark_file = None
    if file_ and not file_.startswith("outside:") and (tool in EDIT_TOOLS or tool == "Bash"):
        mark_file = file_
    is_mem = False
    if mark_file and mark_file.startswith(MEM_PREFIXES):
        is_mem = True
    if tool == "Bash" and MEM_SCRIPTS_RE.search(command):
        is_mem = True
    if tool == "Skill" and skill_name and skill_name.split(":")[-1] in MEM_SKILLS:
        is_mem = True
    if mode or mark_file or is_mem:
        def fn(t):
            if mode:
                t["permission_mode"] = mode
            cp = _s(t.get("current_prompt")) or ctx.prompt_id or "unknown"
            if mark_file:
                lst = _list(_dict(t, "files_by_prompt"), cp)
                if mark_file not in lst:
                    lst.append(mark_file)
            if is_mem:
                lst = _list(_dict(t, "memories_by_prompt"), cp)
                lst.append(mark_file or "cli")
        ctx.update_turn(fn)
    return None


def _record_failure(ctx, ev):
    payload = ctx.payload
    err = payload.get("error")
    if err is not None and not isinstance(err, str):
        try:
            err = json.dumps(err, ensure_ascii=False)
        except Exception:
            err = str(err)
    error = common.truncate(common.redact(_s(err)), 200)
    ev["error"] = error
    if payload.get("tool_name"):
        ev["tool"] = _s(payload.get("tool_name"))
    ev["summary"] = _summary("falha: " + error)
    obj = {"ts": common.now_iso(), "event": ctx.ev, "error": error, "session": ctx.sid}
    if payload.get("tool_name"):
        obj["tool"] = _s(payload.get("tool_name"))
    common.save_json(P["last_failure"], obj)
    return None


def h_post_tool_use_failure(ctx, ev):
    return _record_failure(ctx, ev)


def h_stop_failure(ctx, ev):
    return _record_failure(ctx, ev)


def h_subagent_start(ctx, ev):
    aid = _s(ctx.payload.get("agent_id"))
    atype = _s(ctx.payload.get("agent_type"))
    ev["summary"] = _summary("subagente %s iniciou" % (atype or "?"))
    if aid:
        def fn(t):
            subs = _dict(t, "subagents")
            entry = subs.get(aid)
            if not isinstance(entry, dict):
                entry = {}
            entry["type"] = atype or None
            entry["start"] = common.now_iso()
            entry.setdefault("end", None)
            subs[aid] = entry
        ctx.update_turn(fn)
    return None


def h_subagent_stop(ctx, ev):
    aid = _s(ctx.payload.get("agent_id"))
    atype = _s(ctx.payload.get("agent_type"))
    ev["summary"] = _summary("subagente %s terminou" % (atype or "?"))
    if aid:
        def fn(t):
            subs = _dict(t, "subagents")
            entry = subs.get(aid)
            if not isinstance(entry, dict):
                entry = {"type": atype or None, "start": None}
            entry["end"] = common.now_iso()
            subs[aid] = entry
        ctx.update_turn(fn)
    return None


def _refine_summary(rc, out, dt):
    if rc is None:
        return "refino rapido falhou/estourou (%.1f s)" % dt
    s = "refino rapido %.1f s" % dt
    text = (out or "").strip()
    if text:
        try:
            r = json.loads(text)
        except Exception:
            r = None
        if isinstance(r, dict):
            if r.get("skipped"):
                s += ", pulado (lock ocupado)"
            n = r.get("new")
            if isinstance(n, list):
                n = len(n)
            if isinstance(n, int) and not isinstance(n, bool) and n:
                s += ", +%d memoria%s" % (n, "" if n == 1 else "s")
            if r.get("version"):
                s += ", v%s" % r.get("version")
        else:
            s += ": " + common.truncate(text.split("\n")[-1], 80)
    return s


def h_stop(ctx, ev):
    payload = ctx.payload
    if ctx.ev != "Stop" or "agent_id" in payload:
        ev["summary"] = "ignorado: nao e o agente principal"
        return None
    followup = bool(payload.get("stop_hook_active"))
    cfg = ctx.cfg()
    t = ctx.load_turn()
    p = _s(payload.get("prompt_id")) or _s(t.get("current_prompt")) or None
    lam = _s(payload.get("last_assistant_message"))
    fb = t.get("files_by_prompt") if isinstance(t.get("files_by_prompt"), dict) else {}
    mb = t.get("memories_by_prompt") if isinstance(t.get("memories_by_prompt"), dict) else {}
    sb = t.get("stop_blocks") if isinstance(t.get("stop_blocks"), dict) else {}
    raw_files = fb.get(p) if p else None
    all_files = [f for f in raw_files if isinstance(f, str)] if isinstance(raw_files, list) else []
    touched = _touched(t, p)
    raw_mems = mb.get(p) if p else None
    mems = [m for m in raw_mems if isinstance(m, str)] if isinstance(raw_mems, list) else []
    registered = bool(mems)
    said_nothing_new = "nada novo a registrar" in lam.lower()
    gate = bool(cfg.get("learning_gate"))
    prior = _int(sb.get(p), 0) if p else 0
    blocked = bool((not followup) and gate and p and touched and (not registered) and (not said_nothing_new) and prior == 0)

    # (d) a linha nasce completa; jsonl nunca é reescrito
    common.append_jsonl(P["turns"], {"ts": common.now_iso(), "session": ctx.sid, "prompt_id": p,
                                     "response_head": common.redact(lam)[:_int(cfg.get("turn_response_chars"), 500)],
                                     "files_touched": all_files, "memories": mems, "blocked": blocked, "followup": followup},
                        max_chars=1400)
    # (e) refino rápido (roda também no turno de continuação)
    t1 = time.monotonic()
    rc, out, _err = common.run_motor("refine.py", ["--quick", "--trigger", "Stop"], timeout=T_REFINE)
    summary = _refine_summary(rc, out, time.monotonic() - t1)
    ev["followup"] = followup
    if blocked:
        def fn(tt):
            _dict(tt, "stop_blocks")[p] = 1
        ctx.update_turn(fn)
        ev["blocked"] = True
        ev["summary"] = _summary("bloqueio: pediu registro de %d arquivo(s); %s" % (len(touched), summary))
        reason = GATE_REASON.format(n=len(touched), files=", ".join(touched[:6]) + (", …" if len(touched) > 6 else ""))
        return {"decision": "block", "reason": reason}
    ev["blocked"] = False
    ev["summary"] = _summary(summary)
    if touched and not registered and not followup:
        def fn2(tt):
            tt["pending_reminder"] = True
        ctx.update_turn(fn2)
        ev["reminder"] = True
    return None


def h_pre_compact(ctx, ev):
    trigger = ctx.payload.get("trigger")
    ev["trigger"] = trigger
    rc, _out, _err = common.run_motor("snapshot.py", ["create", "--reason", "compact"], timeout=T_SNAPSHOT)

    def fn(t):
        t["compact_delta"] = {"files": _flatten_unique(t.get("files_by_prompt"))[:200],
                              "memories": _flatten_unique(t.get("memories_by_prompt")),
                              "current_prompt": t.get("current_prompt"), "ts": common.now_iso()}

    ctx.update_turn(fn)
    ev["summary"] = "snapshot compact rc=%s; delta guardado" % rc
    return None


def h_post_compact(ctx, ev):
    payload = ctx.payload
    trigger = _s(payload.get("trigger")) or "auto"
    summary = _s(payload.get("compact_summary"))
    ev["trigger"] = trigger
    ev["summary_chars"] = len(summary)
    if not summary.strip():
        ev["summary"] = "compact_summary vazio"
        return None
    doc_id = "%s-%s" % (_file_ts(), ctx.sid)
    path = os.path.join(P["compactacoes"], doc_id + ".md")
    body = common.escape_at(common.redact(summary))
    now = common.now_iso()
    meta = {"id": doc_id, "type": "compaction",
            "title": "Compactação %s (%s)" % (common.now().strftime("%d/%m %H:%M"), trigger),
            "tags": ["compactacao", "sessao-" + ctx.sid], "status": "active", "source": "compaction",
            "session": ctx.sid, "trigger": trigger, "created": now, "updated": now, "version": 1,
            "hash": common.body_hash(body)}
    common.write_atomic(path, common.write_frontmatter(meta, body))
    rel_path = _norm_rel(path)
    common.append_jsonl(P["compactions"], {"ts": now, "session": ctx.sid, "trigger": trigger,
                                           "summary_chars": len(summary), "file": rel_path})
    ev["file"] = rel_path
    ev["summary"] = _summary("compactacao %s -> %s" % (_fmt_kb(len(summary)), rel_path))
    return None


def h_session_end(ctx, ev):
    payload = ctx.payload
    reason = payload.get("reason")
    t = ctx.load_turn()
    prompts = _int(t.get("prompts"), 0)
    new_memories = 0
    mb = t.get("memories_by_prompt")
    if isinstance(mb, dict):
        for v in mb.values():
            if isinstance(v, list):
                new_memories += len(v)
    files = _flatten_unique(t.get("files_by_prompt"))
    sb = t.get("stop_blocks")
    blocked_prompts = sum(1 for v in sb.values() if v) if isinstance(sb, dict) else 0
    now = common.now_iso()
    common.append_jsonl(P["sessions"], {"ts": now, "session": ctx.sid, "event": "end", "reason": reason,
                                        "prompts": prompts, "new_memories": new_memories, "files_touched": len(files)})
    head = ""
    for line in reversed(common.tail_jsonl(P["turns"], 32768)):
        if isinstance(line, dict) and line.get("session") == ctx.sid:
            head = _s(line.get("response_head"))
            break
    common.save_json(P["last_session"], {"session": ctx.sid, "start": t.get("start"), "end": now, "reason": reason,
                                         "prompts": prompts, "new_memories": new_memories, "files_touched": files[:50],
                                         "response_head": common.truncate(common.redact(head), 160),
                                         "blocked_prompts": blocked_prompts})
    ev["reason"] = reason
    ev["summary"] = "fim: %d pedido(s), %d memoria(s), %d arquivo(s)" % (prompts, new_memories, len(files))
    return None


def h_config_change(ctx, ev):
    payload = ctx.payload
    ev["source"] = payload.get("source")
    ev["file"] = _rel_or_none(payload.get("file_path"))
    ev["summary"] = _summary("config %s %s" % (_s(payload.get("source")), ev["file"] or ""))
    return None


def h_instructions_loaded(ctx, ev):
    payload = ctx.payload
    ev["file"] = _rel_or_none(payload.get("file_path"))
    ev["memory_type"] = payload.get("memory_type")
    ev["load_reason"] = payload.get("load_reason")
    ev["summary"] = _summary("carregou %s (%s, %s)" % (ev["file"] or "?", _s(payload.get("memory_type")), _s(payload.get("load_reason"))))
    return None


HANDLERS = {
    "Setup": h_setup,
    "SessionStart": h_session_start,
    "UserPromptSubmit": h_user_prompt_submit,
    "UserPromptExpansion": h_user_prompt_expansion,
    "PreToolUse": h_pre_tool_use,
    "PostToolUse": h_post_tool_use,
    "PostToolUseFailure": h_post_tool_use_failure,
    "SubagentStart": h_subagent_start,
    "SubagentStop": h_subagent_stop,
    "Stop": h_stop,
    "StopFailure": h_stop_failure,
    "PreCompact": h_pre_compact,
    "PostCompact": h_post_compact,
    "SessionEnd": h_session_end,
    "ConfigChange": h_config_change,
    "InstructionsLoaded": h_instructions_loaded,
}


# --------------------------------------------------------------------------- entrada e saída
def read_stdin():
    try:
        data = sys.stdin.buffer.read()
        return data.decode("utf-8", errors="replace")
    except Exception:
        try:
            return sys.stdin.read()
        except Exception:
            return ""


def emit(obj):
    s = json.dumps(obj, ensure_ascii=False) + "\n"
    try:
        sys.stdout.buffer.write(s.encode("utf-8"))
        sys.stdout.buffer.flush()
    except Exception:
        try:
            sys.stdout.write(s)
            sys.stdout.flush()
        except Exception:
            pass


def main(argv):
    t0 = time.monotonic()
    raw = read_stdin()
    if common.paused():
        return None  # PAUSA: nem loga
    if "--maintenance" in argv:
        common.run_motor("maintenance.py", [], timeout=T_MAINT)
        return None
    if not raw.strip():
        common.log_error(SCRIPT, json.JSONDecodeError("stdin vazio", "", 0), extra={"stdin_chars": len(raw)})
        return None
    try:
        payload = json.loads(raw)
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"stdin_chars": len(raw)})
        return None
    if not isinstance(payload, dict):
        common.log_error(SCRIPT, ValueError("payload nao e objeto JSON"), extra={"stdin_chars": len(raw)})
        return None
    ev_name = payload.get("hook_event_name")
    if not isinstance(ev_name, str) or ev_name not in HANDLERS:
        common.log_error(SCRIPT, ValueError("hook_event_name ausente ou desconhecido"), event=_s(ev_name) or "ausente",
                         extra={"stdin_chars": len(raw)})
        return None
    ctx = Ctx(payload, ev_name, t0)
    ev = base_event(ctx)
    out = None
    try:
        out = HANDLERS[ev_name](ctx, ev)
    except SystemExit:
        raise
    except BaseException as e:
        common.log_error(SCRIPT, e, event=ev_name)
        ev["error"] = type(e).__name__
        out = None
    if "ms" not in ev:
        ev["ms"] = int((time.monotonic() - t0) * 1000)
    common.append_jsonl(P["events"], ev)
    return out


if __name__ == "__main__":
    try:
        result = main(sys.argv[1:])
        if result is not None:
            emit(result)
    except SystemExit:
        pass
    except BaseException as exc:
        try:
            common.log_error(SCRIPT, exc)
        except Exception:
            pass
    sys.exit(0)
