#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
common.py — biblioteca base do motor do organismo Gabriel (babel-os).

Regras de ouro (spec §11.1):
- Python 3.9 do sistema, só biblioteca padrão (sem PyYAML: frontmatter é YAML-lite próprio).
- Nada aqui lança exceção para fora quando usado por um hook; erros vão para memoria/log/errors.jsonl.
- Caminhos derivados de __file__ (ou BABEL_ROOT, que só o selftest exporta). Nunca de cwd.
"""
import os, sys, io, re, json, time, hashlib, unicodedata, fcntl, datetime, tempfile

# --------------------------------------------------------------------------- caminhos
_MOTOR_DIR = os.path.dirname(os.path.abspath(__file__))
_MOTOR_REAL = os.path.dirname(os.path.realpath(__file__))
ROOT = os.environ.get("BABEL_ROOT") or os.path.dirname(_MOTOR_DIR)
ROOT = os.path.abspath(ROOT)
ROOT_REAL = os.path.dirname(_MOTOR_REAL)  # a pasta real do projeto, mesmo sob BABEL_ROOT


def _auto_memory_dir():
    config_dir = os.environ.get("CLAUDE_CONFIG_DIR") or os.path.join(os.path.expanduser("~"), ".claude")
    slug_ = re.sub(r"[^A-Za-z0-9]", "-", ROOT_REAL)
    return os.path.join(config_dir, "projects", slug_, "memory")


def paths():
    """Todas as pastas e arquivos do substrato (§2). Nunca um caminho literal no código."""
    m = os.path.join(ROOT, "memoria")
    c = os.path.join(m, ".cache")
    lg = os.path.join(m, "log")
    return {
        "root": ROOT,
        "root_real": ROOT_REAL,
        "claude_md": os.path.join(ROOT, "CLAUDE.md"),
        "leia_me": os.path.join(ROOT, "LEIA-ME.md"),
        "pausa": os.path.join(ROOT, "PAUSA"),
        "claude_dir": os.path.join(ROOT, ".claude"),
        "settings": os.path.join(ROOT, ".claude", "settings.json"),
        "hook": os.path.join(ROOT, ".claude", "hooks", "hook.py"),
        "skills": os.path.join(ROOT, ".claude", "skills"),
        "agents": os.path.join(ROOT, ".claude", "agents"),
        "rules": os.path.join(ROOT, ".claude", "rules"),
        "workflows": os.path.join(ROOT, ".claude", "workflows"),
        "motor": os.path.join(ROOT, "motor"),
        "dashboard": os.path.join(ROOT, "dashboard"),
        "template": os.path.join(ROOT, "dashboard", "template.html"),
        "index_html": os.path.join(ROOT, "dashboard", "index.html"),
        "data_js": os.path.join(ROOT, "dashboard", "data.js"),
        "entregas": os.path.join(ROOT, "entregas"),
        "entregas_sites": os.path.join(ROOT, "entregas", "sites"),
        "entregas_sistemas": os.path.join(ROOT, "entregas", "sistemas"),
        "planos": os.path.join(ROOT, "planos"),
        "backups": os.path.join(ROOT, "backups"),
        "memoria": m,
        "indice": os.path.join(m, "INDICE.md"),
        "indice_completo": os.path.join(m, "INDICE-completo.md"),
        "state": os.path.join(m, "state.json"),
        "graph": os.path.join(m, "graph.json"),
        "config": os.path.join(m, "config.json"),
        "perfil": os.path.join(m, "perfil"),
        "perfil_marcelo": os.path.join(m, "perfil", "marcelo.md"),
        "retrato": os.path.join(m, "perfil", "retrato.md"),
        "memorias": os.path.join(m, "memorias"),
        "decisoes": os.path.join(m, "decisoes"),
        "projetos": os.path.join(m, "projetos"),
        "conhecimento": os.path.join(m, "conhecimento"),
        "compactacoes": os.path.join(m, "compactacoes"),
        "relatorios": os.path.join(m, "relatorios"),
        "origem": os.path.join(m, "origem"),
        "pedido_original": os.path.join(m, "origem", "pedido-original.md"),
        "log": lg,
        "log_archive": os.path.join(lg, "archive"),
        "events": os.path.join(lg, "events.jsonl"),
        "prompts": os.path.join(lg, "prompts.jsonl"),
        "turns": os.path.join(lg, "turns.jsonl"),
        "sessions": os.path.join(lg, "sessions.jsonl"),
        "compactions": os.path.join(lg, "compactions.jsonl"),
        "heartbeats": os.path.join(lg, "heartbeats.jsonl"),
        "agenda": os.path.join(lg, "agenda.jsonl"),
        "refinements": os.path.join(lg, "refinements.jsonl"),
        "recalls": os.path.join(lg, "recalls.jsonl"),
        "mutations": os.path.join(lg, "mutations.jsonl"),
        "errors": os.path.join(lg, "errors.jsonl"),
        "history": os.path.join(m, ".history"),
        "history_motor": os.path.join(m, ".history", "motor"),
        "cache": c,
        "cache_texts": os.path.join(c, "texts"),
        "cache_test": os.path.join(c, "test"),
        "index_json": os.path.join(c, "index.json"),
        "docs_json": os.path.join(c, "docs.json"),
        "offsets_json": os.path.join(c, "offsets.json"),
        "signature_json": os.path.join(c, "signature.json"),
        "skill_heads": os.path.join(c, "skill-heads.json"),
        "current_session": os.path.join(c, "current-session.json"),
        "last_session": os.path.join(c, "last-session.json"),
        "last_failure": os.path.join(c, "last-failure.json"),
        "refine_lock": os.path.join(c, "refine.lock"),
        "serve_pid": os.path.join(c, "serve.pid"),
        "lixeira": os.path.join(m, ".lixeira"),
        "auto_memory": _auto_memory_dir(),
    }


P = paths()

# pastas que verify.py --repair garante (ordem estável)
DIRS = ["memoria", "perfil", "memorias", "decisoes", "projetos", "conhecimento", "compactacoes",
        "relatorios", "origem", "log", "log_archive", "history", "history_motor", "cache",
        "cache_texts", "cache_test", "lixeira", "entregas", "entregas_sites", "entregas_sistemas",
        "planos", "backups", "dashboard"]

COLLECTIONS = ["perfil", "memorias", "decisoes", "projetos", "conhecimento", "compactacoes", "relatorios", "origem"]
COLLECTION_WEIGHTS = {"perfil": 1.1, "memorias": 1.0, "decisoes": 1.0, "projetos": 1.0, "conhecimento": 0.8,
                      "compactacoes": 0.6, "relatorios": 0.5, "origem": 0.7, "prompts": 0.3}
TYPES = ["profile", "preference", "fact", "learning", "idea", "reference", "decision", "project",
         "knowledge", "compaction", "report"]
TYPE_LABELS = {"profile": "perfil", "preference": "preferência", "fact": "fato", "learning": "aprendizado",
               "idea": "ideia", "reference": "referência", "decision": "decisão", "project": "projeto",
               "knowledge": "conhecimento", "compaction": "compactação", "report": "relatório"}
FRONTMATTER_ORDER = ["id", "type", "title", "summary", "tags", "confidence", "status", "superseded_by",
                     "source", "session", "project", "situation", "files", "links", "supersedes",
                     "similar_to", "sources", "topic", "agent", "trigger", "reason", "pinned",
                     "created", "updated", "generated", "version", "hash"]

CONFIG_DEFAULTS = {
    "learning_gate": True, "top_k": 6, "recall_budget_chars": 6000, "recall_body_chars_top3": 500,
    "recall_min_words": 4, "session_start_max_chars": 3000, "index_max_lines": 150,
    "index_max_chars": 12000, "daily_snapshot": True, "turn_response_chars": 500,
    "prompt_max_chars": 1500, "reminder_reserved_chars": 300, "knowledge_max_age_days": 90,
}


def ensure_dirs():
    for k in DIRS:
        try:
            os.makedirs(P[k], exist_ok=True)
        except Exception:
            pass


def rel(path):
    """Caminho relativo ao projeto; fora dele: 'outside:<basename>'."""
    if not path:
        return None
    try:
        ap = os.path.abspath(str(path))
        for base in (ROOT, ROOT_REAL):
            if ap == base or ap.startswith(base + os.sep):
                return os.path.relpath(ap, base)
        return "outside:" + os.path.basename(ap)
    except Exception:
        return None


# --------------------------------------------------------------------------- tempo
def now():
    return datetime.datetime.now().astimezone()


def now_iso():
    return now().isoformat(timespec="seconds")


def today():
    return now().strftime("%Y-%m-%d")


def ts_compact():
    return now().strftime("%Y%m%d-%H%M%S")


def parse_iso(s):
    """Aceita ISO com fuso; devolve datetime aware ou None (sem exceção)."""
    try:
        s = str(s).strip()
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        d = datetime.datetime.fromisoformat(s)
        if d.tzinfo is None:
            d = d.replace(tzinfo=now().tzinfo)
        return d
    except Exception:
        return None


def dias_desde(iso):
    d = parse_iso(iso)
    if not d:
        return None
    return max(0, (now() - d).total_seconds() / 86400.0)


def fmt_ddmm(iso, hora=False):
    d = parse_iso(iso)
    if not d:
        return "?"
    return d.strftime("%d/%m %H:%M") if hora else d.strftime("%d/%m")


def sid8(session_id):
    s = str(session_id or "unknown")
    return s[:8] if s else "unknown"


def truncate(s, n):
    if s is None:
        return ""
    s = str(s)
    if len(s) <= n:
        return s
    return s[: max(0, n - 1)].rstrip() + "…"


# --------------------------------------------------------------------------- segredos e @
_SECRET_PATTERNS = [
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S),
    re.compile(r"\bsk-ant-[A-Za-z0-9_-]{16,}"),
    re.compile(r"\bsk-[A-Za-z0-9_-]{16,}"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}"),
    re.compile(r"\bxox[abp]-[A-Za-z0-9-]{10,}"),
    re.compile(r"\br8_[A-Za-z0-9]{20,}"),
    re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}"),
    re.compile(r"(?i)\bBearer\s+\S+"),
]
_KV_SECRET = re.compile(r"(?i)\b(senha|password|passwd|token|api[_-]?key|apikey|secret|chave)(\s*[:=]\s*)(\S+)")
_CARD = re.compile(r"\b(?:\d[ -]?){13,19}\b")


def _luhn(digits):
    try:
        total, alt = 0, False
        for ch in reversed(digits):
            d = int(ch)
            if alt:
                d *= 2
                if d > 9:
                    d -= 9
            total += d
            alt = not alt
        return total % 10 == 0
    except Exception:
        return False


def redact(text):
    """Substitui por [redigido] só segredos reais. E-mails e handles NÃO são apagados."""
    if text is None:
        return ""
    t = str(text)
    try:
        for p in _SECRET_PATTERNS:
            t = p.sub("[redigido]", t)
        t = _KV_SECRET.sub(lambda m: m.group(1) + m.group(2) + "[redigido]", t)

        def _card(m):
            g = m.group(0)
            digits = re.sub(r"\D", "", g)
            tail = g[len(g.rstrip()):]
            return ("[redigido]" + tail) if 13 <= len(digits) <= 19 and _luhn(digits) else g
        t = _CARD.sub(_card, t)
    except Exception:
        pass
    return t


def looks_secret(text):
    """True se o texto inteiro parecer um segredo (para recusar gravação)."""
    if not text:
        return False
    t = str(text).strip()
    r = redact(t)
    return r.strip() == "[redigido]" or (len(t) < 120 and "[redigido]" in r and len(r.replace("[redigido]", "").strip()) < 12)


def escape_at(md):
    """Todo token com @ fora de code span/fence vira `token`; @/ e @~/ remanescentes viram (at)/."""
    if md is None:
        return ""
    out = []
    in_fence = False
    for line in str(md).split("\n"):
        stripped = line.strip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            in_fence = not in_fence
            out.append(line)
            continue
        if in_fence or "@" not in line:
            out.append(line)
            continue
        parts = line.split("`")
        # partes de índice par estão fora de code spans (quando as crases estão balanceadas)
        balanced = len(parts) % 2 == 1
        for i in range(len(parts)):
            if balanced and i % 2 == 1:
                continue
            if "@" not in parts[i]:
                continue
            parts[i] = re.sub(r"\S*@\S+", lambda m: "`" + m.group(0) + "`", parts[i])
        line2 = "`".join(parts)
        line2 = line2.replace("`@/", "`(at)/").replace("`@~/", "`(at)~/")
        line2 = re.sub(r"(?<!`)@/", "(at)/", line2)
        line2 = re.sub(r"(?<!`)@~/", "(at)~/", line2)
        out.append(line2)
    return "\n".join(out)


def bare_at_lines(md):
    """Linhas com @ solto fora de crase/fence (verificação determinística do INDICE/CLAUDE.md)."""
    hits = []
    in_fence = False
    for n, line in enumerate(str(md or "").split("\n"), 1):
        s = line.strip()
        if s.startswith("```") or s.startswith("~~~"):
            in_fence = not in_fence
            continue
        if in_fence or "@" not in line:
            continue
        parts = line.split("`")
        balanced = len(parts) % 2 == 1
        for i, part in enumerate(parts):
            if balanced and i % 2 == 1:
                continue
            if re.search(r"(^|[^`])@[^ `]", part):
                hits.append(n)
                break
    return hits


# --------------------------------------------------------------------------- arquivos
def read_text(path):
    try:
        with io.open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception:
        return None


def write_atomic(path, content):
    """Escreve em tmp e faz os.replace: nunca deixa arquivo pela metade."""
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    tmp = "%s.tmp.%d" % (path, os.getpid())
    try:
        with io.open(tmp, "w", encoding="utf-8") as f:
            f.write(content)
            f.flush()
        os.replace(tmp, path)
        return True
    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        raise


def write_if_changed(path, content, ignore_line_prefix=None):
    """Grava só se mudou (ignorando linhas que começam com o prefixo, ex.: 'generated'). Devolve True se gravou."""
    old = read_text(path)
    if old is not None:
        a, b = old, content
        if ignore_line_prefix:
            a = "\n".join(l for l in a.split("\n") if not l.lstrip().startswith(ignore_line_prefix) and ignore_line_prefix not in l)
            b = "\n".join(l for l in b.split("\n") if not l.lstrip().startswith(ignore_line_prefix) and ignore_line_prefix not in l)
        if a == b:
            return False
    write_atomic(path, content)
    return True


def _shrink_for_line(obj, max_chars):
    line = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    if len(line) <= max_chars:
        return line
    o = dict(obj)
    for key in ("summary", "text", "response_head", "message", "error", "command_args"):
        if key in o and isinstance(o[key], str) and len(line) > max_chars:
            excess = len(line) - max_chars + 1
            o[key] = truncate(o[key], max(20, len(o[key]) - excess))
            line = json.dumps(o, ensure_ascii=False, separators=(",", ":"))
    if len(line) > max_chars:
        # último recurso: mantém só chaves curtas
        o = {k: v for k, v in o.items() if isinstance(v, (int, float, bool)) or (isinstance(v, str) and len(v) <= 80) or v is None}
        line = json.dumps(o, ensure_ascii=False, separators=(",", ":"))
    return line


def append_jsonl(path, obj, max_chars=1000):
    """Append de UMA linha JSON com flock no próprio arquivo (append no mesmo inode é seguro)."""
    try:
        d = os.path.dirname(path) or "."
        os.makedirs(d, exist_ok=True)
        line = _shrink_for_line(obj, max_chars) + "\n"
        with io.open(path, "a", encoding="utf-8") as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            try:
                f.write(line)
                f.flush()
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        return True
    except Exception:
        return False


def read_jsonl(path, last=None):
    """Lê tolerando linhas corrompidas. last=N devolve só as N últimas válidas."""
    items = []
    try:
        with io.open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    items.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        return []
    if last:
        return items[-last:]
    return items


def tail_jsonl(path, nbytes=4096):
    """Últimas linhas válidas lendo só o fim do arquivo (barato; para a status line)."""
    try:
        size = os.path.getsize(path)
        with io.open(path, "rb") as f:
            f.seek(max(0, size - nbytes))
            chunk = f.read().decode("utf-8", errors="replace")
        lines = chunk.split("\n")
        if size > nbytes:
            lines = lines[1:]
        out = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue
        return out
    except Exception:
        return []


def count_jsonl(path):
    try:
        n = 0
        with io.open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if line.strip():
                    n += 1
        return n
    except Exception:
        return 0


def load_json(path, default=None, script="common"):
    """Leitura tolerante: ausente → default; ilegível → default + errors.jsonl com o nome do arquivo."""
    if not os.path.exists(path):
        return default
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        log_error(script, e, extra={"file": rel(path) or os.path.basename(path), "message": "arquivo ilegivel"})
        return default


def save_json(path, obj):
    write_atomic(path, json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


# --------------------------------------------------------------------------- travas
class exclusive_lock(object):
    """Context manager LOCK_EX|LOCK_NB em memoria/.cache/<name>.lock. `with exclusive_lock('refine') as ok:`.
    Com wait > 0 tenta de novo a cada 50 ms até wait segundos. ok=False se continuar ocupado."""

    def __init__(self, name, wait=0.0):
        self.name = name
        self.wait = float(wait or 0)
        self.fd = None
        self.ok = False

    def __enter__(self):
        try:
            os.makedirs(P["cache"], exist_ok=True)
            self.fd = open(os.path.join(P["cache"], self.name + ".lock"), "a")
            deadline = time.monotonic() + self.wait
            while True:
                try:
                    fcntl.flock(self.fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    self.ok = True
                    return True
                except (IOError, OSError):
                    if time.monotonic() >= deadline:
                        return False
                    time.sleep(0.05)
        except Exception:
            return False

    def __exit__(self, *a):
        try:
            if self.fd is not None:
                if self.ok:
                    fcntl.flock(self.fd.fileno(), fcntl.LOCK_UN)
                self.fd.close()
        except Exception:
            pass
        return False


def update_json_locked(path, fn, default=None, script="common"):
    """Lê-modifica-grava sob lock LATERAL fixo <path>.lock (flock tranca o inode; os.replace troca o inode).
    fn(obj) altera o dicionário no lugar (pode devolver outro). Devolve o objeto final ou None em falha."""
    lock_path = path + ".lock"
    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(lock_path, "a") as lf:
            fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
            try:
                obj = load_json(path, None, script=script)
                if not isinstance(obj, dict):
                    obj = dict(default) if isinstance(default, dict) else {}
                r = fn(obj)
                if isinstance(r, dict):
                    obj = r
                save_json(path, obj)
                return obj
            finally:
                fcntl.flock(lf.fileno(), fcntl.LOCK_UN)
    except Exception as e:
        log_error(script, e, extra={"file": rel(path)})
        return None


# --------------------------------------------------------------------------- config / estado leve
def load_config():
    """Defaults mesclados com memoria/config.json; corrompido → .corrupt-<ts> + defaults + errors.jsonl."""
    cfg = dict(CONFIG_DEFAULTS)
    path = P["config"]
    if not os.path.exists(path):
        return cfg
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if not isinstance(raw, dict):
            raise ValueError("config nao e objeto")
    except Exception as e:
        try:
            os.replace(path, path + ".corrupt-" + ts_compact())
            save_json(path, CONFIG_DEFAULTS)
        except Exception:
            pass
        log_error("common", e, extra={"file": "memoria/config.json", "message": "config corrompido, recriado"})
        cfg["_warnings"] = ["config_corrompido"]
        return cfg
    warnings = []
    for k, v in raw.items():
        if k in CONFIG_DEFAULTS:
            if type(v) == type(CONFIG_DEFAULTS[k]) or (isinstance(CONFIG_DEFAULTS[k], int) and isinstance(v, (int, float)) and not isinstance(v, bool)):
                cfg[k] = v
            else:
                warnings.append("config_tipo_errado:" + k)
        else:
            cfg[k] = v
    if warnings:
        cfg["_warnings"] = warnings
    return cfg


def paused():
    return os.path.exists(P["pausa"])


def session_id_fallback():
    s = os.environ.get("CLAUDE_CODE_SESSION_ID")
    if s:
        return s
    cur = load_json(P["current_session"], None)
    if isinstance(cur, dict) and cur.get("session"):
        return cur["session"]
    return "unknown"


def log_error(script, exc, event=None, extra=None):
    try:
        obj = {"ts": now_iso(), "script": script, "type": type(exc).__name__ if isinstance(exc, BaseException) else "Error",
               "message": truncate(redact(str(exc)), 500)}
        if event:
            obj["event"] = event
        if extra:
            for k, v in extra.items():
                obj.setdefault(k, v)
        os.makedirs(P["log"], exist_ok=True)
        append_jsonl(P["errors"], obj)
    except Exception:
        pass


# --------------------------------------------------------------------------- texto
def slug(text, maximum=60):
    t = unicodedata.normalize("NFKD", str(text or "")).encode("ascii", "ignore").decode("ascii").lower()
    t = re.sub(r"[^a-z0-9]+", "-", t).strip("-")
    t = t[:maximum].strip("-")
    return t or "sem-nome"


def body_hash(body):
    b = str(body or "").replace("\r\n", "\n")
    b = "\n".join(l.rstrip() for l in b.split("\n")).strip()
    return hashlib.sha256(b.encode("utf-8")).hexdigest()


def short_hash(text, n=10):
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()[:n]


_STOP = None
_SYN = None


def _stopwords():
    global _STOP
    if _STOP is None:
        s = set()
        txt = read_text(os.path.join(_MOTOR_DIR, "stopwords_pt.txt")) or ""
        for w in txt.split():
            s.add(_fold(w))
        _STOP = s
    return _STOP


def _synonyms():
    global _SYN
    if _SYN is None:
        _SYN = load_json(os.path.join(_MOTOR_DIR, "synonyms.json"), {}) or {}
    return _SYN


def _fold(s):
    return "".join(c for c in unicodedata.normalize("NFKD", str(s)) if not unicodedata.combining(c)).lower()


def stem(w):
    """Radicalização leve pt-BR, na ordem da spec."""
    if w.endswith("coes") and len(w) > 5:
        return w[:-4] + "cao"
    if w.endswith("oes") and len(w) > 4:
        return w[:-3] + "ao"
    if w.endswith("aes") and len(w) > 4:
        return w[:-3] + "ao"
    if w.endswith("mente") and len(w) > 7:
        return w[:-5]
    if w.endswith("es") and len(w) > 5:
        return w[:-2]
    if w.endswith("s") and len(w) > 4:
        return w[:-1]
    return w


def tokenize(text, expand=True):
    """Tokens normalizados (NFKD, minúsculas, sem stopwords, >= 3 chars exceto números, radical leve, sinônimos)."""
    t = _fold(text or "")
    raw = re.findall(r"[a-z0-9]+", t)
    stop = _stopwords()
    out = []
    seen = set()
    for w in raw:
        if w in stop:
            continue
        if len(w) < 3 and not w.isdigit() and w not in _synonyms():
            continue
        s = stem(w)
        if s not in seen:
            seen.add(s)
            out.append(s)
        if expand:
            for syn in (_synonyms().get(w) or _synonyms().get(s) or []):
                ss = stem(_fold(syn))
                if ss not in seen:
                    seen.add(ss)
                    out.append(ss)
    return out


# --------------------------------------------------------------------------- frontmatter YAML-lite
def _yaml_scalar_in(v):
    v = v.strip()
    if v == "" or v == "~" or v.lower() == "null":
        return None
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        if not inner:
            return []
        parts, cur, q = [], "", None
        for ch in inner:
            if q:
                if ch == q:
                    q = None
                else:
                    cur += ch
            elif ch in ("'", '"'):
                q = ch
            elif ch == ",":
                parts.append(cur.strip()); cur = ""
            else:
                cur += ch
        parts.append(cur.strip())
        return [p for p in parts if p != ""]
    if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
        return v[1:-1]
    low = v.lower()
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if re.fullmatch(r"-?\d+", v):
        try:
            return int(v)
        except Exception:
            return v
    if re.fullmatch(r"-?\d+\.\d+", v):
        try:
            return float(v)
        except Exception:
            return v
    return v


def read_frontmatter(text):
    """(dict, body). Sem frontmatter → ({}, text). Frontmatter aberto sem fechar → (None, text) = inválido."""
    if text is None:
        return None, ""
    if not text.startswith("---"):
        return {}, text
    lines = text.split("\n")
    if lines[0].strip() != "---":
        return {}, text
    end = None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end = i
            break
    if end is None:
        return None, text
    meta = {}
    list_key = None
    for line in lines[1:end]:
        if not line.strip() or line.strip().startswith("#"):
            continue
        if re.match(r"^\s+-\s*", line) and list_key:
            meta.setdefault(list_key, [])
            if not isinstance(meta[list_key], list):
                meta[list_key] = []
            meta[list_key].append(_yaml_scalar_in(re.sub(r"^\s+-\s*", "", line)))
            continue
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*)\s*:\s*(.*)$", line)
        if not m:
            continue  # linha fora do padrão é ignorada, não derruba o arquivo
        k, v = m.group(1), m.group(2)
        if v.strip() == "":
            list_key = k
            meta[k] = []
        else:
            list_key = None
            meta[k] = _yaml_scalar_in(v)
    body = "\n".join(lines[end + 1:])
    return meta, body


def _yaml_scalar_out(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    s = str(v)
    if s == "" or s.lower() in ("true", "false", "null", "yes", "no", "on", "off", "~") \
            or re.search(r"[:#\[\]{},\"'\n]|^\s|\s$|^-", s) or re.fullmatch(r"-?\d+(\.\d+)?", s):
        return json.dumps(s, ensure_ascii=False)
    return s


def write_frontmatter(meta, body):
    keys = [k for k in FRONTMATTER_ORDER if k in meta] + [k for k in meta if k not in FRONTMATTER_ORDER]
    out = ["---"]
    for k in keys:
        v = meta[k]
        if isinstance(v, list):
            out.append("%s: [%s]" % (k, ", ".join(_yaml_scalar_out(x) for x in v)))
        else:
            out.append("%s: %s" % (k, _yaml_scalar_out(v)))
    out.append("---")
    b = (body or "").lstrip("\n").rstrip("\n")
    return "\n".join(out) + "\n" + b + "\n"


def collection_of(path):
    """Coleção (pasta de memoria/) de um arquivo .md, ou None."""
    r = rel(path)
    if not r or not r.startswith("memoria" + os.sep):
        return None
    parts = r.split(os.sep)
    if len(parts) < 3:
        return None
    return parts[1] if parts[1] in COLLECTIONS else None


def doc_id_from_path(path):
    return os.path.splitext(os.path.basename(str(path)))[0]


def list_docs():
    """Todos os .md do substrato (coleções), com caminho absoluto, ordenados. Nunca planos/, log/, .cache/."""
    out = []
    for col in COLLECTIONS:
        base = P[col]
        if not os.path.isdir(base):
            continue
        for dp, dn, fn in os.walk(base):
            dn[:] = sorted(d for d in dn if not d.startswith("."))
            for f in sorted(fn):
                if f.endswith(".md") and not f.startswith(".") and not f.upper().startswith("INDICE") and f != "retrato.md":
                    out.append(os.path.join(dp, f))
    return out


def history_snapshot(doc_id, current_text, version):
    """Guarda a versão VISTA (texts/<id>.md) em .history/<id>/v<version>.md se ainda não existir com o mesmo hash;
    depois atualiza texts/<id>.md com current_text. Nunca lança."""
    try:
        os.makedirs(P["cache_texts"], exist_ok=True)
        seen_path = os.path.join(P["cache_texts"], doc_id + ".md")
        seen = read_text(seen_path)
        if seen is not None and seen != current_text:
            hdir = os.path.join(P["history"], doc_id)
            os.makedirs(hdir, exist_ok=True)
            target = os.path.join(hdir, "v%s.md" % (version if version else 0))
            if os.path.exists(target):
                if body_hash(read_text(target) or "") != body_hash(seen):
                    n = 0
                    while os.path.exists(os.path.join(hdir, "v%s-%d.md" % (version, n))):
                        n += 1
                    target = os.path.join(hdir, "v%s-%d.md" % (version, n))
                else:
                    target = None
            if target:
                write_atomic(target, seen)
        if current_text is not None:
            write_atomic(seen_path, current_text)
        return True
    except Exception as e:
        log_error("common", e, extra={"file": doc_id})
        return False


def run_motor(script, args=None, timeout=5.0, stdin_text=None):
    """Roda outro script do motor por subprocess, repassando o ambiente (BABEL_ROOT chega ao filho).
    Devolve (rc, stdout, stderr) ou (None, '', 'timeout'|'erro')."""
    import subprocess
    cmd = [sys.executable or "/usr/bin/python3", os.path.join(_MOTOR_DIR, script)] + list(args or [])
    try:
        r = subprocess.run(cmd, input=stdin_text, capture_output=True, text=True, timeout=timeout, env=dict(os.environ), cwd=ROOT)
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        log_error("common", e, extra={"message": "%s > %.1f s" % (script, timeout)})
        return None, "", "timeout"
    except Exception as e:
        log_error("common", e, extra={"message": script})
        return None, "", "erro"


def fmt_brl(v):
    try:
        return ("US$ %.2f" % float(v)).replace(".", ",")
    except Exception:
        return ""


def label_type(t):
    return TYPE_LABELS.get(str(t), str(t))


if __name__ == "__main__":
    # auto-teste rápido
    print("ROOT", ROOT)
    print("auto_memory", P["auto_memory"])
    print(tokenize("Gabriel, cria uma LP de pré-cadastro pro Reino com identidade Babel OS; as decisões dos empresários"))
    print(redact("token=abc123def456 senha: x sk-ABCDEFGHIJKLMNOPQRST Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U cartão 4111 1111 1111 1111 e-mail x@y.com"))
    print(escape_at("email marcelo@x.com e @browser e `ok@ok` e @/etc @~/x"))
    m, b = read_frontmatter("---\nid: x\ntags: [a, b]\nlinks:\n  - p\n  - q\nconfidence: 0.9\npinned: true\ntitle: \"Marcelo: sim\"\n---\ncorpo\n")
    print(m, repr(b))
    print(write_frontmatter(m, b))
