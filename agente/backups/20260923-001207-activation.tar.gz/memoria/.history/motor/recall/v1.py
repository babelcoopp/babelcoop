#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
recall.py — recuperação de memória do organismo Gabriel (spec §11.5).

prompt → BM25 sobre .cache/index.json (§3.8) + multiplicadores + expansão por grafo (1 salto)
       + histórico (docs prompt:*) + pendências ligadas → markdown "🧠 Gabriel lembra" ≤ orçamento.

CLI:
  --prompt-stdin                  lê o prompt inteiro do stdin (modo do gancho; registra recalls.jsonl)
  --search "<termo>" [--k N] [--body] [--ids]
  --recent N                      N memórias mais recentes (título + id + tipo)
  --slices N                      top-40 em N fatias por coleção/projeto → JSON {"fatias": [...]}
  --json | --session ID | --budget N
Sempre exit 0; erro → errors.jsonl.
"""
import os, sys, re, json, math, time, argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

SCRIPT = "recall.py"
K1 = 1.2
B = 0.75
TIMEOUT_S = 4.0
INDEX_STALE_S = 60.0
FOOTER = "(Se algo estiver errado: /esquecer <id>. Para ver mais: /consultar <tema>.)"
SITUATION_LABELS = {"idea": "ideia", "in-progress": "em andamento", "delivered": "entregue", "paused": "pausado"}
COLLECTION_LABELS = {"perfil": "perfil", "memorias": "memórias", "decisoes": "decisões", "projetos": "projetos",
                     "conhecimento": "conhecimento", "compactacoes": "compactações", "relatorios": "relatórios",
                     "origem": "origem", "prompts": "histórico"}

_BODY_CACHE = {}


# --------------------------------------------------------------------------- índice
def _newest_md_mtime():
    newest = 0.0
    try:
        for p in common.list_docs():
            try:
                m = os.path.getmtime(p)
                if m > newest:
                    newest = m
            except Exception:
                pass
    except Exception:
        pass
    return newest


def _index_is_fresh(index):
    if not isinstance(index, dict) or not isinstance(index.get("docs"), list) or not isinstance(index.get("meta"), dict):
        return False
    gen = common.parse_iso(index.get("generated") or "")
    if gen is None:
        return False
    newest = _newest_md_mtime()
    if newest <= 0:
        return True
    return (newest - gen.timestamp()) <= INDEX_STALE_S


def _rebuild_index(deadline_s):
    try:
        import refine  # escrito por outro construtor; contrato: build_index(deadline=None, write=True) -> dict
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"message": "refine.py indisponivel para reconstruir o indice"})
        return None
    try:
        try:
            idx = refine.build_index(deadline=deadline_s, write=False)
        except TypeError:
            idx = refine.build_index(deadline=deadline_s)
        if isinstance(idx, dict) and isinstance(idx.get("docs"), list):
            return idx
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"message": "refine.build_index falhou"})
    return None


def load_index(deadline=None):
    """index.json via load_json; ausente/ilegível/velho (> 60 s que o .md mais novo) → refine.build_index em memória."""
    idx = common.load_json(common.P["index_json"], None, script=SCRIPT)
    if _index_is_fresh(idx):
        return idx
    remaining = 1.5
    if deadline is not None:
        remaining = max(0.2, min(1.5, deadline - time.monotonic()))
    rebuilt = _rebuild_index(remaining)
    if rebuilt is not None:
        return rebuilt
    if isinstance(idx, dict) and isinstance(idx.get("docs"), list) and isinstance(idx.get("meta"), dict):
        return idx  # velho, mas melhor que nada
    common.log_error(SCRIPT, RuntimeError("indice ausente e reconstrucao impossivel"), extra={"file": "memoria/.cache/index.json"})
    return None


# --------------------------------------------------------------------------- pontuação
def _is_prompt(doc_id, m):
    return str(doc_id).startswith("prompt:") or (m or {}).get("collection") == "prompts"


def _active(m):
    return str((m or {}).get("status") or "active") == "active"


def _created_key(m):
    return str((m or {}).get("created") or "")


def _recency(created):
    days = common.dias_desde(created)
    if days is None:
        return 0.8
    if days <= 30:
        return 1.0
    if days >= 365:
        return 0.6
    return 1.0 - 0.4 * (days - 30.0) / 335.0


def _confidence(m):
    try:
        c = float(m.get("confidence") if m.get("confidence") is not None else 0.7)
    except Exception:
        c = 0.7
    return max(0.0, min(1.0, c))


def bm25_raw(index, q_terms):
    """Σ_t idf(t) · tf_w·(k1+1) / (tf_w + k1·(1 − b + b·len/avgdl)) — sobre TODOS os docs do índice."""
    docs = index.get("docs") or []
    meta = index.get("meta") or {}
    df_map = index.get("df") or {}
    postings = index.get("postings") or {}
    try:
        N = float(index.get("N") or len(docs)) or 1.0
    except Exception:
        N = float(len(docs)) or 1.0
    try:
        avgdl = float(index.get("avgdl") or 1.0) or 1.0
    except Exception:
        avgdl = 1.0
    scores = {}
    for t in q_terms:
        plist = postings.get(t)
        if not plist:
            continue
        try:
            df = float(df_map.get(t) or len(plist))
        except Exception:
            df = float(len(plist))
        idf = math.log(1.0 + (N - df + 0.5) / (df + 0.5))
        if idf <= 0:
            continue
        for entry in plist:
            try:
                di, tf = entry[0], float(entry[1])
            except Exception:
                continue
            try:
                doc_id = docs[int(di)]
            except Exception:
                continue
            m = meta.get(doc_id) or {}
            try:
                dl = float(m.get("len") or avgdl)
            except Exception:
                dl = avgdl
            denom = tf + K1 * (1.0 - B + B * dl / avgdl)
            if denom <= 0:
                continue
            scores[doc_id] = scores.get(doc_id, 0.0) + idf * tf * (K1 + 1.0) / denom
    return scores


def _doc_path(m):
    p = (m or {}).get("path")
    if not p:
        return None
    if os.path.isabs(p):
        return p
    return os.path.join(common.ROOT, p)


def _read_doc(doc_id, m):
    """(frontmatter, body) do arquivo; cache por chamada. Ausente → ({}, '')."""
    if doc_id in _BODY_CACHE:
        return _BODY_CACHE[doc_id]
    fm, body = {}, ""
    path = _doc_path(m)
    if path:
        txt = common.read_text(path)
        if txt is not None:
            f, b = common.read_frontmatter(txt)
            fm = f if isinstance(f, dict) else {}
            body = b or ""
    _BODY_CACHE[doc_id] = (fm, body)
    return fm, body


def _situation(doc_id, m):
    s = (m or {}).get("situation")
    if s:
        return str(s)
    fm, _ = _read_doc(doc_id, m)
    return str(fm.get("situation") or "")


def _cited(doc_id, m, q_set, folded_text):
    """O prompt cita o slug do projeto ou uma de suas tags."""
    sid = str(doc_id)
    if sid and re.search(r"(?<![a-z0-9])" + re.escape(common._fold(sid)) + r"(?![a-z0-9])", folded_text):
        return True
    id_tokens = set(common.tokenize(sid.replace("-", " "), expand=False))
    if id_tokens and id_tokens <= q_set:
        return True
    for tag in (m.get("tags") or []):
        for tk in common.tokenize(str(tag).replace("-", " "), expand=False):
            if tk in q_set:
                return True
    return False


def score_content(index, q_terms, text):
    """Docs de conteúdo (nunca prompts), só status active, com os multiplicadores de §11.5 passo 4."""
    meta = index.get("meta") or {}
    raw = bm25_raw(index, q_terms)
    q_set = set(q_terms)
    folded = common._fold(text or "")
    out = {}
    for doc_id, s in raw.items():
        m = meta.get(doc_id) or {}
        if _is_prompt(doc_id, m) or not _active(m):
            continue
        col = str(m.get("collection") or "memorias")
        w = common.COLLECTION_WEIGHTS.get(col, 1.0)
        s2 = s * w * (0.6 + 0.4 * _confidence(m)) * _recency(m.get("created"))
        if m.get("pinned") is True or str(m.get("pinned")).lower() == "true":
            s2 *= 1.15
        t = str(m.get("type") or "")
        if t in ("profile", "preference", "decision"):
            s2 += 0.3
        if t == "project" or col == "projetos":
            if _situation(doc_id, m) == "in-progress" and _cited(doc_id, m, q_set, folded):
                s2 += 0.5
        out[doc_id] = s2
    return out


def _sort_items(items, meta):
    """Ordena por (−score, −created, id) com sorts estáveis (created vazio vai para o fim)."""
    items = list(items)
    items.sort(key=lambda x: x[0])
    items.sort(key=lambda x: _created_key(meta.get(x[0])), reverse=True)
    items.sort(key=lambda x: -x[1])
    return items


def rank(index, q_terms, text, k):
    """Corte score ≥ max(1, 0.15·top); ordena por (−score, −created, id); top-k."""
    scores = score_content(index, q_terms, text)
    if not scores:
        return []
    top = max(scores.values())
    cut = max(1.0, 0.15 * top)
    items = [(d, s) for d, s in scores.items() if s >= cut]
    items = _sort_items(items, index.get("meta") or {})
    return items[:k]


# --------------------------------------------------------------------------- grafo
def _norm_node(x):
    s = str(x or "")
    if s.startswith("project:"):
        return s[len("project:"):]
    return s


def load_graph_adjacency():
    """{doc_id: {vizinho: peso}} só para arestas link/project (1 salto, sem direção)."""
    g = common.load_json(common.P["graph"], None, script=SCRIPT)
    adj = {}
    if not isinstance(g, dict):
        return adj
    for e in (g.get("edges") or []):
        try:
            if str(e.get("type")) not in ("link", "project"):
                continue
            a, b = _norm_node(e.get("from")), _norm_node(e.get("to"))
            if not a or not b or a.startswith("tag:") or b.startswith("tag:") or a == b:
                continue
            w = float(e.get("weight") or 1.0)
            adj.setdefault(a, {})
            adj.setdefault(b, {})
            adj[a][b] = max(adj[a].get(b, 0.0), w)
            adj[b][a] = max(adj[b].get(a, 0.0), w)
        except Exception:
            continue
    return adj


def expand(index, ranked, adj, k):
    """Vizinhos dos 3 primeiros entram com 0,5·score·peso (mínimo 0,3); reordena; corta em k."""
    meta = index.get("meta") or {}
    present = dict(ranked)
    added = {}
    for doc_id, s in ranked[:3]:
        for nb, w in (adj.get(doc_id) or {}).items():
            if nb in present or nb in added:
                continue
            m = meta.get(nb)
            if not m or _is_prompt(nb, m) or not _active(m):
                continue
            cand = max(0.3, 0.5 * s * w)
            if cand > added.get(nb, 0.0):
                added[nb] = cand
    if not added:
        return list(ranked), []
    merged = list(ranked) + list(added.items())
    merged = _sort_items(merged, meta)[:k]
    kept = set(d for d, _ in merged)
    return merged, [d for d in added if d in kept]


def crossings(final, adj, meta):
    """Componentes ligadas (link/project) entre os docs da lista → cadeias 'tipo `id` ↔ tipo `id`'."""
    ids = [d for d, _ in final]
    idset = set(ids)
    seen = set()
    chains = []
    for d in ids:
        if d in seen:
            continue
        comp, stack = [], [d]
        seen.add(d)
        while stack:
            x = stack.pop()
            comp.append(x)
            for nb in (adj.get(x) or {}):
                if nb in idset and nb not in seen:
                    seen.add(nb)
                    stack.append(nb)
        if len(comp) >= 2:
            comp.sort(key=lambda z: ids.index(z))
            chains.append(" ↔ ".join("%s `%s`" % (_type_label(meta.get(z) or {}), z) for z in comp[:5]))
    return chains[:3]


# --------------------------------------------------------------------------- histórico
def history(index, q_terms, deadline=None):
    """Mesma pontuação só na coleção prompts; times ≤ 20 (score ≥ 0,5·top), last e 'última vez' via turns.jsonl."""
    meta = index.get("meta") or {}
    raw = bm25_raw(index, q_terms)
    hits = []
    for doc_id, s in raw.items():
        m = meta.get(doc_id) or {}
        if _is_prompt(doc_id, m):
            hits.append((doc_id, s, m))
    if not hits:
        return {"times": 0, "last": None}
    top = max(s for _, s, _ in hits)
    related = [(d, s, m) for d, s, m in hits if s >= 0.5 * top and s > 0]
    if not related:
        return {"times": 0, "last": None}
    related.sort(key=lambda x: (str(x[2].get("created") or x[2].get("ts") or ""), x[0]), reverse=True)
    newest_id, _, newest_m = related[0]
    last_raw = str(newest_m.get("created") or newest_m.get("ts") or "")
    last = last_raw[:10] if last_raw else None
    h = {"times": min(20, len(related)), "last": last}
    pid = newest_m.get("prompt_id") or (newest_id[len("prompt:"):] if newest_id.startswith("prompt:") else None)
    if pid and (deadline is None or time.monotonic() < deadline):
        head = _turn_head(pid)
        if head:
            h["response_head"] = head
    return h


def _turn_head(prompt_id):
    path = common.P["turns"]
    try:
        if not os.path.exists(path):
            return None
        size = os.path.getsize(path)
        rows = common.read_jsonl(path) if size <= 4 * 1024 * 1024 else common.tail_jsonl(path, 4 * 1024 * 1024)
        for row in reversed(rows):
            if isinstance(row, dict) and row.get("prompt_id") == prompt_id and row.get("response_head"):
                return common.truncate(re.sub(r"\s+", " ", common.redact(row.get("response_head"))).strip(), 120)
    except Exception:
        pass
    return None


# --------------------------------------------------------------------------- pendências
_OPEN_ITEM = re.compile(r"^\s*-\s*\[ \]\s*(.+?)\s*$")


def open_items(doc_id, m, limit=3):
    _, body = _read_doc(doc_id, m)
    items = []
    for line in body.split("\n"):
        mt = _OPEN_ITEM.match(line)
        if mt:
            items.append(mt.group(1).strip())
            if len(items) >= limit:
                break
    return items


def _agenda_open():
    rows = common.read_jsonl(common.P["agenda"])
    state = {}
    for r in rows:
        if not isinstance(r, dict) or not r.get("id"):
            continue
        ev = r.get("event")
        if ev == "new":
            state[r["id"]] = dict(r)
        elif ev == "done":
            state.pop(r["id"], None)
    return list(state.values())


def linked_pending(final, meta):
    """- [ ] de projetos no top-k + agenda aberta que compartilhe tag/projeto com os docs do top-k."""
    lines = []
    proj_ids = set()
    tag_set = set()
    for doc_id, _ in final:
        m = meta.get(doc_id) or {}
        if str(m.get("type")) == "project" or m.get("collection") == "projetos":
            proj_ids.add(doc_id)
            for it in open_items(doc_id, m):
                lines.append("- [ ] %s: %s" % (doc_id, common.truncate(it, 120)))
        if m.get("project"):
            proj_ids.add(str(m.get("project")))
        for tag in (m.get("tags") or []):
            for tk in common.tokenize(str(tag).replace("-", " "), expand=False):
                tag_set.add(tk)
    try:
        for ag in _agenda_open():
            text = str(ag.get("text") or "")
            ag_proj = str(ag.get("project") or "")
            ag_tags = set()
            for tag in (ag.get("tags") or []):
                ag_tags.update(common.tokenize(str(tag).replace("-", " "), expand=False))
            toks = set(common.tokenize(text, expand=False))
            hit = (ag_proj and ag_proj in proj_ids) or bool(ag_tags & tag_set) or bool(toks & tag_set) \
                or any(common._fold(p) in common._fold(text) for p in proj_ids if p)
            if hit:
                lines.append("- [ ] %s · %s (%s)" % (common.fmt_ddmm(str(ag.get("when") or "")), common.truncate(text, 100), ag.get("id")))
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"file": "memoria/log/agenda.jsonl"})
    return lines[:8]


# --------------------------------------------------------------------------- renderização
def _type_label(m):
    t = str(m.get("type") or "")
    if not t and m.get("collection") == "projetos":
        t = "project"
    return common.label_type(t) if t else "memória"


def _clean_body(body, limit):
    b = re.sub(r"^\s*#{1,6}\s*", "", body or "", flags=re.M)
    b = re.sub(r"\s+", " ", b).strip()
    return common.truncate(common.redact(b), limit)


def _situation_text(body):
    mt = re.search(r"^##\s*Situa[cç][aã]o\s*\n(.*?)(?=^##\s|\Z)", body or "", flags=re.M | re.S)
    return mt.group(1) if mt else (body or "")


def _body_for(doc_id, m, limit):
    fm, body = _read_doc(doc_id, m)
    if str(m.get("type")) == "project" or m.get("collection") == "projetos":
        txt = _clean_body(_situation_text(body), limit)
        if not txt:
            txt = _clean_body(str(m.get("summary") or fm.get("summary") or ""), limit)
        return txt
    txt = _clean_body(body, limit)
    if not txt:
        txt = _clean_body(str(m.get("head") or ""), limit)
    return txt


def _item_line(n, doc_id, m):
    title = str(m.get("title") or doc_id).replace("\n", " ").strip()
    if str(m.get("type")) == "project" or m.get("collection") == "projetos":
        sit = _situation(doc_id, m)
        tag = "projeto" + (" · " + SITUATION_LABELS.get(sit, sit) if sit else "")
        pend = open_items(doc_id, m, limit=1)
        extra = (" — pendência: " + common.truncate(pend[0], 80)) if pend else ""
        return "%d. [%s] **%s**%s (`%s`)" % (n, tag, common.truncate(title, 90), extra, doc_id)
    conf = _confidence(m)
    date = common.fmt_ddmm(str(m.get("created") or ""))
    return "%d. [%s · %.1f · %s] **%s** (`%s`)" % (n, _type_label(m), conf, date, common.truncate(title, 90), doc_id)


def render(index, final, expanded, hist, pend, budget, body_chars, body_all=False, body_none=False):
    """Monta o markdown; corta de baixo para cima até caber no orçamento (rodapé sempre fica)."""
    if not final:
        return ""
    meta = index.get("meta") or {}
    total_docs = sum(1 for d, m in meta.items() if not _is_prompt(d, m) and _active(m))
    header = "🧠 Gabriel lembra (cruzou %d memórias · %d ligadas a este pedido)" % (total_docs, len(final))
    sections = []
    lines = ["### Mais ligado ao pedido"]
    for n, (doc_id, s) in enumerate(final, 1):
        m = meta.get(doc_id) or {}
        lines.append(_item_line(n, doc_id, m))
        if not body_none and (body_all or n <= 3):
            b = _body_for(doc_id, m, body_chars)
            if b:
                lines.append("   " + b)
    sections.append(lines)
    adj = load_graph_adjacency()
    cr = crossings(final, adj, meta)
    if cr:
        sections.append(["### Cruzamentos"] + cr)
    if hist.get("times"):
        vezes = "%d vez" % hist["times"] if hist["times"] == 1 else "%d vezes" % hist["times"]
        s = "Você já tratou disso %s" % vezes
        if hist.get("last"):
            s += "; última em %s" % common.fmt_ddmm(hist["last"])
        if hist.get("response_head"):
            s += ' — "%s"' % hist["response_head"].replace('"', "'")
        sections.append(["### Histórico", s])
    if pend:
        sections.append(["### Pendências ligadas"] + list(pend))

    def assemble():
        out = [header]
        for sec in sections:
            if len(sec) > 1:
                out.extend(sec)
        out.append(FOOTER)
        return "\n".join(out)

    text = assemble()
    while len(text) > budget:
        # remove a última linha de conteúdo (de baixo para cima); seção vazia some junto
        removed = False
        for sec in reversed(sections):
            if len(sec) > 1:
                sec.pop()
                removed = True
                break
        if not removed:
            break
        if len(sections[0]) <= 1:
            return ""
        text = assemble()
    return text


# --------------------------------------------------------------------------- API de módulo
def recall(text, k=None, budget=None, session=None, body=False, ids_only=False, _record=False):
    """{context, ids, expanded, history, ms} (+ top, chars, terms)."""
    t0 = time.monotonic()
    deadline = t0 + TIMEOUT_S
    cfg = common.load_config()
    k = int(k or cfg.get("top_k") or 6)
    budget = int(budget or cfg.get("recall_budget_chars") or 6000)
    body_chars = int(cfg.get("recall_body_chars_top3") or 500)
    empty = {"context": "", "ids": [], "expanded": [], "history": {"times": 0, "last": None}, "ms": 0, "top": [], "chars": 0, "terms": []}
    text = (text or "").strip()
    q = common.tokenize(text)
    empty["terms"] = q
    if not q:
        empty["ms"] = int((time.monotonic() - t0) * 1000)
        return empty
    index = load_index(deadline)
    if index is None:
        empty["ms"] = int((time.monotonic() - t0) * 1000)
        return empty
    ranked = rank(index, q, text, k)
    if not ranked:
        empty["ms"] = int((time.monotonic() - t0) * 1000)
        if _record:
            _record_recall(session, q, [], [], empty["history"], 0, empty["ms"])
        return empty
    meta = index.get("meta") or {}
    adj = load_graph_adjacency()
    final, expanded = expand(index, ranked, adj, k)
    hist = {"times": 0, "last": None}
    if time.monotonic() < deadline:
        hist = history(index, q, deadline)
    pend = []
    if time.monotonic() < deadline:
        pend = linked_pending(final, meta)
    context = render(index, final, expanded, hist, pend, budget, body_chars, body_all=body, body_none=ids_only)
    ms = int((time.monotonic() - t0) * 1000)
    if not context:
        # orçamento não coube nem o primeiro item: nada foi injetado, nada é auditado como injetado
        final, expanded = [], []
    top = [[d, round(s, 2)] for d, s in final if d not in set(expanded)]
    res = {"context": context, "ids": [d for d, _ in final], "expanded": list(expanded),
           "history": {"times": hist.get("times", 0), "last": hist.get("last")}, "ms": ms,
           "top": top, "chars": len(context), "terms": q}
    if _record:
        _record_recall(session, q, top, res["expanded"], res["history"], len(context), ms)
    return res


def _record_recall(session, terms, top, expanded, hist, chars, ms):
    try:
        sid = common.sid8(session or common.session_id_fallback())
        turn = common.load_json(os.path.join(common.P["cache"], "turn-%s.json" % sid), {}, script=SCRIPT) or {}
        row = {"ts": common.now_iso(), "session": sid, "prompt_id": turn.get("current_prompt") if isinstance(turn, dict) else None,
               "query_terms": list(terms)[:40], "top": top, "expanded": expanded, "history": hist, "chars": chars, "ms": ms}
        common.append_jsonl(common.P["recalls"], row)
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"file": "memoria/log/recalls.jsonl"})


def recent(n, index=None):
    """N docs de conteúdo mais recentes por created: [{id, title, type, created, collection}]."""
    index = index or load_index()
    if not index:
        return []
    meta = index.get("meta") or {}
    rows = [(d, m) for d, m in meta.items() if not _is_prompt(d, m) and _active(m)]
    rows.sort(key=lambda x: (_created_key(x[1]), x[0]), reverse=True)
    return [{"id": d, "title": str(m.get("title") or d), "type": str(m.get("type") or ""), "created": str(m.get("created") or ""),
             "collection": str(m.get("collection") or "")} for d, m in rows[:max(0, int(n))]]


def slices(text, n, k=40):
    """Top-k (40) agrupados em n fatias por projeto/coleção → {"fatias": [{"nome", "arquivos"}]}."""
    index = load_index()
    if not index:
        return {"fatias": []}
    meta = index.get("meta") or {}
    if text and common.tokenize(text):
        q = common.tokenize(text)
        ranked = rank(index, q, text, k)
        adj = load_graph_adjacency()
        ranked, _ = expand(index, ranked, adj, k)
        docs = [d for d, _ in ranked]
    else:
        docs = [r["id"] for r in recent(k, index)]
    groups = {}
    order = []
    for d in docs:
        m = meta.get(d) or {}
        path = _doc_path(m)
        if not path:
            continue
        if str(m.get("type")) == "project" or m.get("collection") == "projetos":
            key = "projeto " + d
        elif m.get("project"):
            key = "projeto " + str(m.get("project"))
        else:
            key = COLLECTION_LABELS.get(str(m.get("collection") or ""), str(m.get("collection") or "memórias"))
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(path)
    n = max(1, int(n or 1))
    ordered = sorted(order, key=lambda kk: (-len(groups[kk]), order.index(kk)))
    fatias = []
    if len(ordered) > n:
        for kk in ordered[:n - 1]:
            fatias.append({"nome": kk, "arquivos": groups[kk]})
        rest = []
        for kk in ordered[n - 1:]:
            rest.extend(groups[kk])
        fatias.append({"nome": "outros", "arquivos": rest})
    else:
        for kk in ordered:
            fatias.append({"nome": kk, "arquivos": groups[kk]})
    return {"fatias": fatias}


# --------------------------------------------------------------------------- CLI
def _parse_args(argv):
    ap = argparse.ArgumentParser(prog="recall.py", add_help=False)
    ap.add_argument("--prompt-stdin", action="store_true")
    ap.add_argument("--search", default=None)
    ap.add_argument("--k", type=int, default=None)
    ap.add_argument("--body", action="store_true")
    ap.add_argument("--ids", action="store_true")
    ap.add_argument("--recent", type=int, default=None)
    ap.add_argument("--slices", type=int, default=None)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--session", default=None)
    ap.add_argument("--budget", type=int, default=None)
    ap.add_argument("-h", "--help", action="store_true")
    args, _unknown = ap.parse_known_args(argv)
    return args


def _print(s):
    try:
        sys.stdout.write(s)
        if not s.endswith("\n"):
            sys.stdout.write("\n")
        sys.stdout.flush()
    except Exception:
        pass


def _dump(obj):
    _print(json.dumps(obj, ensure_ascii=False))


def main():
    args = _parse_args(sys.argv[1:])
    if args.help:
        _print(__doc__ or "")
        return
    cfg = common.load_config()

    if args.recent is not None:
        rows = recent(args.recent)
        if args.json:
            _dump(rows)
            return
        if not rows:
            _print("(ainda não há memórias registradas)")
            return
        _print("\n".join("- [%s · %s] **%s** (`%s`)" % (common.label_type(r["type"]) if r["type"] else "memória",
                                                        common.fmt_ddmm(r["created"]), common.truncate(r["title"], 90), r["id"]) for r in rows))
        return

    if args.slices is not None:
        _dump(slices(args.search or "", args.slices, k=args.k or 40))
        return

    if args.prompt_stdin:
        try:
            text = sys.stdin.read()
        except Exception:
            text = ""
        text = (text or "").strip()
        min_words = int(cfg.get("recall_min_words") or 4)
        if text.lstrip().startswith("/") or len(text.split()) < min_words:
            res = {"context": "", "ids": [], "expanded": [], "history": {"times": 0, "last": None}, "ms": 0}
            if args.json:
                _dump(res)
            return
        res = recall(text, k=args.k, budget=args.budget, session=args.session, _record=True)
        if args.json:
            _dump({"context": res["context"], "ids": res["ids"], "expanded": res["expanded"], "history": res["history"],
                   "ms": res["ms"], "top": res.get("top", []), "chars": res.get("chars", 0), "terms": res.get("terms", [])})
        elif res["context"]:
            _print(res["context"])
        return

    if args.search is not None:
        k = args.k or (2 * int(cfg.get("top_k") or 6))
        res = recall(args.search, k=k, budget=args.budget, session=args.session, body=args.body, ids_only=args.ids)
        if args.json:
            out = {"context": res["context"], "ids": res["ids"], "expanded": res["expanded"], "history": res["history"], "ms": res["ms"],
                   "top": res.get("top", []), "chars": res.get("chars", 0)}
            if args.ids:
                out["context"] = ""
            _dump(out)
            return
        if args.ids:
            if res["ids"]:
                _print("\n".join(res["ids"]))
            return
        if res["context"]:
            _print(res["context"])
        else:
            _print("🧠 Nada na memória ainda sobre isso.")
        return

    _print("uso: recall.py --prompt-stdin | --search \"<termo>\" [--k N] [--body] [--ids] | --recent N | --slices N [--json] [--session ID] [--budget N]")


if __name__ == "__main__":
    try:
        main()
    except BaseException as e:
        try:
            common.log_error(SCRIPT, e)
        except Exception:
            pass
    sys.exit(0)
