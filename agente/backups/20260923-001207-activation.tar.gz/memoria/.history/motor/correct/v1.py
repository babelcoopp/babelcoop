#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
correct.py — corrige a memória sem apagar nada (spec §11.8).

  --forget <id> --reason "…"      marca status: superseded (superseded_by vazio) + reason, versionado
  --supersede <id> --text "…"     cria <id>-corrigido-<n> (type herdado, links [id], supersedes id, confidence 0.95)
  --merge <novo> <antigo>         incorpora o corpo do novo no antigo (## Incorporado de <novo>) e supera o novo
  [--session ID] [--json]

Id inexistente → imprime os 5 ids mais parecidos e `erro`. Sempre exit 0.
"""
import os, sys, re, json, time, argparse, difflib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common
import remember as rm

SCRIPT = "correct.py"


def bump_and_write(doc_id, path, meta, body, old_text, old_version):
    """Reescreve o doc com version+1, updated, hash — guardando a versão atual em .history antes."""
    meta = dict(meta)
    meta["id"] = meta.get("id") or doc_id
    meta["version"] = int(old_version or 0) + 1
    meta["updated"] = common.now_iso()
    meta["hash"] = common.body_hash(body)
    new_text = common.write_frontmatter(meta, body)
    rm.snapshot_before_update(doc_id, old_text, old_version)
    common.write_atomic(path, new_text)
    rm.set_seen(doc_id, new_text)   # a versão anterior já está em .history; só avança a "última vista"
    return new_text


def version_of(meta):
    try:
        return int((meta or {}).get("version") or 0)
    except Exception:
        return 0


def similar_by_id(doc_id, k=5):
    """5 ids mais parecidos: BM25 sobre id/título no índice; sem índice, difflib sobre os ids/títulos existentes."""
    out = []
    try:
        index = common.load_json(common.P["index_json"], None, script=SCRIPT)
        query = common.tokenize(re.sub(r"[-_]", " ", str(doc_id)))
        if isinstance(index, dict) and query:
            out = [d for d, _ in rm.bm25_top(index, query, k=k)]
        if len(out) < k:
            cands = []
            q = rm.fold(re.sub(r"[-_]", " ", str(doc_id)))
            for p in rm.all_doc_paths():
                did = common.doc_id_from_path(p)
                if did in out:
                    continue
                title = ""
                try:
                    head = common.read_text(p) or ""
                    m, _ = common.read_frontmatter(head)
                    title = str((m or {}).get("title") or "")
                except Exception:
                    pass
                score = max(difflib.SequenceMatcher(None, q, rm.fold(did.replace("-", " "))).ratio(),
                            difflib.SequenceMatcher(None, q, rm.fold(title)).ratio() if title else 0.0)
                cands.append((-score, did))
            cands.sort()
            for _, did in cands:
                if len(out) >= k:
                    break
                out.append(did)
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"message": "similar_by_id"})
    return out[:k]


def not_found(doc_id):
    sims = similar_by_id(doc_id)
    return {"ok": False, "error": "id não encontrado: %s" % doc_id, "parecidos": sims}


def do_forget(doc_id, reason, sid):
    path = rm.find_doc(doc_id)
    if not path:
        return not_found(doc_id)
    meta, body, text = rm.load_doc(path)
    if text is None:
        return {"ok": False, "error": "não consegui ler %s" % common.rel(path)}
    old_version = version_of(meta)
    meta = dict(meta)
    meta["status"] = "superseded"
    meta["superseded_by"] = None
    meta["reason"] = common.escape_at(common.redact(common.truncate(re.sub(r"\s+", " ", reason or "pedido do Marcelo").strip(), 200)))
    meta["session"] = sid
    bump_and_write(doc_id, path, meta, body, text, old_version)
    rm.log_memory_event(sid, doc_id, path, "forget %s: %s" % (doc_id, meta["reason"]), extra={"action": "forget"})
    rm.mark_memory_in_turn(sid, doc_id)
    return {"ok": True, "id": doc_id, "path": common.rel(path), "action": "forget"}


def do_supersede(doc_id, text, sid):
    path = rm.find_doc(doc_id)
    if not path:
        return not_found(doc_id)
    old_meta, old_body, old_text = rm.load_doc(path)
    if old_text is None:
        return {"ok": False, "error": "não consegui ler %s" % common.rel(path)}
    text = (text or "").replace("\r\n", "\n").strip()
    if not text:
        return {"ok": False, "error": "faltou --text com a correção"}
    if common.looks_secret(text):
        return {"ok": False, "error": "parece segredo"}
    body = common.escape_at(common.redact(text)).rstrip("\n") + "\n"
    ids = rm.existing_ids()
    n = 1
    new_id = "%s-corrigido-%d" % (doc_id, n)
    while new_id in ids:
        n += 1
        new_id = "%s-corrigido-%d" % (doc_id, n)
    new_path = os.path.join(os.path.dirname(path), new_id + ".md")
    typ = old_meta.get("type") if old_meta.get("type") in common.TYPES else "fact"
    now = common.now_iso()
    meta = {"id": new_id, "type": typ, "title": old_meta.get("title") or rm.first_sentence(body, 90)}
    if "summary" in old_meta and old_meta.get("summary"):
        meta["summary"] = old_meta["summary"]
    meta["tags"] = rm.norm_tags([str(t) for t in (old_meta.get("tags") or [])] + [typ])
    meta["confidence"] = 0.95
    meta["status"] = "active"
    meta["source"] = "marcelo-said"
    meta["session"] = sid
    for k in ("project", "situation", "files", "sources", "topic"):
        if old_meta.get(k) not in (None, "", []):
            meta[k] = old_meta[k]
    links = [doc_id]
    for l in [str(x) for x in (old_meta.get("links") or [])] + rm.extract_wikilinks(body):
        if l not in links:
            links.append(l)
    meta["links"] = links
    meta["supersedes"] = doc_id
    meta["pinned"] = bool(old_meta.get("pinned")) if isinstance(old_meta.get("pinned"), bool) else False
    meta["created"] = now
    meta["updated"] = now
    meta["version"] = 1
    meta["hash"] = common.body_hash(body)
    new_text = common.write_frontmatter(meta, body)
    common.write_atomic(new_path, new_text)
    rm.set_seen(new_id, new_text)
    # marca o antigo já aqui (o refinador faria o mesmo no passo 5; assim o resultado é imediato)
    try:
        om = dict(old_meta)
        om["status"] = "superseded"
        om["superseded_by"] = new_id
        bump_and_write(doc_id, path, om, old_body, old_text, version_of(old_meta))
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"file": doc_id, "message": "marcar antigo como superseded"})
    rm.log_memory_event(sid, new_id, new_path, "supersede %s -> %s" % (doc_id, new_id), extra={"action": "supersede", "supersedes": doc_id})
    rm.mark_memory_in_turn(sid, new_id)
    return {"ok": True, "id": new_id, "path": common.rel(new_path), "action": "supersede", "supersedes": doc_id}


def do_merge(new_id, old_id, sid):
    if new_id == old_id:
        return {"ok": False, "error": "os dois ids são iguais"}
    new_path = rm.find_doc(new_id)
    if not new_path:
        return not_found(new_id)
    old_path = rm.find_doc(old_id)
    if not old_path:
        return not_found(old_id)
    nm, nb, nt = rm.load_doc(new_path)
    om, ob, ot = rm.load_doc(old_path)
    if nt is None or ot is None:
        return {"ok": False, "error": "não consegui ler um dos arquivos"}
    marker = "## Incorporado de %s" % new_id
    old_body = (ob or "").rstrip("\n")
    if marker in old_body:
        return {"ok": False, "error": "%s já foi incorporado em %s" % (new_id, old_id)}
    incorporated = (nb or "").strip("\n")
    old_body = old_body + "\n\n" + marker + "\n" + (incorporated if incorporated else "(sem corpo)") + "\n"
    om2 = dict(om)
    links = [str(l) for l in (om.get("links") or [])]
    if new_id not in links:
        links.append(new_id)
    om2["links"] = links
    tags = rm.norm_tags([str(t) for t in (om.get("tags") or [])] + [str(t) for t in (nm.get("tags") or [])])
    om2["tags"] = tags
    om2["session"] = sid
    bump_and_write(old_id, old_path, om2, old_body, ot, version_of(om))
    nm2 = dict(nm)
    nm2["status"] = "superseded"
    nm2["superseded_by"] = old_id
    nl = [str(l) for l in (nm.get("links") or [])]
    if old_id not in nl:
        nl.append(old_id)
    nm2["links"] = nl
    nm2["session"] = sid
    bump_and_write(new_id, new_path, nm2, nb or "", nt, version_of(nm))
    rm.log_memory_event(sid, old_id, old_path, "merge %s -> %s" % (new_id, old_id), extra={"action": "merge", "merged": new_id})
    rm.mark_memory_in_turn(sid, old_id)
    return {"ok": True, "id": old_id, "path": common.rel(old_path), "action": "merge", "merged": new_id}


def build_parser():
    ap = argparse.ArgumentParser(prog="correct.py")
    ap.add_argument("--forget", default=None, metavar="ID")
    ap.add_argument("--reason", default=None)
    ap.add_argument("--supersede", default=None, metavar="ID")
    ap.add_argument("--text", default=None)
    ap.add_argument("--merge", nargs=2, default=None, metavar=("NOVO", "ANTIGO"))
    ap.add_argument("--session", default=None)
    ap.add_argument("--json", dest="as_json", action="store_true")
    ap.add_argument("--no-refine", dest="no_refine", action="store_true", help=argparse.SUPPRESS)
    return ap


def emit(result, as_json):
    if as_json:
        print(json.dumps(result, ensure_ascii=False))
        return
    if result.get("ok"):
        line = "ok %s %s" % (result["id"], result["path"])
        if result.get("action") == "supersede":
            line += " supersedes %s" % result.get("supersedes")
        elif result.get("action") == "merge":
            line += " merged %s" % result.get("merged")
        print(line)
    else:
        if result.get("parecidos"):
            print("parecidos: " + ", ".join(result["parecidos"]))
        print("erro %s" % result.get("error", "desconhecido"))


def main():
    as_json = "--json" in sys.argv[1:]
    try:
        args = build_parser().parse_args()
        as_json = args.as_json
        sid = rm.resolve_session(args.session)
        t0 = time.monotonic()
        if args.forget:
            result = do_forget(args.forget.strip(), args.reason, sid)
        elif args.supersede:
            text = args.text
            if text is None:
                text = rm.read_stdin_text()
            result = do_supersede(args.supersede.strip(), text, sid)
        elif args.merge:
            result = do_merge(args.merge[0].strip(), args.merge[1].strip(), sid)
        else:
            result = {"ok": False, "error": "use --forget <id> --reason \"…\" | --supersede <id> --text \"…\" | --merge <novo> <antigo>"}
        if result.get("ok") and not args.no_refine:
            rm.run_refine("correct", timeout=3.0)
        result["ms"] = int((time.monotonic() - t0) * 1000)
        emit(result, as_json)
    except SystemExit:
        pass
    except BaseException as e:
        common.log_error(SCRIPT, e)
        emit({"ok": False, "error": "%s: %s" % (type(e).__name__, common.truncate(str(e), 200))}, as_json)
    sys.exit(0)


if __name__ == "__main__":
    main()
