#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
remember.py — grava memória / decisão / projeto / conhecimento / perfil no substrato (spec §11.7, §3.1).

Uso:
  remember.py --type T --title "…" [--tags a,b] [--text "…" | stdin] [--confidence 0.7] [--source S]
              [--session ID] [--project slug] [--links a,b] [--supersedes id] [--id slug] [--summary "…"]
              [--situation S] [--files a,b] [--next "a;b"] [--done "a;b"] [--next-replace]
              [--topic tema] [--sources "u1|u2"] [--pinned] [--json]

Saída: `ok <id> <caminho>` (+ ` updated`) ou `erro <motivo>`; `similar_to: …` quando há memória parecida.
Sempre exit 0.
"""
import os, sys, re, math, json, time, argparse, select, unicodedata, datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

SCRIPT = "remember.py"
SOURCES = ["marcelo-said", "conversation", "inference", "research", "auto-memory", "dossier", "compaction"]
SITUATIONS = ["idea", "in-progress", "delivered", "paused"]
COLLECTION_BY_TYPE = {"profile": "perfil", "project": "projetos", "knowledge": "conhecimento", "decision": "decisoes",
                      "compaction": "compactacoes", "report": "relatorios"}
DATED_COLLECTIONS = ("memorias", "decisoes", "compactacoes", "relatorios")


# --------------------------------------------------------------------------- helpers locais (também usados por correct.py)
def resolve_session(arg):
    return common.sid8(arg or common.session_id_fallback())


def fold(s):
    return "".join(c for c in unicodedata.normalize("NFKD", str(s or "")) if not unicodedata.combining(c)).lower()


def norm_tag(t):
    s = common.slug(t, 40)
    return None if (not s or s == "sem-nome") else s


def norm_tags(items):
    out = set()
    for t in items or []:
        n = norm_tag(t)
        if n:
            out.add(n)
    return sorted(out)


def split_list(s, sep=","):
    if s is None:
        return []
    if isinstance(s, (list, tuple)):
        raw = list(s)
    else:
        raw = str(s).split(sep)
    out = []
    for x in raw:
        x = str(x).strip()
        if x and x not in out:
            out.append(x)
    return out


def clamp_confidence(v, default=0.7):
    try:
        f = float(v)
    except Exception:
        return default
    if f != f:
        return default
    return max(0.0, min(1.0, round(f, 2)))


def read_stdin_text(wait=0.5):
    """Lê o stdin só se houver algo (nunca trava esperando um terminal)."""
    try:
        if sys.stdin is None or sys.stdin.isatty():
            return ""
        r, _, _ = select.select([sys.stdin], [], [], wait)
        if not r:
            return ""
        return sys.stdin.read()
    except Exception:
        return ""


def all_doc_paths():
    return common.list_docs()


def find_doc(doc_id):
    """Caminho absoluto do .md cujo nome é <doc_id>.md em qualquer coleção, ou None."""
    if not doc_id:
        return None
    for p in all_doc_paths():
        if common.doc_id_from_path(p) == doc_id:
            return p
    return None


def existing_ids():
    return set(common.doc_id_from_path(p) for p in all_doc_paths())


def load_doc(path):
    """(meta, body, text) ou (None, None, None)."""
    text = common.read_text(path)
    if text is None:
        return None, None, None
    meta, body = common.read_frontmatter(text)
    if meta is None:
        meta = {}
    return meta, body, text


def extract_wikilinks(body):
    return [m for m in re.findall(r"\[\[([A-Za-z0-9._-]+)\]\]", body or "")]


def snapshot_before_update(doc_id, current_text, version):
    """Guarda o arquivo ATUAL em .history/<id>/v<version>.md (se ainda não existir com o mesmo hash) e sincroniza
    .cache/texts/<id>.md — sem esperar o refinador (§11.7 passo 2). Nunca lança."""
    try:
        seen_path = os.path.join(common.P["cache_texts"], doc_id + ".md")
        seen = common.read_text(seen_path)
        if seen is not None and seen != current_text:
            sm, _ = common.read_frontmatter(seen)
            sv = (sm or {}).get("version") or 0
            common.history_snapshot(doc_id, current_text, sv)   # versão vista antes → history; texts = atual
        else:
            common.history_snapshot(doc_id, current_text, version)
        hdir = os.path.join(common.P["history"], doc_id)
        os.makedirs(hdir, exist_ok=True)
        target = os.path.join(hdir, "v%s.md" % (version if version else 0))
        if os.path.exists(target):
            if common.body_hash(common.read_text(target) or "") == common.body_hash(current_text):
                return True
            n = 0
            while os.path.exists(os.path.join(hdir, "v%s-%d.md" % (version, n))):
                if common.body_hash(common.read_text(os.path.join(hdir, "v%s-%d.md" % (version, n))) or "") == common.body_hash(current_text):
                    return True
                n += 1
            target = os.path.join(hdir, "v%s-%d.md" % (version, n))
        common.write_atomic(target, current_text)
        return True
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"file": doc_id, "message": "snapshot antes de atualizar"})
        return False


def set_seen(doc_id, text):
    """Atualiza .cache/texts/<id>.md (última versão vista pelo motor). Nunca lança."""
    try:
        os.makedirs(common.P["cache_texts"], exist_ok=True)
        common.write_atomic(os.path.join(common.P["cache_texts"], doc_id + ".md"), text)
        return True
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"file": doc_id, "message": "texts/<id>.md"})
        return False


def bm25_top(index, terms, k=5, exclude=(), k1=1.2, b=0.75):
    """Top-k [(id, score)] pelo BM25 do índice §3.8 (só docs de conteúdo; nunca prompt:*)."""
    try:
        docs = index.get("docs") or []
        meta = index.get("meta") or {}
        df = index.get("df") or {}
        postings = index.get("postings") or {}
        N = float(index.get("N") or len(docs) or 1)
        avgdl = float(index.get("avgdl") or 1.0) or 1.0
        scores = {}
        for t in set(terms or []):
            pl = postings.get(t)
            if not pl:
                continue
            d = float(df.get(t) or len(pl))
            idf = math.log(1.0 + (N - d + 0.5) / (d + 0.5))
            if idf <= 0:
                continue
            for entry in pl:
                try:
                    di, tf = entry[0], float(entry[1])
                except Exception:
                    continue
                doc = docs[di] if isinstance(di, int) and 0 <= di < len(docs) else str(di)
                if doc.startswith("prompt:") or doc in exclude:
                    continue
                L = float((meta.get(doc) or {}).get("len") or avgdl)
                scores[doc] = scores.get(doc, 0.0) + idf * tf * (k1 + 1) / (tf + k1 * (1 - b + b * L / avgdl))
        return sorted(scores.items(), key=lambda x: (-x[1], x[0]))[:k]
    except Exception as e:
        common.log_error(SCRIPT, e, extra={"message": "bm25"})
        return []


def jaccard(a, b):
    a, b = set(a), set(b)
    if not a and not b:
        return 0.0
    return len(a & b) / float(len(a | b))


def doc_tokens_from_index(index, doc_id):
    """Tokens (title + corpo) de um doc do índice: lê o arquivo pelo `path` do meta; fallback title+head+tags."""
    m = (index.get("meta") or {}).get(doc_id) or {}
    path = m.get("path")
    text = None
    if path:
        ap = path if os.path.isabs(path) else os.path.join(common.ROOT, path)
        text = common.read_text(ap)
    if text is None:
        p = find_doc(doc_id)
        text = common.read_text(p) if p else None
    if text is not None:
        meta, body = common.read_frontmatter(text)
        title = (meta or {}).get("title") or m.get("title") or ""
        return set(common.tokenize("%s %s" % (title, body)))
    return set(common.tokenize("%s %s %s" % (m.get("title") or "", m.get("head") or "", " ".join(m.get("tags") or []))))


def similar_ids(index, title, body, exclude=(), threshold=0.85, k=5):
    if not index:
        return []
    terms = common.tokenize(title or "")
    if not terms:
        return []
    mine = set(common.tokenize("%s %s" % (title or "", body or "")))
    out = []
    for doc, _score in bm25_top(index, terms, k=k, exclude=exclude):
        if jaccard(mine, doc_tokens_from_index(index, doc)) >= threshold:
            out.append(doc)
    return out


def current_prompt_of(sid):
    if not sid or sid == "unknown":
        return None
    t = common.load_json(os.path.join(common.P["cache"], "turn-%s.json" % sid), {}, script=SCRIPT) or {}
    return t.get("current_prompt")


def mark_memory_in_turn(sid, doc_id):
    """Adiciona o id a memories_by_prompt[current_prompt] no turn cache (redundância com o PostToolUse)."""
    if not sid or sid == "unknown":
        return False
    path = os.path.join(common.P["cache"], "turn-%s.json" % sid)
    if not os.path.exists(path):
        return False

    def fn(obj):
        cp = obj.get("current_prompt")
        if not cp:
            return obj
        mbp = obj.get("memories_by_prompt")
        if not isinstance(mbp, dict):
            mbp = {}
            obj["memories_by_prompt"] = mbp
        lst = mbp.get(cp)
        if not isinstance(lst, list):
            lst = []
            mbp[cp] = lst
        if doc_id not in lst:
            lst.append(doc_id)
        return obj
    return common.update_json_locked(path, fn, default={}, script=SCRIPT) is not None


def log_memory_event(sid, doc_id, path, summary, extra=None):
    ev = {"ts": common.now_iso(), "session": sid, "prompt_id": current_prompt_of(sid), "event": "memoria",
          "tool": None, "file": common.rel(path), "agent": None, "id": doc_id,
          "summary": common.truncate(common.redact(summary), 200)}
    if extra:
        ev.update(extra)
    return common.append_jsonl(common.P["events"], ev)


def run_refine(trigger, timeout=3.0):
    rc, out, err = common.run_motor("refine.py", ["--quick", "--trigger", trigger, "--quiet"], timeout=timeout)
    return rc == 0


def rarest_terms(index, text, n=3):
    """Os n termos do texto com menor df no índice (só termos que o índice conhece)."""
    if not index or not text:
        return []
    df = index.get("df") or {}
    if not isinstance(df, dict) or not df:
        return []
    cands = []
    for t in common.tokenize(text, expand=False):
        if len(t) < 4 or t.isdigit():
            continue
        d = df.get(t)
        if isinstance(d, (int, float)) and d > 0:
            cands.append((d, t))
    cands.sort()
    out = []
    for _, t in cands:
        if t not in out:
            out.append(t)
        if len(out) >= n:
            break
    return out


def first_sentence(text, limit=90):
    t = re.sub(r"\s+", " ", str(text or "")).strip()
    t = re.sub(r"^[#>*\-\s]+", "", t)
    m = re.match(r"(.+?[.!?])(\s|$)", t)
    s = m.group(1) if m else t
    return common.truncate(s.strip(), limit)


def fmt_hist_ts(dt=None):
    dt = dt or common.now()
    return dt.strftime("%d/%m %H:%M")


# --------------------------------------------------------------------------- corpo de projeto (## Situação / ## Próximos passos / ## Histórico)
SEC_SITUACAO, SEC_PROXIMOS, SEC_HISTORICO = "Situação", "Próximos passos", "Histórico"
_SEC_KEYS = {"situacao": SEC_SITUACAO, "proximos passos": SEC_PROXIMOS, "historico": SEC_HISTORICO}
_ITEM_RE = re.compile(r"^\s*-\s*\[( |x|X)\]\s*(.*?)\s*$")
_DONE_SUFFIX = re.compile(r"\s*\((?:conclu[ií]d[oa])\s+\d{2}/\d{2}(?:/\d{4})?\)\s*$", re.I)


def parse_sections(body):
    """[[title|None, [lines]]] — a primeira entrada é o preâmbulo (title None)."""
    sections = [[None, []]]
    for line in (body or "").split("\n"):
        m = re.match(r"^##\s+(.+?)\s*$", line)
        if m:
            sections.append([m.group(1).strip(), []])
        else:
            sections[-1][1].append(line)
    return sections


def section_key(title):
    k = fold(title).strip()
    k = re.sub(r"\s+", " ", k)
    return _SEC_KEYS.get(k)


def _trim(lines):
    out = list(lines)
    while out and not out[0].strip():
        out.pop(0)
    while out and not out[-1].strip():
        out.pop()
    return out


def render_sections(sections):
    parts = []
    for title, lines in sections:
        body = "\n".join(_trim(lines))
        if title is None:
            if body:
                parts.append(body)
            continue
        parts.append("## %s\n%s" % (title, body) if body else "## %s" % title)
    return "\n\n".join(parts).strip() + "\n"


def item_key(text):
    return common.slug(_DONE_SUFFIX.sub("", text or ""))


def merge_next_steps(lines, new_items, done_items, replace=False):
    """Mescla a lista `- [ ]` conforme §11.7: novos entram abertos; abertos que não vieram viram `- [x] … (concluído dd/mm)`
    (só quando há lista nova ou --next-replace); --done marca explicitamente. Nada some."""
    today_mark = common.now().strftime("%d/%m")
    new_keys = [item_key(x) for x in new_items]
    done_keys = set(item_key(x) for x in done_items)
    has_new_list = bool(new_items) or replace
    out = []
    open_keys, done_present = set(), set()
    for line in lines:
        m = _ITEM_RE.match(line)
        if not m:
            out.append(line)
            continue
        state, text = m.group(1), m.group(2)
        key = item_key(text)
        if state == " ":
            if key in done_keys or (has_new_list and key not in new_keys):
                out.append("- [x] %s (concluído %s)" % (text.strip(), today_mark))
                done_present.add(key)
            else:
                out.append("- [ ] %s" % text.strip())
                open_keys.add(key)
        else:
            out.append("- [x] %s" % text.strip())
            done_present.add(key)
    for item, key in zip(new_items, new_keys):
        if key in open_keys or key in done_keys:
            continue
        out.append("- [ ] %s" % item.strip())
        open_keys.add(key)
    for item in done_items:
        key = item_key(item)
        if key in open_keys or key in done_present:
            continue
        out.append("- [x] %s (concluído %s)" % (item.strip(), today_mark))
        done_present.add(key)
    return out


def ensure_project_sections(sections):
    have = set(section_key(t) for t, _ in sections if t)
    for name in (SEC_SITUACAO, SEC_PROXIMOS, SEC_HISTORICO):
        if name not in have:
            sections.append([name, []])
    return sections


def get_section(sections, name):
    for sec in sections:
        if sec[0] and section_key(sec[0]) == name:
            return sec
    return None


def build_project_body(old_body, text, next_items, done_items, replace, summary, title, creating):
    sections = ensure_project_sections(parse_sections(old_body or ""))
    sit = get_section(sections, SEC_SITUACAO)
    nxt = get_section(sections, SEC_PROXIMOS)
    hist = get_section(sections, SEC_HISTORICO)
    stamp = fmt_hist_ts()
    if creating:
        sit[1] = [text.strip() if text else (summary or title or "").strip()]
        hist[1] = _trim(hist[1]) + ["- %s — projeto criado" % stamp]
    elif text:
        prev = re.sub(r"\s+", " ", "\n".join(_trim(sit[1]))).strip()
        sit[1] = [text.strip()]
        note = common.truncate(prev, 120) if prev else "(situação anterior vazia)"
        hist[1] = _trim(hist[1]) + ["- %s — %s" % (stamp, note)]
    else:
        hist[1] = _trim(hist[1]) + ["- %s — atualização (%s)" % (stamp, "próximos passos" if (next_items or done_items or replace) else "dados")]
    if next_items or done_items or replace:
        nxt[1] = merge_next_steps(_trim(nxt[1]), next_items, done_items, replace=replace)
    elif creating:
        nxt[1] = []
    return render_sections(sections)


# --------------------------------------------------------------------------- CLI
def build_parser():
    ap = argparse.ArgumentParser(prog="remember.py", add_help=True)
    ap.add_argument("--type", dest="type_", default=None)
    ap.add_argument("--title", default=None)
    ap.add_argument("--tags", default=None)
    ap.add_argument("--text", default=None)
    ap.add_argument("--confidence", default=None)
    ap.add_argument("--source", default=None)
    ap.add_argument("--session", default=None)
    ap.add_argument("--project", default=None)
    ap.add_argument("--links", default=None)
    ap.add_argument("--supersedes", default=None)
    ap.add_argument("--id", dest="id_", default=None)
    ap.add_argument("--summary", default=None)
    ap.add_argument("--situation", default=None)
    ap.add_argument("--files", default=None)
    ap.add_argument("--next", dest="next_", default=None)
    ap.add_argument("--done", default=None)
    ap.add_argument("--next-replace", dest="next_replace", action="store_true")
    ap.add_argument("--topic", default=None)
    ap.add_argument("--sources", default=None)
    ap.add_argument("--pinned", action="store_true")
    ap.add_argument("--json", dest="as_json", action="store_true")
    ap.add_argument("--no-refine", dest="no_refine", action="store_true", help=argparse.SUPPRESS)
    return ap


def emit(result, as_json):
    if as_json:
        print(json.dumps(result, ensure_ascii=False))
        return
    if result.get("ok"):
        line = "ok %s %s" % (result["id"], result["path"])
        if result.get("updated"):
            line += " updated"
        print(line)
        if result.get("similar_to"):
            print("similar_to: " + ", ".join(result["similar_to"]))
    else:
        print("erro %s" % result.get("error", "desconhecido"))


def remember(args):
    t0 = time.monotonic()
    sid = resolve_session(args.session)
    typ = (args.type_ or "").strip().lower()
    if typ not in common.TYPES:
        return {"ok": False, "error": "tipo inválido '%s' (use: %s)" % (typ or "", ", ".join(common.TYPES))}

    # ---- texto (--text ou stdin)
    text = args.text
    if text is None:
        text = read_stdin_text()
    text = (text or "").replace("\r\n", "\n").strip()
    if text and common.looks_secret(text):
        return {"ok": False, "error": "parece segredo"}
    text = common.escape_at(common.redact(text))

    # ---- título
    title = (args.title or "").strip()
    if not title and text:
        title = first_sentence(text, 90)
    if not title:
        return {"ok": False, "error": "faltou --title (ou texto para derivar o título)"}
    title = common.escape_at(common.redact(re.sub(r"\s+", " ", title)))
    if len(title) > 90:
        title = common.truncate(title, 90)

    # ---- validações leves
    situation = (args.situation or "").strip().lower() or None
    if situation and situation not in SITUATIONS:
        return {"ok": False, "error": "situation inválida '%s' (use: %s)" % (situation, ", ".join(SITUATIONS))}
    source = (args.source or "").strip() or None
    if source and not (source in SOURCES or source.startswith("subagent:")):
        source = common.slug(source, 40)
    project = common.slug(args.project, 60) if args.project else None
    if project == "sem-nome":
        project = None
    supersedes = (args.supersedes or "").strip() or None

    # ---- coleção / id / caminho
    collection = COLLECTION_BY_TYPE.get(typ, "memorias")
    ids = existing_ids()
    updating = False
    old_meta, old_body, old_text = {}, "", None
    if collection in DATED_COLLECTIONS:
        base = "%s-%s" % (common.today(), common.slug(args.id_ or title, 49))
        doc_id = base
        n = 2
        while doc_id in ids:
            doc_id = "%s-%d" % (base, n)
            n += 1
        path = os.path.join(common.P[collection], doc_id + ".md")
    elif collection == "conhecimento":
        topic = common.slug(args.topic, 40) if args.topic else "geral"
        doc_id = common.slug(args.id_ or title, 60)
        path = os.path.join(common.P["conhecimento"], topic, doc_id + ".md")
        existing = find_doc(doc_id)
        if existing and args.id_:
            updating, path = True, existing
        elif existing:
            n = 2
            base = doc_id
            while doc_id in ids:
                doc_id = "%s-%d" % (base, n)
                n += 1
            path = os.path.join(common.P["conhecimento"], topic, doc_id + ".md")
    else:  # projetos / perfil: um arquivo por slug, atualizado
        doc_id = common.slug(args.id_ or title, 60)
        existing = find_doc(doc_id)
        if existing:
            updating, path = True, existing
        else:
            path = os.path.join(common.P[collection], doc_id + ".md")
    if updating:
        old_meta, old_body, old_text = load_doc(path)
        if old_text is None:
            return {"ok": False, "error": "não consegui ler %s" % common.rel(path)}
        old_meta = old_meta or {}

    # ---- índice (para tags raras e quase-duplicatas)
    index = common.load_json(common.P["index_json"], None, script=SCRIPT)
    if not isinstance(index, dict):
        index = None

    # ---- listas
    tags_in = split_list(args.tags)
    links = split_list(args.links)
    for l in extract_wikilinks(text):
        if l not in links:
            links.append(l)
    files_in = []
    for f in split_list(args.files):
        r = common.rel(f) if os.path.isabs(f) else f
        files_in.append(r or f)
    sources_in = [s.replace("@", "%40") for s in split_list(args.sources, "|")]
    next_items = split_list(args.next_, ";")
    done_items = split_list(args.done, ";")

    # ---- corpo
    if typ == "project":
        body = build_project_body(old_body if updating else "", text, next_items, done_items, args.next_replace,
                                  args.summary, title, creating=not updating)
    elif updating:
        body = text if text else (old_body or "")
    else:
        body = text
    if not body.strip() and typ != "project":
        return {"ok": False, "error": "faltou --text (ou texto pelo stdin)"}
    body = body.rstrip("\n") + "\n"

    # ---- frontmatter
    meta = dict(old_meta) if updating else {}
    meta["id"] = doc_id
    meta["type"] = typ
    meta["title"] = title
    if args.summary is not None or typ in ("profile", "project"):
        s = args.summary if args.summary is not None else (old_meta.get("summary") if updating else None)
        if s is None:
            s = first_sentence(text or title, 160)
        meta["summary"] = common.escape_at(common.redact(common.truncate(re.sub(r"\s+", " ", str(s)).strip(), 160)))
    tag_set = list(tags_in) + [typ]
    if project:
        tag_set.append(project)
    if updating:
        tag_set += [str(t) for t in (old_meta.get("tags") or []) if t]
    tag_set += rarest_terms(index, "%s %s" % (title, text))
    meta["tags"] = norm_tags(tag_set)
    if args.confidence is not None:
        meta["confidence"] = clamp_confidence(args.confidence)
    elif not updating or "confidence" not in meta:
        meta["confidence"] = 0.7
    else:
        meta["confidence"] = clamp_confidence(meta.get("confidence"))
    meta["status"] = meta.get("status") or "active"
    if source:
        meta["source"] = source
    elif not updating:
        meta["source"] = "conversation"
    meta["session"] = sid
    if project:
        meta["project"] = project
    if typ == "project":
        if situation:
            meta["situation"] = situation
        elif not meta.get("situation"):
            meta["situation"] = "in-progress"
        old_files = [str(f) for f in (old_meta.get("files") or [])] if updating else []
        files = list(old_files)
        for f in files_in:
            if f not in files:
                files.append(f)
        meta["files"] = files
    elif files_in:
        meta["files"] = files_in
    if links:
        merged = [str(l) for l in (old_meta.get("links") or [])] if updating else []
        for l in links:
            if l not in merged:
                merged.append(l)
        meta["links"] = merged
    if supersedes:
        meta["supersedes"] = supersedes
    if typ == "knowledge":
        if sources_in or "sources" not in meta:
            merged = [str(s) for s in (old_meta.get("sources") or [])] if updating else []
            for s in sources_in:
                if s not in merged:
                    merged.append(s)
            meta["sources"] = merged
        meta["topic"] = common.slug(args.topic, 40) if args.topic else (meta.get("topic") or os.path.basename(os.path.dirname(path)))
    if args.pinned:
        meta["pinned"] = True
    elif "pinned" not in meta:
        meta["pinned"] = False
    now = common.now_iso()
    new_hash = common.body_hash(body)
    if updating:
        meta["created"] = old_meta.get("created") or now
        try:
            old_version = int(old_meta.get("version") or 0)
        except Exception:
            old_version = 0
        old_hash = old_meta.get("hash") or common.body_hash(old_body or "")
        meta["version"] = old_version + 1
        meta["updated"] = now
    else:
        meta["created"] = now
        meta["updated"] = now
        meta["version"] = 1
    meta["hash"] = new_hash
    for k in ("summary", "links", "files", "sources"):
        if k in meta and meta[k] in (None, "", []) and not (typ == "project" and k == "files") and not (typ == "knowledge" and k == "sources") and not (typ in ("profile", "project") and k == "summary"):
            meta.pop(k, None)

    new_text = common.write_frontmatter(meta, body)

    # ---- gravação (com cópia de segurança antes de atualizar)
    if updating:
        snapshot_before_update(doc_id, old_text, old_version)
    common.write_atomic(path, new_text)
    set_seen(doc_id, new_text)   # a versão anterior já está em .history; só avança a "última vista"

    # ---- quase-duplicatas (só ao criar)
    similar = []
    if not updating and index:
        try:
            similar = similar_ids(index, title, body, exclude={doc_id})
        except Exception as e:
            common.log_error(SCRIPT, e, extra={"message": "similar_to"})

    # ---- evento + turn cache + refino
    log_memory_event(sid, doc_id, path, "%s %s %s: %s" % ("update" if updating else "new", common.label_type(typ), doc_id, title),
                     extra={"type": typ, "updated": updating})
    mark_memory_in_turn(sid, doc_id)
    if not args.no_refine:
        run_refine("remember", timeout=3.0)

    return {"ok": True, "id": doc_id, "path": common.rel(path), "updated": updating, "similar_to": similar,
            "type": typ, "session": sid, "ms": int((time.monotonic() - t0) * 1000)}


def main():
    as_json = "--json" in sys.argv[1:]
    try:
        args = build_parser().parse_args()
        as_json = args.as_json
        result = remember(args)
        emit(result, as_json)
    except SystemExit:
        # argparse (ex.: --help ou flag desconhecida): nunca sai com código != 0
        pass
    except BaseException as e:
        common.log_error(SCRIPT, e)
        emit({"ok": False, "error": "%s: %s" % (type(e).__name__, common.truncate(str(e), 200))}, as_json)
    sys.exit(0)


if __name__ == "__main__":
    main()
