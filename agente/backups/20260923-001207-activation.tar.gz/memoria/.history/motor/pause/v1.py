#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
pause.py --toggle | --on | --off [--reason "motivo"]  (spec §11.15)

Cria ou remove ROOT/PAUSA (conteúdo: data e motivo). Com PAUSA presente, hooks e
status line não fazem nada; scripts chamados à mão continuam funcionando.
Imprime o estado novo em português. Sempre exit 0.
"""
import os, sys, io

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common


def _set_on(reason):
    content = "pausado em %s\nmotivo: %s\n" % (common.now_iso(), reason or "pausa pedida pelo Marcelo (/pausar)")
    common.write_atomic(common.P["pausa"], content)
    return "⏸ Gabriel em pausa desde agora. Hooks e linha de status ficam quietos. Para voltar: /pausar de novo ou apague o arquivo PAUSA."


def _set_off():
    try:
        os.unlink(common.P["pausa"])
    except FileNotFoundError:
        pass
    return "▶ Gabriel de volta ao trabalho. Hooks e linha de status ativos de novo."


def main(argv):
    args = list(argv)
    reason = None
    if "--reason" in args:
        i = args.index("--reason")
        if i + 1 < len(args):
            reason = args[i + 1]
            del args[i:i + 2]
        else:
            del args[i]
    mode = "--toggle"
    for a in args:
        if a in ("--toggle", "--on", "--off"):
            mode = a
    paused = common.paused()
    if mode == "--on" or (mode == "--toggle" and not paused):
        if paused:
            msg = "⏸ Gabriel já estava em pausa (arquivo PAUSA presente)."
        else:
            msg = _set_on(reason)
    else:
        if not paused:
            msg = "▶ Gabriel não estava em pausa (nenhum arquivo PAUSA)."
        else:
            msg = _set_off()
    print(msg)


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BaseException as e:
        common.log_error("pause.py", e)
    sys.exit(0)
