#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
selftest.py — suíte de testes do organismo Gabriel (spec §16.1 e §11.16).

Roda TUDO numa caixa isolada em memoria/.cache/test/root/ (BABEL_ROOT exportado para todo
subprocesso): motor/ e .claude/hooks/hook.py por symlink, memoria/ copiada (sem log/, .cache/,
.history/), config.json de teste com learning_gate: true, dashboard/ copiado, backups/ vazio.
Nada do substrato vivo é lido para escrita nem apagado. A única escrita fora da caixa é a cópia
dos scripts aprovados para memoria/.history/motor/<script>/v<N>.py quando 100 % passa.

Uso: /usr/bin/python3 motor/selftest.py [--quick] [--json] [--hook <caminho do hook.py>]
Exit 0 sempre: o resultado está no texto (PASSOU/FALHOU por item, 'N/M passaram') e no --json.
"""
import os, sys, io, re, json, time, shutil, hashlib, subprocess, ast, glob, threading, datetime, argparse

PY = "/usr/bin/python3"
HERE = os.path.dirname(os.path.abspath(__file__))
LIVE_ROOT = os.path.abspath(os.environ.get("BABEL_ROOT") or os.path.dirname(HERE))
BOX = os.path.join(LIVE_ROOT, "memoria", ".cache", "test", "root")
# Tudo que este processo faz in-process via common aponta para a caixa (antes de importar common).
os.environ["BABEL_ROOT"] = BOX
sys.path.insert(0, HERE)
import common

P = common.P
DEFAULT_HOOK = os.path.join(LIVE_ROOT, ".claude", "hooks", "hook.py")
FALLBACK_HOOK = ("/private/tmp/claude-501/-Users-marcelomaximos-Desktop-babel-os/"
                 "7f804fee-3994-40ac-9bc4-d07573504669/scratchpad/build/claude/hooks/hook.py")
HOOK = DEFAULT_HOOK

SID = "teste-0000-4000-8000-000000000001"
SID8 = common.sid8(SID)

TESTED_EVENTS = ["Setup", "SessionStart", "UserPromptSubmit", "UserPromptExpansion", "PreToolUse",
                 "PostToolUse", "PostToolUseFailure", "SubagentStart", "SubagentStop", "Stop",
                 "StopFailure", "PreCompact", "PostCompact", "SessionEnd", "ConfigChange",
                 "InstructionsLoaded"]
TIMEOUTS = {"Setup": 30, "SessionStart": 15, "UserPromptSubmit": 8, "UserPromptExpansion": 5,
            "PreToolUse": 5, "PostToolUse": 5, "PostToolUseFailure": 5, "SubagentStart": 5,
            "SubagentStop": 5, "Stop": 8, "StopFailure": 5, "PreCompact": 20, "PostCompact": 10,
            "SessionEnd": 10, "ConfigChange": 5, "InstructionsLoaded": 5}
LOGS = ["events", "errors", "prompts", "turns", "sessions", "refinements", "mutations", "recalls",
        "compactions", "agenda", "heartbeats"]

ENV = dict(os.environ)
ENV["BABEL_ROOT"] = BOX
ENV["CLAUDE_PROJECT_DIR"] = BOX
ENV["PYTHONIOENCODING"] = "utf-8"
ENV.setdefault("COLUMNS", "120")
for _k in ("CLAUDE_CODE_SESSION_ID", "CLAUDE_SESSION_ID"):
    ENV.pop(_k, None)

SUITE = None
SEED = {}  # ids das memórias semeadas


# --------------------------------------------------------------------------- infra da suíte
class Fail(Exception):
    pass


def check(cond, msg):
    if not cond:
        raise Fail(msg)


class Suite(object):
    def __init__(self, quick, as_json):
        self.quick = quick
        self.as_json = as_json
        self.items = []
        self.stop_outputs = []

    def add(self, name, ok, reason="", ms=0):
        reason = common.truncate(str(reason or ""), 220).replace("\n", " ")
        self.items.append({"item": name, "ok": bool(ok), "reason": "" if ok else reason, "ms": int(ms)})
        if not self.as_json:
            print(("PASSOU %s" % name) if ok else ("FALHOU %s: %s" % (name, reason)))
            sys.stdout.flush()
        return bool(ok)

    def case(self, name, fn, *a, **kw):
        t0 = time.monotonic()
        try:
            r = fn(*a, **kw)
            ok, reason = True, ""
            if isinstance(r, str) and r:
                ok, reason = False, r
        except Fail as e:
            ok, reason = False, str(e)
        except subprocess.TimeoutExpired as e:
            ok, reason = False, "timeout de %s s no subprocesso" % e.timeout
        except KeyboardInterrupt:
            raise
        except BaseException as e:
            ok, reason = False, "%s: %s" % (type(e).__name__, common.truncate(str(e), 160))
        return self.add(name, ok, reason, (time.monotonic() - t0) * 1000)

    def passed(self):
        return sum(1 for i in self.items if i["ok"])


# --------------------------------------------------------------------------- utilidades locais (sem log vivo)
def read_text(path):
    return common.read_text(path)


def write_text(path, text):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with io.open(path, "w", encoding="utf-8") as f:
        f.write(text)


def read_json(path, default=None):
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def write_json(path, obj):
    write_text(path, json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def fsize(path):
    try:
        return os.path.getsize(path)
    except Exception:
        return 0


def count_lines(path):
    return common.count_jsonl(path)


def sha256_file(path):
    h = hashlib.sha256()
    with io.open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def fm(text):
    if text is None:
        return None, ""
    return common.read_frontmatter(text)


def state():
    return read_json(P["state"], {}) or {}


def vt(v):
    try:
        parts = [int(x) for x in str(v or "0.0.0").split(".")[:3]]
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts)
    except Exception:
        return (0, 0, 0)


def turn_path(sid):
    return os.path.join(P["cache"], "turn-%s.json" % common.sid8(sid))


def turn(sid):
    t = read_json(turn_path(sid), None)
    return t if isinstance(t, dict) else {}


def edit_turn(sid, fn):
    t = turn(sid)
    if not t:
        t = {"session": common.sid8(sid), "start": common.now_iso(), "prompts": 0, "current_prompt": None,
             "permission_mode": "auto", "files_by_prompt": {}, "memories_by_prompt": {}, "stop_blocks": {},
             "pending_reminder": False, "compact_delta": None, "subagents": {}}
    fn(t)
    write_json(turn_path(sid), t)
    return t


def iso_days_ago(n, hour=10):
    d = common.now() - datetime.timedelta(days=n)
    d = d.replace(hour=hour, minute=0, second=0, microsecond=0)
    return d.isoformat(timespec="seconds"), d.strftime("%Y-%m-%d")


def doc_path(collection, doc_id, sub=None):
    base = P[collection]
    if sub:
        base = os.path.join(base, sub)
    return os.path.join(base, doc_id + ".md")


def write_doc(collection, doc_id, meta, body, sub=None, raw=None):
    path = doc_path(collection, doc_id, sub)
    m = {"id": doc_id, "status": "active", "confidence": 0.9, "pinned": False, "version": 1}
    m.update(meta)
    m["hash"] = common.body_hash(body)
    write_text(path, raw if raw is not None else common.write_frontmatter(m, body))
    return path


def touch_md():
    """Muda a assinatura do substrato sem mudar hash de corpo (força o refino rápido a trabalhar)."""
    p = doc_path("memorias", SEED["lp"])
    t = read_text(p) or ""
    write_text(p, t + "\n")


def log_sizes():
    out = {}
    for dp, dn, fn in os.walk(P["log"]):
        for f in fn:
            fp = os.path.join(dp, f)
            out[os.path.relpath(fp, P["log"])] = fsize(fp)
    return out


def ints_in(obj):
    if isinstance(obj, bool):
        return []
    if isinstance(obj, int):
        return [obj]
    if isinstance(obj, dict):
        return sum((ints_in(v) for v in obj.values()), [])
    if isinstance(obj, list):
        return sum((ints_in(v) for v in obj), [])
    return []


def bump_ints(obj, value):
    if isinstance(obj, bool):
        return obj
    if isinstance(obj, int):
        return value
    if isinstance(obj, dict):
        return dict((k, bump_ints(v, value)) for k, v in obj.items())
    if isinstance(obj, list):
        return [bump_ints(v, value) for v in obj]
    return obj


def strip_generated(text):
    keep = []
    for l in (text or "").split("\n"):
        low = l.lower()
        if "generated:" in low or "gerado por" in low or "gerado em" in low:
            continue
        keep.append(l)
    return "\n".join(keep)


# --------------------------------------------------------------------------- subprocessos
def run(cmd, stdin=None, timeout=30.0, cwd=None):
    data = stdin.encode("utf-8") if isinstance(stdin, str) else stdin
    t0 = time.monotonic()
    p = subprocess.run(cmd, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout,
                       env=ENV, cwd=cwd or BOX)
    ms = (time.monotonic() - t0) * 1000
    return p.returncode, p.stdout.decode("utf-8", "replace"), p.stderr.decode("utf-8", "replace"), ms


def motor(script, args=None, stdin=None, timeout=30.0):
    path = os.path.join(HERE, script)
    check(os.path.isfile(path), "%s ausente em motor/" % script)
    return run([PY, path] + list(args or []), stdin=stdin, timeout=timeout)


class Snap(object):
    def __init__(self):
        self.off = dict((k, fsize(P[k])) for k in LOGS)

    def new_raw(self, k):
        path = P[k]
        if not os.path.exists(path):
            return []
        size = fsize(path)
        with io.open(path, "rb") as f:
            if size >= self.off[k]:
                f.seek(self.off[k])
            data = f.read()
        return [l for l in data.decode("utf-8", "replace").split("\n") if l.strip()]

    def new(self, k):
        out = []
        for l in self.new_raw(k):
            try:
                out.append(json.loads(l))
            except Exception:
                out.append({"_invalid": l[:80]})
        return out


class R(object):
    def __init__(self, rc, out, err, ms, snap, ev):
        self.rc, self.out, self.err, self.ms, self.snap, self.ev = rc, out, err, ms, snap, ev

    def new(self, k):
        return self.snap.new(k)

    def new_raw(self, k):
        return self.snap.new_raw(k)


def payload(ev, sid=SID, prompt_id="p_1", **extra):
    d = {"session_id": sid, "prompt_id": prompt_id,
         "transcript_path": os.path.join(BOX, ".transcript", sid + ".jsonl"), "cwd": BOX,
         "permission_mode": "auto", "effort": {"level": "xhigh"}, "hook_event_name": ev}
    d.update(extra)
    return d


def run_hook(pl=None, raw=None, args=None, timeout=None, ev=None):
    check(os.path.isfile(HOOK), "hook.py ausente (%s)" % HOOK)
    if pl is not None and ev is None:
        ev = pl.get("hook_event_name")
    if timeout is None:
        timeout = TIMEOUTS.get(ev, 5) + 10
    stdin = raw if raw is not None else json.dumps(pl, ensure_ascii=False)
    snap = Snap()
    rc, out, err, ms = run([PY, HOOK] + list(args or []), stdin=stdin, timeout=timeout)
    return R(rc, out, err, ms, snap, ev)


def parse_stdout(out):
    s = (out or "").strip()
    if not s:
        return None
    check(len(s) <= 10000, "stdout com %d chars (> 10.000)" % len(s))
    try:
        obj = json.loads(s)
    except Exception:
        raise Fail("stdout não é UM JSON: %r" % s[:80])
    check(isinstance(obj, dict), "stdout JSON não é um objeto")
    return obj


def check_common(r, ev, events="1+", timing=True):
    check(r.rc == 0, "exit %s" % r.rc)
    err = (r.err or "").strip()
    check("Traceback" not in err, "Traceback no stderr: %s" % common.truncate(err.splitlines()[-1] if err else "", 120))
    if timing and ev in TIMEOUTS:
        lim = TIMEOUTS[ev] * 0.8
        check(r.ms < lim * 1000, "demorou %.0f ms (limite 80%% de %s s)" % (r.ms, TIMEOUTS[ev]))
    obj = parse_stdout(r.out)
    if obj is not None:
        hso = obj.get("hookSpecificOutput")
        if hso is not None:
            check(isinstance(hso, dict) and hso.get("hookEventName") == ev, "hookEventName != %s" % ev)
        if ev == "Stop":
            check("additionalContext" not in r.out, "Stop emitiu additionalContext")
    if ev == "Stop" and SUITE is not None:
        SUITE.stop_outputs.append(r.out or "")
    if events:
        new = r.new("events")
        mine = [l for l in new if l.get("event") == ev]
        check(not [l for l in new if "_invalid" in l], "linha inválida em events.jsonl")
        for raw in r.new_raw("events"):
            check(len(raw) <= 1000, "linha de events.jsonl com %d chars (> 1.000)" % len(raw))
        if events == "exact1":
            check(len(new) == 1 and len(mine) == 1,
                  "events.jsonl ganhou %d linha(s); esperava exatamente 1 de %s" % (len(new), ev))
        else:
            check(len(mine) >= 1, "nenhuma linha nova com event=%s em events.jsonl" % ev)
    return obj


def check_session_json(obj, require=True):
    if obj is None:
        check(not require, "SessionStart não devolveu JSON")
        return ""
    hso = obj.get("hookSpecificOutput") or {}
    ctx = hso.get("additionalContext")
    check(isinstance(ctx, str) and ctx.strip() != "", "additionalContext vazio")
    check(len(ctx) <= 3000, "additionalContext com %d chars (> 3.000)" % len(ctx))
    check("sessionTitle" not in hso and "sessionTitle" not in obj, "sessionTitle presente")
    return ctx


def expect_deny(r):
    obj = check_common(r, "PreToolUse")
    check(obj is not None, "esperava deny, stdout vazio")
    hso = obj.get("hookSpecificOutput") or {}
    check(hso.get("permissionDecision") == "deny", "permissionDecision != deny")
    check(str(hso.get("permissionDecisionReason") or "").strip() != "", "sem permissionDecisionReason")
    check(any(l.get("denied") for l in r.new("events")), "evento sem denied: true")
    return obj


def expect_silent(r, ev):
    obj = check_common(r, ev)
    check(obj is None, "esperava stdout vazio, veio: %s" % common.truncate(r.out.strip(), 80))


def pre(tool, tool_input, **extra):
    return run_hook(payload("PreToolUse", tool_name=tool, tool_input=tool_input, tool_use_id="toolu_pre", **extra))


def post(tool, tool_input, tool_response=None, prompt_id="p_post", **extra):
    if tool_response is None:
        tool_response = {"stdout": "", "stderr": "", "interrupted": False, "isImage": False}
    return run_hook(payload("PostToolUse", prompt_id=prompt_id, tool_name=tool, tool_input=tool_input,
                            tool_response=tool_response, tool_use_id="toolu_post", **extra))


def files_for(pid, sid=SID):
    return list((turn(sid).get("files_by_prompt") or {}).get(pid) or [])


HOLDER_SRC = r'''
import fcntl, sys, time
f = open(sys.argv[1], "a")
fcntl.flock(f.fileno(), fcntl.LOCK_EX)
sys.stdout.write("locked\n"); sys.stdout.flush()
time.sleep(float(sys.argv[2]))
'''


def hold_lock(name, secs):
    os.makedirs(P["cache"], exist_ok=True)
    p = subprocess.Popen([PY, "-c", HOLDER_SRC, os.path.join(P["cache"], name + ".lock"), str(secs)],
                         stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=ENV)
    p.stdout.readline()
    return p


def release(p):
    try:
        p.kill()
        p.wait(timeout=5)
    except Exception:
        pass


def swap_motor_with_mock(name, src):
    link = os.path.join(BOX, "motor")
    if os.path.islink(link):
        os.unlink(link)
    else:
        shutil.rmtree(link)
    os.makedirs(link)
    for f in os.listdir(HERE):
        if f.startswith(".") or f == "__pycache__":
            continue
        if f == name:
            write_text(os.path.join(link, f), src)
        else:
            os.symlink(os.path.join(HERE, f), os.path.join(link, f))


def restore_motor():
    link = os.path.join(BOX, "motor")
    if os.path.islink(link):
        os.unlink(link)
    elif os.path.isdir(link):
        shutil.rmtree(link)
    os.symlink(HERE, link)


# --------------------------------------------------------------------------- 1. sintaxe
def scan_syntax_gt39(path):
    src = read_text(path) or ""
    problems = []
    try:
        tree = ast.parse(src, filename=path)
    except SyntaxError as e:
        hint = ""
        for line in src.split("\n"):
            if re.match(r"^\s*match\s+[^=(]+:\s*(#.*)?$", line):
                hint = " (match statement é py3.10)"
                break
        return ["SyntaxError linha %s%s" % (e.lineno, hint)]

    def ann_has_bitor(ann):
        if ann is None:
            return False
        for n in ast.walk(ann):
            if isinstance(n, ast.BinOp) and isinstance(n.op, ast.BitOr):
                return True
        return False

    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.module == "__future__":
                problems.append("from __future__ (linha %d)" % node.lineno)
            if (node.module or "").split(".")[0] == "zoneinfo":
                problems.append("zoneinfo (linha %d)" % node.lineno)
        elif isinstance(node, ast.Import):
            for a in node.names:
                if a.name.split(".")[0] == "zoneinfo":
                    problems.append("zoneinfo (linha %d)" % node.lineno)
        elif isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name) \
                and node.value.id in ("list", "dict", "set", "tuple", "frozenset", "type"):
            problems.append("%s[...] fora de string (linha %d)" % (node.value.id, node.lineno))
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            args = node.args
            alls = list(args.args) + list(args.kwonlyargs) + list(getattr(args, "posonlyargs", []))
            if args.vararg:
                alls.append(args.vararg)
            if args.kwarg:
                alls.append(args.kwarg)
            if ann_has_bitor(node.returns) or any(ann_has_bitor(a.annotation) for a in alls):
                problems.append("X | Y em anotação (linha %d)" % node.lineno)
        elif isinstance(node, ast.AnnAssign) and ann_has_bitor(node.annotation):
            problems.append("X | Y em anotação (linha %d)" % node.lineno)
    return problems


def t_compile(path):
    check(os.path.isfile(path), "arquivo ausente")
    cdir = os.path.join(BOX, ".pyc")
    os.makedirs(cdir, exist_ok=True)
    cfile = os.path.join(cdir, os.path.basename(path) + "c")
    rc, out, err, ms = run([PY, "-c", "import py_compile,sys; py_compile.compile(sys.argv[1], cfile=sys.argv[2], doraise=True)",
                            path, cfile], timeout=60, cwd=BOX)
    if rc != 0:
        last = [l for l in (err + out).strip().splitlines() if l.strip()]
        raise Fail("py_compile: %s" % (last[-1] if last else "erro"))
    problems = scan_syntax_gt39(path)
    check(not problems, "sintaxe > 3.9: " + "; ".join(problems[:3]))


# --------------------------------------------------------------------------- 2. caixa e sementes
def seed_docs():
    iso2, d2 = iso_days_ago(2)
    SEED["lp"] = d2 + "-lp-do-evento-de-outubro-do-reino"
    write_doc("memorias", SEED["lp"], {"type": "fact", "title": "LP do evento de outubro do Reino",
                                        "tags": ["lp", "evento", "reino", "outubro"], "source": "marcelo-said",
                                        "project": "reino-lp", "created": iso2, "updated": iso2},
              "O Marcelo quer uma LP para o evento de outubro do Reino (abertura do carrinho em 23/10). "
              "Página única, identidade Babel OS, pré-cadastro de líderes.")
    iso12, d12 = iso_days_ago(12)
    iso11, d11 = iso_days_ago(11)
    SEED["dup_a"] = d12 + "-dup-a-arquivo-unico"
    SEED["dup_b"] = d11 + "-dup-b-arquivo-unico"
    dup_body = "Marcelo prefere sites em arquivo único, sem build, para abrir no navegador."
    write_doc("memorias", SEED["dup_a"], {"type": "preference", "title": "Dup A: arquivo único",
                                           "tags": ["sites"], "created": iso12, "updated": iso12}, dup_body)
    write_doc("memorias", SEED["dup_b"], {"type": "preference", "title": "Dup B: arquivo único",
                                           "tags": ["sites"], "created": iso11, "updated": iso11}, dup_body)
    iso10, d10 = iso_days_ago(10)
    iso9, d9 = iso_days_ago(9)
    SEED["old"] = d10 + "-lp-em-tres-arquivos"
    SEED["new"] = d9 + "-lp-em-um-arquivo"
    write_doc("memorias", SEED["old"], {"type": "fact", "title": "A LP fica em três arquivos",
                                         "tags": ["lp"], "created": iso10, "updated": iso10},
              "A LP do Reino fica dividida em três arquivos separados.")
    write_doc("memorias", SEED["new"], {"type": "fact", "title": "A LP fica em um arquivo só",
                                         "tags": ["lp"], "supersedes": SEED["old"], "created": iso9, "updated": iso9},
              "A LP do Reino fica num arquivo único, corrigindo a memória anterior.")
    iso8, d8 = iso_days_ago(8)
    SEED["at"] = d8 + "-contato-do-diego"
    write_doc("memorias", SEED["at"], {"type": "reference", "title": "Contato do Diego diego@reino.com.br e @browser",
                                        "tags": ["diego", "contato"], "created": iso8, "updated": iso8},
              "Falar com diego@reino.com.br sobre o patrocínio; nunca usar @/etc/hosts nem @~/x no texto.")
    iso7, d7 = iso_days_ago(7)
    SEED["broken"] = d7 + "-frontmatter-quebrado"
    write_doc("memorias", SEED["broken"], {}, "", raw="---\nid: %s\ntype: fact\ntitle: Quebrada\ntags: [teste\ncorpo sem fechar o frontmatter\n" % SEED["broken"])
    iso6, d6 = iso_days_ago(6)
    SEED["script"] = d6 + "-titulo-com-script"
    write_doc("memorias", SEED["script"], {"type": "idea", "title": "Teste </script> no título do painel",
                                            "tags": ["painel"], "created": iso6, "updated": iso6},
              "Corpo simples para provar o escape de </script> no data.js.")
    iso5, d5 = iso_days_ago(5)
    SEED["decision"] = d5 + "-usar-identidade-babel-os"
    write_doc("decisoes", SEED["decision"], {"type": "decision", "title": "Toda entrega usa a identidade Babel OS",
                                              "tags": ["decisao", "babel-os"], "created": iso5, "updated": iso5},
              "**Contexto:** entregas visuais. **Alternativas:** cada uma com cara própria. "
              "**Escolha:** identidade Babel OS por padrão. **Consequências:** consistência.")
    iso3, d3 = iso_days_ago(3)
    write_doc("projetos", "reino-lp", {"type": "project", "title": "LP do Reino", "summary": "LP do evento de outubro",
                                       "tags": ["reino", "lp"], "situation": "in-progress",
                                       "files": ["entregas/sites/teste-lp.html"], "created": iso3, "updated": iso3},
              "## Situação\nEm construção.\n\n## Próximos passos\n- [ ] validar textos com o Marcelo\n\n## Histórico\n- %s — criado\n" % common.fmt_ddmm(iso3, True))
    write_text(os.path.join(P["entregas_sites"], "teste-lp.html"), "<!doctype html><html><body>LP de teste</body></html>\n")


def build_box():
    if os.path.lexists(BOX):
        if os.path.islink(BOX):
            os.unlink(BOX)
        else:
            shutil.rmtree(BOX)
    os.makedirs(BOX)
    os.symlink(HERE, os.path.join(BOX, "motor"))
    os.makedirs(os.path.join(BOX, ".claude", "hooks"))
    if os.path.isfile(HOOK):
        os.symlink(HOOK, os.path.join(BOX, ".claude", "hooks", "hook.py"))
    live_claude = os.path.join(LIVE_ROOT, ".claude")
    for sub in ("skills", "agents", "rules", "workflows"):
        src = os.path.join(live_claude, sub)
        if os.path.isdir(src):
            shutil.copytree(src, os.path.join(BOX, ".claude", sub), symlinks=True)
    src = os.path.join(live_claude, "settings.json")
    if os.path.isfile(src):
        shutil.copyfile(src, os.path.join(BOX, ".claude", "settings.json"))
    for f in ("CLAUDE.md", "LEIA-ME.md"):
        src = os.path.join(LIVE_ROOT, f)
        if os.path.isfile(src):
            shutil.copyfile(src, os.path.join(BOX, f))
    src_m = os.path.join(LIVE_ROOT, "memoria")

    def ignore(d, names):
        top = os.path.abspath(d) == os.path.abspath(src_m)
        out = set()
        for n in names:
            if ".tmp." in n or n.endswith(".lock") or ".corrupt-" in n:
                out.add(n)
            elif top and (n in ("log", ".cache", ".history", ".lixeira") or n.startswith(".restoring-")):
                out.add(n)
        return out

    if os.path.isdir(src_m):
        shutil.copytree(src_m, P["memoria"], ignore=ignore)
    cfg = dict(common.CONFIG_DEFAULTS)
    live_cfg = read_json(os.path.join(src_m, "config.json"), None)
    if isinstance(live_cfg, dict):
        for k, v in live_cfg.items():
            if k in cfg and type(v) == type(cfg[k]):
                cfg[k] = v
    cfg["learning_gate"] = True
    write_json(P["config"], cfg)
    src_d = os.path.join(LIVE_ROOT, "dashboard")
    if os.path.isdir(src_d):
        shutil.copytree(src_d, P["dashboard"])
    for k in ("backups", "entregas_sites", "entregas_sistemas", "planos", "log", "cache_texts", "history", "lixeira"):
        os.makedirs(P[k], exist_ok=True)
    seed_docs()
    check(os.path.isfile(P["config"]) and read_json(P["config"], {}).get("learning_gate") is True, "config de teste não gravado")


def t_prepare_box():
    if os.path.isfile(os.path.join(HERE, "verify.py")):
        rc, out, err, ms = motor("verify.py", ["--repair", "--quiet"], timeout=60)
        check(rc == 0, "verify --repair saiu %s" % rc)
    rc, out, err, ms = motor("refine.py", ["--full", "--trigger", "selftest"], timeout=90)
    check(rc == 0, "refine --full saiu %s" % rc)
    check("Traceback" not in err, "traceback no refine --full")
    check(os.path.isfile(P["state"]) and isinstance(read_json(P["state"]), dict), "state.json não existe/ilegível")
    check(os.path.isfile(P["index_json"]), "index.json não gerado")
    check(os.path.isfile(P["indice"]), "INDICE.md não gerado")


# --------------------------------------------------------------------------- 3. Setup
def flag_path(sid):
    return os.path.join(P["cache"], "setup-%s.flag" % common.sid8(sid))


def t_setup_init_install():
    if os.path.exists(P["state"]):
        os.unlink(P["state"])
    if os.path.exists(flag_path(SID)):
        os.unlink(flag_path(SID))
    r = run_hook(payload("Setup", trigger="init"))
    expect_silent(r, "Setup")
    check(os.path.exists(flag_path(SID)), ".cache/setup-<sid8>.flag ausente")
    check(isinstance(read_json(P["state"]), dict), "state.json não criado (verify --install não rodou)")


def t_setup_init_repair():
    r = run_hook(payload("Setup", trigger="init"))
    expect_silent(r, "Setup")
    check(os.path.exists(flag_path(SID)), "flag ausente")
    check(isinstance(read_json(P["state"]), dict), "state.json ilegível após --repair")
    check(os.path.isfile(P["indice"]), "INDICE.md ausente após --repair")


def t_setup_maintenance():
    r = run_hook(payload("Setup", trigger="maintenance"))
    expect_silent(r, "Setup")
    check(os.path.exists(flag_path(SID)), "flag ausente")


# --------------------------------------------------------------------------- 4. SessionStart
def seed_session_memory(s8, n_days=1):
    iso, d = iso_days_ago(n_days)
    doc_id = "%s-memoria-da-sessao-%s" % (d, s8)
    write_doc("memorias", doc_id, {"type": "fact", "title": "Memória da sessão %s" % s8, "tags": ["teste", "sessao"],
                                    "source": "conversation", "session": s8, "created": iso, "updated": iso},
              "Fato registrado na sessão %s para o teste do bump de minor." % s8)
    return doc_id


def quick_refine():
    rc, out, err, ms = motor("refine.py", ["--quick", "--trigger", "selftest", "--quiet"], timeout=20)
    check(rc == 0, "refine --quick saiu %s" % rc)


def t_ss_bump_two_startups():
    seed_session_memory("e1e1e1e1")
    seed_session_memory("f2f2f2f2")
    quick_refine()
    v0 = vt(state().get("version"))
    m0 = count_lines(P["mutations"])
    r1 = run_hook(payload("SessionStart", sid="g3g3g3g3-0000-4000-8000-000000000001", source="startup", model="claude-fable-5-1"))
    check_session_json(check_common(r1, "SessionStart"))
    r2 = run_hook(payload("SessionStart", sid="h4h4h4h4-0000-4000-8000-000000000001", source="startup", model="claude-fable-5-1"))
    check_session_json(check_common(r2, "SessionStart"))
    st = state()
    v1 = vt(st.get("version"))
    check(v1[0] == v0[0] and v1[1] == v0[1] + 1 and v1[2] == 0,
          "minor não subiu exatamente 1: %s → %s" % (".".join(map(str, v0)), ".".join(map(str, v1))))
    sc = st.get("sessions_counted") or []
    check("e1e1e1e1" in sc and "f2f2f2f2" in sc, "sessions_counted sem as duas sessões: %s" % sc)
    m1 = count_lines(P["mutations"])
    check(m1 == m0 + 1, "mutations.jsonl ganhou %d linha(s), esperava 1" % (m1 - m0))
    cs = st.get("counts_at_session_start") or {}
    check(cs.get("session") == "h4h4h4h4", "counts_at_session_start não aponta a última sessão (%s)" % cs.get("session"))


def t_ss_resume_preserves():
    sid = "resume01-0000-4000-8000-000000000001"
    tc = {"session": "resume01", "start": common.now_iso(), "prompts": 3, "current_prompt": "p_9",
          "permission_mode": "auto", "files_by_prompt": {"p_9": ["entregas/sites/x.html"]},
          "memories_by_prompt": {"p_9": []}, "stop_blocks": {"p_9": 1}, "pending_reminder": True,
          "compact_delta": None, "subagents": {}}
    write_json(turn_path(sid), tc)
    r = run_hook(payload("SessionStart", sid=sid, source="resume", model="claude-fable-5-1",
                         seconds_since_last_response=5400, context_tokens=1000))
    check_session_json(check_common(r, "SessionStart"))
    t = turn(sid)
    check(t.get("files_by_prompt") == tc["files_by_prompt"] and t.get("stop_blocks") == tc["stop_blocks"]
          and t.get("pending_reminder") is True, "turn cache alterado no resume: %s" % common.truncate(json.dumps(t), 120))
    starts = [l for l in r.new("sessions") if l.get("event") == "start"]
    check(starts, "sem linha start em sessions.jsonl")
    check(starts[-1].get("resumed") is True and starts[-1].get("session") == "resume01", "linha start sem resumed: true")


def t_ss_init_only():
    sid = "init0001-0000-4000-8000-000000000001"
    write_text(flag_path(sid), common.now_iso())
    cur_before = read_text(P["current_session"])
    if os.path.exists(turn_path(sid)):
        os.unlink(turn_path(sid))
    r = run_hook(payload("SessionStart", sid=sid, source="startup", model="claude-fable-5-1"))
    check_common(r, "SessionStart")
    starts = [l for l in r.new("sessions") if l.get("event") == "start"]
    check(starts and starts[-1].get("init_only") is True, "linha start sem init_only: true")
    check(read_text(P["current_session"]) == cur_before, "current-session.json alterado pela sessão-fantasma")
    check(not os.path.exists(turn_path(sid)), "turn cache criado para a sessão init_only")
    check(not os.path.exists(flag_path(sid)), "flag de setup não foi apagado")


def t_ss_compact():
    r = run_hook(payload("SessionStart", source="compact"))
    obj = check_common(r, "SessionStart")
    ctx = check_session_json(obj)
    check("Índice vivo" not in ctx and "## Memórias recentes" not in ctx, "compact injetou o INDICE")


def t_ss_clear_fork():
    seed_session_memory("c5c5c5c5", 2)
    quick_refine()
    v0 = vt(state().get("version"))
    m0 = count_lines(P["mutations"])
    r = run_hook(payload("SessionStart", sid="d6d6d6d6-0000-4000-8000-000000000001", source="clear"))
    check_session_json(check_common(r, "SessionStart"))
    st = state()
    v1 = vt(st.get("version"))
    check(v1[1] == v0[1] + 1 and v1[2] == 0, "clear não subiu o minor: %s → %s" % (v0, v1))
    check("c5c5c5c5" in (st.get("sessions_counted") or []), "sessão c5c5c5c5 fora de sessions_counted")
    check(count_lines(P["mutations"]) == m0 + 1, "mutations.jsonl não ganhou exatamente 1 linha")
    r2 = run_hook(payload("SessionStart", sid="e7e7e7e7-0000-4000-8000-000000000001", source="fork"))
    check_session_json(check_common(r2, "SessionStart"))
    st2 = state()
    check(vt(st2.get("version")) == v1, "fork sem sessão nova mudou a versão")
    check((st2.get("counts_at_session_start") or {}).get("session") == "e7e7e7e7", "fork não gravou counts_at_session_start")


def t_ss_state_absent():
    if os.path.exists(P["state"]):
        os.unlink(P["state"])
    r = run_hook(payload("SessionStart", sid="i8i8i8i8-0000-4000-8000-000000000001", source="startup"))
    obj = check_common(r, "SessionStart")
    check_session_json(obj)
    st = read_json(P["state"])
    check(isinstance(st, dict) and st.get("version"), "state.json não recriado")
    muts = common.read_jsonl(P["mutations"])
    if muts:
        last = muts[-1].get("version_after")
        check(vt(st.get("version")) >= vt(last), "versão não preservada de mutations.jsonl (%s < %s)" % (st.get("version"), last))


# --------------------------------------------------------------------------- 5. UserPromptSubmit / Expansion
def t_ups_normal():
    edit_turn(SID, lambda t: t.__setitem__("pending_reminder", False))
    r = run_hook(payload("UserPromptSubmit", prompt_id="p_ups1", prompt="faz uma LP pro evento do Reino de outubro"))
    obj = check_common(r, "UserPromptSubmit")
    if obj is not None:
        ctx = (obj.get("hookSpecificOutput") or {}).get("additionalContext") or ""
        check(len(ctx) <= 6000, "additionalContext > 6.000")
    pl = r.new("prompts")
    check(len(pl) == 1, "prompts.jsonl ganhou %d linha(s), esperava 1" % len(pl))
    l = pl[0]
    check(l.get("prompt_id") == "p_ups1" and isinstance(l.get("terms"), list) and isinstance(l.get("injected"), list)
          and not l.get("command"), "linha de prompts.jsonl fora do §3.4: %s" % common.truncate(json.dumps(l, ensure_ascii=False), 120))
    t = turn(SID)
    check(t.get("current_prompt") == "p_ups1", "turn.current_prompt não é p_ups1")
    check(t.get("permission_mode") == "auto", "turn.permission_mode != auto")


def t_ups_oi():
    edit_turn(SID, lambda t: t.__setitem__("pending_reminder", False))
    r = run_hook(payload("UserPromptSubmit", prompt_id="p_ups2", prompt="oi"))
    expect_silent(r, "UserPromptSubmit")
    pl = r.new("prompts")
    check(len(pl) == 1 and not pl[0].get("command"), "prompts.jsonl deveria ganhar 1 linha sem command")


def t_ups_command():
    edit_turn(SID, lambda t: t.__setitem__("pending_reminder", False))
    r = run_hook(payload("UserPromptSubmit", prompt_id="p_ups3", prompt="/estado"))
    expect_silent(r, "UserPromptSubmit")
    pl = r.new("prompts")
    check(len(pl) == 1 and pl[0].get("command") == "estado", "prompts.jsonl sem command: estado")


def t_ups_reminder_short():
    edit_turn(SID, lambda t: t.__setitem__("pending_reminder", True))
    r = run_hook(payload("UserPromptSubmit", prompt_id="p_ups4", prompt="oi"))
    obj = check_common(r, "UserPromptSubmit")
    check(obj is not None, "esperava JSON só com o lembrete")
    ctx = (obj.get("hookSpecificOutput") or {}).get("additionalContext") or ""
    check(ctx.lstrip().startswith("⚠"), "lembrete não começa com ⚠")
    check("remember.py" in ctx, "lembrete não cita remember.py")
    check(len(ctx) <= 300 and "Gabriel lembra" not in ctx, "contexto tem mais que o lembrete (%d chars)" % len(ctx))
    check(not turn(SID).get("pending_reminder"), "pending_reminder não foi zerado")


def t_ups_reminder_long():
    edit_turn(SID, lambda t: t.__setitem__("pending_reminder", True))
    r = run_hook(payload("UserPromptSubmit", prompt_id="p_ups5", prompt="faz a LP do evento de outubro do Reino com a identidade Babel OS"))
    obj = check_common(r, "UserPromptSubmit")
    check(obj is not None, "esperava JSON com lembrete + recall")
    ctx = (obj.get("hookSpecificOutput") or {}).get("additionalContext") or ""
    first = ctx.strip().split("\n")[0]
    check(first.startswith("⚠"), "lembrete não é a primeira linha")
    check(len(ctx) <= 6000, "contexto com %d chars (> 6.000)" % len(ctx))
    check(not turn(SID).get("pending_reminder"), "pending_reminder não foi zerado")


def t_ups_secrets():
    edit_turn(SID, lambda t: t.__setitem__("pending_reminder", False))
    prompt = "anota que a senha: 123456 e a chave sk-ABCDEFGHIJKLMNOPQRSTUVWXYZ do diego@reino.com.br ficam guardadas no cofre"
    r = run_hook(payload("UserPromptSubmit", prompt_id="p_ups6", prompt=prompt))
    check_common(r, "UserPromptSubmit")
    pl = r.new("prompts")
    check(len(pl) == 1, "prompts.jsonl sem a linha")
    text = pl[0].get("text") or ""
    check("[redigido]" in text, "segredos não redigidos em prompts.jsonl")
    check("sk-ABCDEFGHIJKLMNOPQRSTUVWXYZ" not in text and "123456" not in text, "segredo vazou em prompts.jsonl")
    check("diego@reino.com.br" in text, "e-mail foi apagado (deveria ficar)")
    for k in ("indice", "indice_completo", "retrato"):
        txt = read_text(P[k])
        if txt:
            check(not common.bare_at_lines(txt), "@ solto em %s" % os.path.basename(P[k]))


def t_upe():
    r = run_hook(payload("UserPromptExpansion", prompt_id="p_ups3", command_name="estado", command_args="x", expansion_type="skill"))
    obj = check_common(r, "UserPromptExpansion", events="exact1")
    check(obj is None, "stdout deveria ser vazio")
    ev = r.new("events")[0]
    check(ev.get("command_name") == "estado", "evento sem command_name")
    check(turn(SID).get("last_command") == "estado", "turn.last_command != estado")


# --------------------------------------------------------------------------- 6. PreToolUse
def t_pre_bash(cmd, deny):
    r = pre("Bash", {"command": cmd, "description": "teste"})
    if deny:
        expect_deny(r)
    else:
        expect_silent(r, "PreToolUse")


def t_pre_write(relpath, content, deny):
    r = pre("Write", {"file_path": os.path.join(BOX, relpath), "content": content})
    if deny:
        expect_deny(r)
    else:
        expect_silent(r, "PreToolUse")


def t_pre_edit_external():
    p = P["perfil_marcelo"]
    check(os.path.isfile(p), "perfil/marcelo.md ausente na caixa")
    hdir = os.path.join(P["history"], "marcelo")
    if os.path.isdir(hdir):
        shutil.rmtree(hdir)
    elif os.path.exists(hdir):
        os.unlink(hdir)
    before = read_text(p)
    m, _ = fm(before)
    version = int((m or {}).get("version") or 0)
    r = pre("Edit", {"file_path": p, "old_string": "Marcelo", "new_string": "Marcelo Maximus", "replace_all": False})
    expect_silent(r, "PreToolUse")
    hist = os.path.join(hdir, "v%d.md" % version)
    check(os.path.isfile(hist), ".history/marcelo/v%d.md não criado" % version)
    check(read_text(hist) == before, ".history/marcelo/v%d.md difere do texto anterior à edição" % version)
    seen = os.path.join(P["cache_texts"], "marcelo.md")
    check(read_text(seen) == before, ".cache/texts/marcelo.md difere do texto anterior")


def t_pre_edit_copy_fails():
    p = P["perfil_marcelo"]
    hdir = os.path.join(P["history"], "marcelo")
    if os.path.isdir(hdir):
        shutil.rmtree(hdir)
    write_text(hdir, "arquivo no lugar da pasta: a cópia tem que falhar\n")
    try:
        r = pre("Edit", {"file_path": p, "old_string": "a", "new_string": "b"})
        expect_silent(r, "PreToolUse")
        check(len(r.new("errors")) >= 1, "cópia falhou sem linha em errors.jsonl")
    finally:
        try:
            os.unlink(hdir)
        except Exception:
            pass


# --------------------------------------------------------------------------- 7. PostToolUse
def t_post_write_big():
    content = "<html>" + ("x" * 50000) + " SEGREDO NAO PODE APARECER </html>"
    fp = os.path.join(BOX, "entregas", "sites", "grande.html")
    r = post("Write", {"file_path": fp, "content": content}, {"filePath": fp, "type": "create"})
    expect_silent(r, "PostToolUse")
    for raw in r.new_raw("events"):
        check(len(raw) <= 1000, "linha com %d chars" % len(raw))
        check("SEGREDO NAO PODE APARECER" not in raw, "conteúdo do Write vazou em events.jsonl")
    check("SEGREDO NAO PODE APARECER" not in (read_text(P["events"]) or ""), "frase apareceu em events.jsonl")


def t_post_read_3mb():
    fp = os.path.join(BOX, "CLAUDE.md")
    r = post("Read", {"file_path": fp}, {"type": "text", "file": {"filePath": fp, "content": "y" * 3000000,
                                                                  "numLines": 1, "startLine": 1, "totalLines": 1}})
    expect_silent(r, "PostToolUse")


def t_post_handback():
    before = set(os.listdir(P["relatorios"])) if os.path.isdir(P["relatorios"]) else set()
    msg = "Relatório do pesquisador (selftest MARCADOR-7731): pesquisei 5 concorrentes do Reino. " * 20
    r = post("SubagentHandback", {"message": msg}, {}, agent_id="agent-t1", agent_type="pesquisador")
    expect_silent(r, "PostToolUse")
    after = set(os.listdir(P["relatorios"])) if os.path.isdir(P["relatorios"]) else set()
    novos = [f for f in after - before if f.endswith(".md")]
    check(len(novos) == 1, "esperava 1 arquivo novo em relatorios/, achei %d" % len(novos))
    txt = read_text(os.path.join(P["relatorios"], novos[0])) or ""
    m, body = fm(txt)
    check(m is not None and m.get("type") == "report", "relatório sem frontmatter type: report")
    check("MARCADOR-7731" in body, "relatório não contém a mensagem")


def t_post_bash_redirect():
    run_hook(payload("UserPromptSubmit", prompt_id="p_post", prompt="oi"))
    r = post("Bash", {"command": "echo x > entregas/sites/a.html", "description": "t"})
    expect_silent(r, "PostToolUse")
    check("entregas/sites/a.html" in files_for("p_post"), "files_by_prompt sem entregas/sites/a.html: %s" % files_for("p_post"))


def t_post_bash_mv():
    r = post("Bash", {"command": "mv a.html entregas/sites/b.html", "description": "t"})
    expect_silent(r, "PostToolUse")
    fs = files_for("p_post")
    check("entregas/sites/b.html" in fs, "mv: destino não marcado: %s" % fs)
    check("a.html" not in fs, "mv: origem marcada indevidamente")


def t_post_bash_sed():
    r = post("Bash", {"command": "sed -i 's/a/b/' entregas/sites/c.html", "description": "t"})
    expect_silent(r, "PostToolUse")
    check("entregas/sites/c.html" in files_for("p_post"), "sed -i: c.html não marcado")


def t_post_bash_pipe():
    before = files_for("p_post")
    r = post("Bash", {"command": "cat x | grep y", "description": "t"})
    expect_silent(r, "PostToolUse")
    check(files_for("p_post") == before, "pipe sem redirecionamento marcou arquivo")


def t_post_permission_mode():
    r = post("Read", {"file_path": os.path.join(BOX, "CLAUDE.md")}, {"type": "text", "file": {"filePath": "x", "content": "c"}},
             permission_mode="acceptEdits")
    expect_silent(r, "PostToolUse")
    check(turn(SID).get("permission_mode") == "acceptEdits", "permission_mode não gravado no turn cache")
    post("Read", {"file_path": os.path.join(BOX, "CLAUDE.md")}, {"type": "text", "file": {"filePath": "x", "content": "c"}})


# --------------------------------------------------------------------------- 8. falhas, subagentes
def t_failure(ev):
    if os.path.exists(P["last_failure"]):
        os.unlink(P["last_failure"])
    if ev == "PostToolUseFailure":
        pl = payload(ev, tool_name="WebFetch", tool_input={"url": "https://x.example"}, tool_use_id="toolu_f",
                     error="fetch failed: 502 Bad Gateway", is_interrupt=False)
    else:
        pl = payload(ev, error="rate_limit", error_details={"error_type": "rate_limit"})
    r = run_hook(pl)
    expect_silent(r, ev)
    lf = read_json(P["last_failure"])
    check(isinstance(lf, dict) and lf.get("ts") and lf.get("error"), "last-failure.json sem ts/error")


def t_statusline_api_warning():
    rc, out, err, ms = motor("statusline.py", [], stdin=json.dumps({"model": {"display_name": "Fable"}, "session_id": SID,
                                                                    "context_window": {"used_percentage": 10}}), timeout=10)
    check(rc == 0, "exit %s" % rc)
    check("⚠ API" in out, "status line sem '⚠ API' após falha recente")


def t_subagent_start():
    r = run_hook(payload("SubagentStart", agent_id="agent-t2", agent_type="pesquisador"))
    expect_silent(r, "SubagentStart")
    sub = (turn(SID).get("subagents") or {}).get("agent-t2") or {}
    check(sub.get("start"), "turn.subagents[agent-t2].start ausente")


def t_subagent_stop():
    r = run_hook(payload("SubagentStop", agent_id="agent-t2", agent_type="pesquisador", stop_hook_active=False,
                         agent_transcript_path="/x/agent.jsonl", last_assistant_message="Terminei a pesquisa."))
    obj = check_common(r, "SubagentStop")
    check(obj is None or "decision" not in obj, "SubagentStop emitiu decision")
    check(obj is None, "SubagentStop deveria ter stdout vazio")
    sub = (turn(SID).get("subagents") or {}).get("agent-t2") or {}
    check(sub.get("end"), "turn.subagents[agent-t2].end ausente")


# --------------------------------------------------------------------------- 9. Stop
def do_turn(pid, files=None, prompt="cria a lp do evento agora"):
    r = run_hook(payload("UserPromptSubmit", prompt_id=pid, prompt=prompt))
    check(r.rc == 0, "UserPromptSubmit saiu %s" % r.rc)
    for f in (files or []):
        fp = os.path.join(BOX, f)
        r = post("Write", {"file_path": fp, "content": "<html>teste</html>"}, {"filePath": fp, "type": "create"}, prompt_id=pid)
        check(r.rc == 0, "PostToolUse saiu %s" % r.rc)


def stop(pid, msg="Pronto, Marcelo. Criei a LP.", active=False, **extra):
    return run_hook(payload("Stop", prompt_id=pid, stop_hook_active=active, last_assistant_message=msg,
                            background_tasks=[], session_crons=[], **extra))


def t_stop_block():
    do_turn("p_stop1", ["entregas/sites/lp-stop1.html"])
    r = stop("p_stop1")
    obj = check_common(r, "Stop")
    check(obj is not None and obj.get("decision") == "block", "esperava {decision: block}, veio %r" % common.truncate(r.out.strip(), 60))
    check(str(obj.get("reason") or "").strip() != "", "block sem reason")
    check("hookSpecificOutput" not in obj, "block com hookSpecificOutput")
    ts = r.new("turns")
    check(len(ts) == 1, "turns.jsonl ganhou %d linha(s)" % len(ts))
    check(ts[0].get("blocked") is True and ts[0].get("followup") is False, "linha de turns sem blocked: true / followup: false")
    check((turn(SID).get("stop_blocks") or {}).get("p_stop1") == 1, "stop_blocks[p_stop1] != 1")


def t_stop_followup():
    touch_md()
    r = stop("p_stop1", "📌 Anotei: LP registrada.", active=True)
    expect_silent(r, "Stop")
    ts = r.new("turns")
    check(len(ts) == 1, "turns.jsonl ganhou %d linha(s)" % len(ts))
    check(ts[0].get("followup") is True and ts[0].get("blocked") is False, "turno de continuação sem followup: true / blocked: false")
    check(len(r.new("refinements")) >= 1, "refinements.jsonl sem linha (refino não rodou)")


def t_stop_once_per_prompt():
    r = stop("p_stop1", "Pronto de novo.")
    expect_silent(r, "Stop")


def t_stop_agent_id():
    do_turn("p_stop_ag", ["entregas/sites/lp-ag.html"])
    r = stop("p_stop_ag", agent_id="agent-zz", agent_type="pesquisador")
    check(r.rc == 0 and not r.out.strip(), "Stop dentro de subagente deveria ser vazio")
    check(len(r.new("turns")) == 0, "Stop com agent_id gravou linha em turns.jsonl")
    SUITE.stop_outputs.append(r.out or "")


def t_stop_as_subagentstop():
    r = run_hook(payload("SubagentStop", prompt_id="p_stop_ag", stop_hook_active=False, last_assistant_message="fim",
                         agent_id="agent-zz", agent_type="pesquisador"))
    check(r.rc == 0 and not r.out.strip(), "SubagentStop com campos de Stop deveria ser vazio")


def t_stop_nothing_new():
    do_turn("p_stop2", ["entregas/sites/lp-stop2.html"])
    r = stop("p_stop2", "Olhei tudo: nada novo a registrar.")
    expect_silent(r, "Stop")
    ts = r.new("turns")
    check(ts and ts[-1].get("blocked") is False, "turns.jsonl deveria registrar blocked: false")


def t_stop_gate_off():
    cfg = read_json(P["config"], dict(common.CONFIG_DEFAULTS))
    cfg["learning_gate"] = False
    write_json(P["config"], cfg)
    try:
        do_turn("p_stop3", ["entregas/sites/lp-stop3.html"])
        r = stop("p_stop3")
        expect_silent(r, "Stop")
        check(turn(SID).get("pending_reminder") is True, "pending_reminder não ficou true com o portão desligado")
    finally:
        cfg["learning_gate"] = True
        write_json(P["config"], cfg)
        edit_turn(SID, lambda t: t.__setitem__("pending_reminder", False))


def t_stop_no_turn_cache():
    tp = turn_path(SID)
    if os.path.exists(tp):
        os.unlink(tp)
    r = stop("p_stop4")
    expect_silent(r, "Stop")


def t_stop_corrupt_turn_cache():
    write_text(turn_path(SID), "{lixo do turn cache")
    r = stop("p_stop5")
    expect_silent(r, "Stop")
    errs = r.new("errors")
    check(any("turn-" in json.dumps(e, ensure_ascii=False) for e in errs), "errors.jsonl sem linha com o nome do turn cache")
    do_turn("p_stop6")


def t_stop_lock_held():
    holder = hold_lock("refine", 20)
    try:
        best = None
        for attempt in range(2):
            r = stop("p_stop6", "Só conversa.")
            expect_silent(r, "Stop")
            best = r.ms if best is None else min(best, r.ms)
            refs = r.new("refinements")
            check(any(l.get("skipped") is True for l in refs), "refinements.jsonl sem linha skipped: true")
            if r.ms < 1000:
                break
        check(best < 1000, "Stop com refine.lock ocupado demorou %.0f ms (≥ 1 s)" % best)
    finally:
        release(holder)


def t_stop_refine_sleeps():
    swap_motor_with_mock("refine.py", "#!/usr/bin/python3\nimport time, sys\ntime.sleep(3)\nsys.exit(0)\n")
    try:
        best = None
        for attempt in range(2):
            r = stop("p_stop6", "Só conversa.")
            check(r.rc == 0 and not r.out.strip(), "esperava exit 0 e stdout vazio")
            best = r.ms if best is None else min(best, r.ms)
            errs = r.new("errors")
            check(any("TimeoutExpired" in json.dumps(e) for e in errs), "errors.jsonl sem TimeoutExpired")
            if r.ms <= 2500:
                break
        check(best <= 2500, "gancho demorou %.0f ms com refine dormindo (> 2,5 s)" % best)
    finally:
        restore_motor()


def t_stop_never_additional_context():
    check(SUITE.stop_outputs, "nenhum Stop foi executado")
    bad = [o for o in SUITE.stop_outputs if "additionalContext" in o]
    check(not bad, "%d saída(s) de Stop com additionalContext" % len(bad))


# --------------------------------------------------------------------------- 10. compact, fim, config
def t_precompact():
    before = set(os.listdir(P["backups"])) if os.path.isdir(P["backups"]) else set()
    r = run_hook(payload("PreCompact", trigger="manual", custom_instructions=None))
    expect_silent(r, "PreCompact")
    after = set(os.listdir(P["backups"])) if os.path.isdir(P["backups"]) else set()
    check([f for f in after - before if f.endswith(".tar.gz")], "nenhum snapshot novo em backups/")
    check(isinstance(turn(SID).get("compact_delta"), dict), "compact_delta não gravado no turn cache")


def t_postcompact():
    lines = ["Resumo de teste linha %d: o Marcelo pediu a LP do Reino e o Gabriel construiu a página." % i for i in range(120)]
    summary = "\n".join(lines) + "\nFIM-DO-RESUMO-4412\n"
    before = set(os.listdir(P["compactacoes"])) if os.path.isdir(P["compactacoes"]) else set()
    r = run_hook(payload("PostCompact", trigger="auto", compact_summary=summary))
    expect_silent(r, "PostCompact")
    after = set(os.listdir(P["compactacoes"])) if os.path.isdir(P["compactacoes"]) else set()
    novos = [f for f in after - before if f.endswith(".md")]
    check(len(novos) == 1, "esperava 1 arquivo novo em compactacoes/, achei %d" % len(novos))
    txt = read_text(os.path.join(P["compactacoes"], novos[0])) or ""
    m, body = fm(txt)
    check(m is not None and m.get("type") == "compaction", "compactação sem type: compaction")
    check("FIM-DO-RESUMO-4412" in body and "linha 0:" in body and "linha 119:" in body, "resumo não foi salvo integral")
    check(len(r.new("compactions")) == 1, "compactions.jsonl sem a linha")


def t_session_end():
    best = None
    for attempt in range(2):
        r = run_hook(payload("SessionEnd", reason="prompt_input_exit"))
        expect_silent(r, "SessionEnd")
        ends = [l for l in r.new("sessions") if l.get("event") == "end"]
        check(len(ends) == 1, "sessions.jsonl sem linha end")
        check(ends[0].get("reason") == "prompt_input_exit", "linha end sem reason")
        ls = read_json(P["last_session"])
        check(isinstance(ls, dict), "last-session.json ausente/ilegível")
        missing = [k for k in ("session", "start", "end", "reason", "prompts", "new_memories", "files_touched",
                               "response_head", "blocked_prompts") if k not in ls]
        check(not missing, "last-session.json sem campos: %s" % ",".join(missing))
        best = r.ms if best is None else min(best, r.ms)
        if r.ms < 300:
            break
    check(best < 300, "SessionEnd demorou %.0f ms (≥ 300)" % best)


def t_config_change():
    r = run_hook(payload("ConfigChange", source="project_settings", file_path=os.path.join(BOX, ".claude", "settings.json")))
    obj = check_common(r, "ConfigChange", events="exact1")
    check(obj is None, "stdout deveria ser vazio")


def t_instructions_loaded():
    r = run_hook(payload("InstructionsLoaded", file_path=os.path.join(BOX, "CLAUDE.md"), memory_type="Project", load_reason="session_start"))
    obj = check_common(r, "InstructionsLoaded", events="exact1")
    check(obj is None, "stdout deveria ser vazio")


# --------------------------------------------------------------------------- 11. --maintenance
def t_maint_lock_held():
    holder = hold_lock("refine", 30)
    try:
        ref0 = count_lines(P["refinements"])
        mut0 = count_lines(P["mutations"])
        r = run_hook(payload("SessionStart", source="startup"), args=["--maintenance"], timeout=90)
        check(r.rc == 0 and not r.out.strip(), "esperava exit 0 e stdout vazio")
        check("Traceback" not in r.err, "traceback")
        check(count_lines(P["refinements"]) == ref0 and count_lines(P["mutations"]) == mut0, "manutenção mexeu nos logs com o lock ocupado")
    finally:
        release(holder)


def t_maint_full():
    st = state()
    old = (common.now() - datetime.timedelta(days=2)).isoformat(timespec="seconds")
    st["last_full_refinement"] = old
    write_json(P["state"], st)
    snap = Snap()
    r = run_hook(payload("SessionStart", source="startup"), args=["--maintenance"], timeout=120)
    check(r.rc == 0 and not r.out.strip(), "esperava exit 0 e stdout vazio")
    check("Traceback" not in r.err, "traceback")
    refs = snap.new("refinements")
    check(any(l.get("mode") == "full" for l in refs), "refinements.jsonl sem linha full")


def t_maint_minor_pending():
    seed_session_memory("m1m1m1m1", 3)
    quick_refine()
    st = state()
    st.setdefault("health", {})["minor_pending"] = True
    write_json(P["state"], st)
    v0 = vt(st.get("version"))
    r = run_hook(payload("SessionStart", source="startup"), args=["--maintenance"], timeout=120)
    check(r.rc == 0 and not r.out.strip(), "esperava exit 0 e stdout vazio")
    st1 = state()
    v1 = vt(st1.get("version"))
    check(v1[1] == v0[1] + 1 and v1[2] == 0, "minor pendente não concluído: %s → %s" % (v0, v1))
    check("m1m1m1m1" in (st1.get("sessions_counted") or []), "sessão m1m1m1m1 fora de sessions_counted")
    check(not (st1.get("health") or {}).get("minor_pending"), "health.minor_pending continua true")


# --------------------------------------------------------------------------- 12. bordas e PAUSA
def t_border(raw, want_chars):
    r = run_hook(raw=raw, ev="?", timeout=20)
    check(r.rc == 0, "exit %s" % r.rc)
    check(not r.out.strip(), "stdout não vazio")
    check("Traceback" not in r.err, "traceback")
    errs = r.new("errors")
    evs = r.new("events")
    check(len(errs) >= 1 or len(evs) >= 1, "nenhuma linha em errors.jsonl/events.jsonl")
    if want_chars is not None:
        check(any(e.get("stdin_chars") == want_chars for e in errs), "errors.jsonl sem stdin_chars=%d" % want_chars)


def basic_payloads():
    return [
        payload("Setup", trigger="init"),
        payload("SessionStart", source="startup"),
        payload("UserPromptSubmit", prompt_id="p_pausa", prompt="faz a LP do evento do Reino"),
        payload("UserPromptExpansion", command_name="estado", command_args="", expansion_type="skill"),
        payload("PreToolUse", tool_name="Bash", tool_input={"command": "rm -rf memoria"}, tool_use_id="t"),
        payload("PostToolUse", tool_name="Write", tool_input={"file_path": os.path.join(BOX, "entregas", "sites", "p.html"), "content": "x"},
                tool_response={"filePath": "p", "type": "create"}, tool_use_id="t"),
        payload("PostToolUseFailure", tool_name="Bash", tool_input={"command": "x"}, error="boom", tool_use_id="t"),
        payload("SubagentStart", agent_id="agent-p", agent_type="pesquisador"),
        payload("SubagentStop", agent_id="agent-p", agent_type="pesquisador", stop_hook_active=False, last_assistant_message="x"),
        payload("Stop", prompt_id="p_stop1", stop_hook_active=False, last_assistant_message="Pronto."),
        payload("StopFailure", error="rate_limit"),
        payload("PreCompact", trigger="manual", custom_instructions=None),
        payload("PostCompact", trigger="manual", compact_summary="resumo"),
        payload("SessionEnd", reason="other"),
        payload("ConfigChange", source="project_settings", file_path="x"),
        payload("InstructionsLoaded", file_path="x", memory_type="Project", load_reason="session_start"),
    ]


def t_pausa_event(pl):
    before = log_sizes()
    r = run_hook(pl, timeout=40)
    check(r.rc == 0, "exit %s" % r.rc)
    check(not r.out.strip(), "stdout não vazio com PAUSA")
    check("Traceback" not in r.err, "traceback")
    after = log_sizes()
    changed = [k for k in set(before) | set(after) if before.get(k) != after.get(k)]
    check(not changed, "logs alterados com PAUSA: %s" % ", ".join(sorted(changed))[:120])


def t_pausa_statusline():
    rc, out, err, ms = motor("statusline.py", [], stdin="{}", timeout=10)
    check(rc == 0, "exit %s" % rc)
    check("⏸" in out and "pausa" in out.lower(), "status line não avisou a pausa: %r" % out[:60])


# --------------------------------------------------------------------------- 13. arquivos corrompidos
def errors_mention(errs, name):
    return any(name in json.dumps(e, ensure_ascii=False) for e in errs)


def t_corrupt_config():
    write_text(P["config"], "{lixo")
    r = run_hook(payload("UserPromptSubmit", prompt_id="p_c1", prompt="oi"))
    check(r.rc == 0 and "Traceback" not in r.err, "exit %s" % r.rc)
    parse_stdout(r.out)
    check(glob.glob(P["config"] + ".corrupt-*"), "config.json.corrupt-<ts> não criado")
    cfg = read_json(P["config"])
    check(isinstance(cfg, dict) and "learning_gate" in cfg, "config.json não regenerado")
    check(errors_mention(r.new("errors"), "config.json"), "errors.jsonl sem o nome config.json")
    cfg["learning_gate"] = True
    write_json(P["config"], cfg)


def t_corrupt_turn():
    write_text(turn_path(SID), "{lixo")
    r = run_hook(payload("UserPromptSubmit", prompt_id="p_c2", prompt="oi"))
    check(r.rc == 0 and "Traceback" not in r.err, "exit %s" % r.rc)
    parse_stdout(r.out)
    check(isinstance(read_json(turn_path(SID)), dict), "turn cache não regenerado")
    check(errors_mention(r.new("errors"), "turn-%s.json" % SID8), "errors.jsonl sem o nome do turn cache")


def t_corrupt_cache_file(key):
    path = P[key]
    name = os.path.basename(path)
    write_text(path, "{lixo")
    touch_md()
    snap = Snap()
    r1 = run_hook(payload("UserPromptSubmit", prompt_id="p_c_" + key, prompt="faz a LP do evento de outubro do Reino"))
    check(r1.rc == 0 and "Traceback" not in r1.err, "UserPromptSubmit: exit %s" % r1.rc)
    parse_stdout(r1.out)
    r = stop("p_c_" + key, "Só conversa.")
    check(r.rc == 0 and "Traceback" not in r.err, "Stop: exit %s" % r.rc)
    parse_stdout(r.out)
    check(read_json(path, None) is not None, "%s não regenerado (continua ilegível/ausente)" % name)
    check(errors_mention(snap.new("errors"), name), "errors.jsonl sem o nome %s" % name)


def t_corrupt_offsets_too_big():
    path = P["offsets_json"]
    cur = read_json(path, None)
    check(cur is not None, "offsets.json ausente antes do teste")
    write_json(path, bump_ints(cur, 10 ** 9))
    touch_md()
    do_turn("p_c_off")
    r = stop("p_c_off", "Só conversa.")
    check(r.rc == 0, "exit %s" % r.rc)
    parse_stdout(r.out)
    new = read_json(path, None)
    size = fsize(P["prompts"])
    check(new is not None and all(i <= size for i in ints_in(new)), "offsets.json não voltou a 0 quando offset > tamanho")


def t_corrupt_last_session():
    write_text(P["last_session"], "{lixo")
    r = run_hook(payload("SessionStart", source="startup"))
    obj = check_common(r, "SessionStart")
    check_session_json(obj)
    check(errors_mention(r.new("errors"), "last-session.json"), "errors.jsonl sem o nome last-session.json")
    r2 = run_hook(payload("SessionEnd", reason="other"))
    check(r2.rc == 0, "SessionEnd saiu %s" % r2.rc)
    check(isinstance(read_json(P["last_session"]), dict), "last-session.json não regenerado")


def t_corrupt_state_or_graph(key):
    path = P[key]
    name = os.path.basename(path)
    write_text(path, "{lixo")
    r = run_hook(payload("SessionStart", source="startup"))
    obj = check_common(r, "SessionStart")
    check_session_json(obj)
    check(glob.glob(path + ".corrupt-*"), "%s.corrupt-<ts> não criado" % name)
    check(isinstance(read_json(path), dict), "%s não regenerado" % name)
    check(errors_mention(r.new("errors"), name), "errors.jsonl sem o nome %s" % name)


def t_memoria_absent():
    bak = os.path.join(BOX, "memoria.selftest-bak")
    if os.path.exists(bak):
        shutil.rmtree(bak)
    os.rename(P["memoria"], bak)
    try:
        r = run_hook(payload("SessionStart", sid="j9j9j9j9-0000-4000-8000-000000000001", source="startup"))
        obj = check_common(r, "SessionStart")
        check_session_json(obj)
        check(isinstance(read_json(P["state"]), dict), "state.json não recriado")
        check(os.path.isfile(P["indice"]), "INDICE.md não recriado")
        check(os.path.isfile(P["config"]), "config.json não recriado")
    finally:
        if os.path.exists(P["memoria"]):
            shutil.rmtree(P["memoria"])
        os.rename(bak, P["memoria"])


# --------------------------------------------------------------------------- 14. motor
def t_verify_warnings():
    kc = os.path.join(P["conhecimento"], "claude-code")
    bak = kc + ".selftest-bak"
    if os.path.exists(bak):
        shutil.rmtree(bak)
    if os.path.isdir(kc):
        os.rename(kc, bak)
    os.makedirs(kc)
    iso_old, d_old = iso_days_ago(100)
    p = write_doc("conhecimento", "claude-code-antigo", {"type": "knowledge", "title": "Claude Code antigo (teste)",
                                                          "tags": ["claude-code", "teste"], "topic": "claude-code",
                                                          "sources": [], "created": iso_old, "updated": iso_old},
                  "Conhecimento antigo de teste.", sub="claude-code")
    old_t = time.time() - 100 * 86400
    os.utime(p, (old_t, old_t))
    skdir = os.path.join(BOX, ".claude", "skills", "teste-longo")
    write_text(os.path.join(skdir, "SKILL.md"), "---\nname: teste-longo\ndescription: %s\n---\nCorpo.\n" % ("descrição longa de teste " * 14))
    try:
        rc, out, err, ms = motor("verify.py", ["--json"], timeout=60)
        check(rc == 0, "verify saiu %s" % rc)
        check("Traceback" not in err, "traceback no verify")
        warns = json.dumps((state().get("health") or {}).get("warnings") or [], ensure_ascii=False)
        blob = out + err + warns
        check("conhecimento_antigo" in blob, "sem aviso conhecimento_antigo (arquivo de 100 dias)")
        low = blob.lower()
        check(("teste-longo" in blob) or ("260" in blob) or ("descri" in low), "sem aviso de descrição de skill > 260 chars")
        touch_md()
        motor("refine.py", ["--quick", "--trigger", "selftest", "--quiet"], timeout=30)
        rc2, out2, err2, ms2 = motor("report.py", ["--suggestions", "--json"], timeout=30)
        rc3, out3, err3, ms3 = motor("report.py", ["--suggestions"], timeout=30)
        SUITE.add("motor: report.py --suggestions (conhecimento antigo)",
                  rc2 == 0 and rc3 == 0 and ("/pesquisar claude code" in out2 or "/pesquisar claude code" in out3),
                  "exit %s/%s ou sem a sugestão '/pesquisar claude code'" % (rc2, rc3), ms2 + ms3)
    finally:
        shutil.rmtree(skdir, ignore_errors=True)
        shutil.rmtree(kc, ignore_errors=True)
        if os.path.isdir(bak):
            os.rename(bak, kc)
        touch_md()
        motor("refine.py", ["--quick", "--trigger", "selftest", "--quiet"], timeout=30)


def t_refine_full():
    rc, out, err, ms = motor("refine.py", ["--full", "--trigger", "selftest"], timeout=90)
    check(rc == 0 and "Traceback" not in err, "refine --full saiu %s" % rc)
    ma, _ = fm(read_text(doc_path("memorias", SEED["dup_a"])))
    mb, _ = fm(read_text(doc_path("memorias", SEED["dup_b"])))
    check(ma and mb, "duplicatas sumiram do lugar")
    check(ma.get("status") == "active" and mb.get("status") == "superseded" and mb.get("superseded_by") == SEED["dup_a"],
          "dedup: esperava %s superseded_by %s (status %s/%s)" % (SEED["dup_b"], SEED["dup_a"], ma.get("status"), mb.get("status")))
    mo, _ = fm(read_text(doc_path("memorias", SEED["old"])))
    check(mo and mo.get("status") == "superseded" and mo.get("superseded_by") == SEED["new"], "supersedes não aplicado ao alvo")
    for k in ("indice", "indice_completo", "retrato"):
        txt = read_text(P[k]) or ""
        check(txt, "%s ausente" % os.path.basename(P[k]))
        check(not common.bare_at_lines(txt), "@ solto em %s" % os.path.basename(P[k]))
    h = state().get("health") or {}
    inv = h.get("invalid")
    check((isinstance(inv, int) and inv >= 1) or (isinstance(inv, list) and len(inv) >= 1), "health.invalid não conta o frontmatter quebrado")
    check((h.get("duplicates") or 0) >= 1, "health.duplicates == 0")
    p = doc_path("memorias", SEED["at"])
    old = read_text(p)
    m_old, b_old = fm(old)
    v_old = int((m_old or {}).get("version") or 1)
    check(os.path.isfile(os.path.join(P["cache_texts"], SEED["at"] + ".md")), ".cache/texts/<id>.md ausente antes da edição")
    write_text(p, old.rstrip("\n") + "\nLinha nova acrescentada pelo selftest.\n")
    rc, out, err, ms = motor("refine.py", ["--full", "--trigger", "selftest"], timeout=90)
    check(rc == 0, "segundo refine --full saiu %s" % rc)
    hist = os.path.join(P["history"], SEED["at"], "v%d.md" % v_old)
    check(os.path.isfile(hist), ".history/%s/v%d.md não criado a partir de .cache/texts" % (SEED["at"], v_old))
    _, bh = fm(read_text(hist))
    check(common.body_hash(bh) == common.body_hash(b_old), ".history guardou texto diferente do anterior")
    m_new, _ = fm(read_text(p))
    check(int((m_new or {}).get("version") or 0) == v_old + 1, "version não subiu para %d" % (v_old + 1))


TIMER_SRC = r'''
import os, sys, time
sys.path.insert(0, os.path.join(os.environ["BABEL_ROOT"], "motor"))
import refine
t = time.monotonic()
refine.run("quick", trigger="selftest", quiet=True)
print(int((time.monotonic() - t) * 1000))
'''


def t_refine_quick_idem():
    quick_refine()
    st0 = state()
    quick_refine()
    st1 = state()
    check(st0.get("version") == st1.get("version") and st0.get("generation") == st1.get("generation"),
          "versão/geração mudaram sem mudança: %s/%s → %s/%s" % (st0.get("version"), st0.get("generation"), st1.get("version"), st1.get("generation")))
    best = None
    for i in range(3):
        rc, out, err, ms = run([PY, "-c", TIMER_SRC], timeout=30)
        check(rc == 0 and "Traceback" not in err, "refine.run('quick') falhou: %s" % common.truncate(err.strip(), 100))
        lines = [l for l in out.strip().splitlines() if l.strip()]
        check(lines and lines[-1].strip().isdigit(), "refine.run não devolveu o tempo")
        v = int(lines[-1])
        best = v if best is None else min(best, v)
    check(best < 50, "refine --quick sem mudança levou %d ms (≥ 50)" % best)


def t_refine_count_sessions():
    seed_session_memory("s1s1s1s1", 4)
    seed_session_memory("s2s2s2s2", 4)
    quick_refine()
    st0 = state()
    v0 = vt(st0.get("version"))
    m0 = count_lines(P["mutations"])
    rc, out, err, ms = motor("refine.py", ["--state-only", "--count-sessions", "--session", "zzzz9999", "--trigger", "selftest"], timeout=30)
    check(rc == 0 and "Traceback" not in err, "saiu %s" % rc)
    st1 = state()
    v1 = vt(st1.get("version"))
    check(v1[1] == v0[1] + 1 and v1[2] == 0, "minor não subiu 1: %s → %s" % (v0, v1))
    sc = st1.get("sessions_counted") or []
    check("s1s1s1s1" in sc and "s2s2s2s2" in sc, "sessions_counted sem as duas sessões")
    check(count_lines(P["mutations"]) == m0 + 1, "mutations.jsonl não ganhou exatamente 1 linha")


def t_recall_search():
    rc, out, err, ms = motor("recall.py", ["--search", "LP do evento", "--json"], timeout=20)
    check(rc == 0 and "Traceback" not in err, "saiu %s" % rc)
    obj = json.loads(out.strip() or "{}")
    check(isinstance(obj.get("ids"), list) and obj["ids"], "JSON sem ids")
    check(SEED["lp"] in obj["ids"], "memória da LP do evento não veio nos ids: %s" % obj["ids"][:4])


def t_recall_budget():
    rc, out, err, ms = motor("recall.py", ["--prompt-stdin", "--json", "--session", SID, "--budget", "5700"],
                             stdin="faz a LP do evento de outubro do Reino com pré-cadastro", timeout=20)
    check(rc == 0 and "Traceback" not in err, "saiu %s" % rc)
    obj = json.loads(out.strip() or "{}")
    ctx = obj.get("context") or ""
    check(len(ctx) <= 5700, "context com %d chars (> 5.700)" % len(ctx))
    for k in ("ids", "expanded", "history", "ms"):
        check(k in obj, "JSON sem %s" % k)
    check(obj.get("ids"), "ids vazio para um prompt com memória casada")


def find_doc(doc_id):
    for p in common.list_docs():
        if common.doc_id_from_path(p) == doc_id:
            return p
    return None


def remember(args):
    rc, out, err, ms = motor("remember.py", args, timeout=30)
    check(rc == 0 and "Traceback" not in err, "remember saiu %s: %s" % (rc, common.truncate(err.strip(), 80)))
    line = (out.strip().splitlines() or [""])[0]
    check(line.startswith("ok "), "remember não imprimiu ok: %s" % common.truncate(out.strip(), 100))
    return line.split()[1], out


def t_remember_basic():
    args = ["--type", "preference", "--title", "Marcelo prefere LP em arquivo único (teste)", "--tags", "teste,lp",
            "--confidence", "0.8", "--text", "Fato de teste. **Por quê:** teste. **Como aplicar:** teste.", "--session", SID]
    doc_id, out = remember(args)
    p = find_doc(doc_id)
    check(p, "arquivo %s não encontrado" % doc_id)
    m, body = fm(read_text(p))
    check(m, "frontmatter inválido")
    missing = [k for k in ("id", "type", "title", "tags", "status", "created", "updated", "version", "hash") if k not in m]
    check(not missing, "frontmatter sem: %s" % ",".join(missing))
    check(m.get("hash") == common.body_hash(body), "hash não bate com o corpo")
    check(m.get("status") == "active" and int(m.get("version") or 0) == 1, "status/version errados")
    doc_id2, out2 = remember(args)
    check("similar_to" in out2, "repetição não imprimiu similar_to")


def hist_lines(body):
    n, inside = 0, False
    for l in (body or "").split("\n"):
        if l.startswith("## "):
            inside = l.strip().lower().startswith("## hist")
            continue
        if inside and l.strip().startswith("- "):
            n += 1
    return n


def t_remember_project():
    base = ["--type", "project", "--id", "proj-teste", "--title", "Projeto teste", "--session", SID]
    remember(base + ["--situation", "in-progress", "--files", "entregas/sites/f1.html", "--next", "alfa;beta", "--text", "Situação inicial do projeto"])
    p = doc_path("projetos", "proj-teste")
    check(os.path.isfile(p), "projetos/proj-teste.md não criado")
    m1, b1 = fm(read_text(p))
    h1 = hist_lines(b1)
    remember(base + ["--files", "entregas/sites/f2.html", "--next", "beta;gama", "--text", "Situação nova do projeto"])
    m2, b2 = fm(read_text(p))
    check(re.search(r"- \[x\] alfa \(concluído \d\d/\d\d\)", b2), "alfa não virou '- [x] alfa (concluído dd/mm)'")
    check(re.search(r"- \[ \] beta", b2), "beta deixou de ser aberto")
    check(re.search(r"- \[ \] gama", b2), "gama não entrou")
    check(list(m2.get("files") or []) == ["entregas/sites/f1.html", "entregas/sites/f2.html"], "--files não acumulou: %s" % m2.get("files"))
    check(hist_lines(b2) == h1 + 1, "## Histórico ganhou %d linha(s), esperava 1" % (hist_lines(b2) - h1))
    check(m2.get("created") == m1.get("created"), "created não preservado na atualização")


def t_correct_forget():
    doc_id, out = remember(["--type", "fact", "--title", "Fato para esquecer no teste", "--text", "Fato temporário.", "--session", SID])
    rc, out, err, ms = motor("correct.py", ["--forget", doc_id, "--reason", "teste", "--session", SID], timeout=30)
    check(rc == 0 and "Traceback" not in err, "correct saiu %s" % rc)
    m, _ = fm(read_text(find_doc(doc_id) or ""))
    check(m and m.get("status") == "superseded", "memória não ficou superseded: %s" % (m or {}).get("status"))


def t_agenda():
    snap = Snap()
    rc, out, err, ms = motor("agenda.py", ["new", "--when", "2030-01-15", "--text", "Cobrar o Diego (teste)", "--session", SID], timeout=30)
    check(rc == 0 and "Traceback" not in err, "agenda new saiu %s" % rc)
    news = [l for l in snap.new("agenda") if l.get("event") == "new"]
    check(news, "agenda.jsonl sem evento new")
    aid = news[-1].get("id") or ""
    check(re.match(r"^ag-\d{4}$", aid), "id fora do padrão ag-NNNN: %s" % aid)
    rc, out, err, ms = motor("agenda.py", ["list", "--open"], timeout=30)
    check(rc == 0 and "Cobrar o Diego (teste)" in out, "list --open não mostra o lembrete")
    snap2 = Snap()
    rc, out, err, ms = motor("agenda.py", ["done", aid], timeout=30)
    check(rc == 0, "agenda done saiu %s" % rc)
    check(any(l.get("event") == "done" and l.get("id") == aid for l in snap2.new("agenda")), "agenda.jsonl sem evento done")
    rc, out, err, ms = motor("agenda.py", ["list", "--open"], timeout=30)
    check("Cobrar o Diego (teste)" not in out, "lembrete concluído continua em list --open")


def t_panel():
    rc, out, err, ms = motor("panel.py", [], timeout=30)
    check(rc == 0 and "Traceback" not in err, "panel saiu %s" % rc)
    html = read_text(P["index_html"]) or ""
    check("window.BABEL" in html, "index.html sem window.BABEL")
    js = read_text(P["data_js"]) or ""
    check(js.startswith("window.BABEL"), "data.js não começa com window.BABEL")
    check("</script" not in js, "data.js contém </script sem escape")
    body = js[js.index("=") + 1:].strip().rstrip(";")
    obj = json.loads(body)
    dl = obj.get("deliveries") or []
    check(dl, "deliveries vazio (entregas/sites/teste-lp.html não varrido)")
    for d in dl:
        path = str(d.get("path") or "")
        check(path.startswith("entregas/"), "deliveries[].path não relativo: %s" % path)
    check(SEED["script"] in json.dumps(obj), "memória com </script> no título não entrou no BABEL")


def t_statusline_basic():
    rc, out, err, ms = motor("statusline.py", [], stdin="{}", timeout=10)
    check(rc == 0, "exit %s com {}" % rc)
    check(out.strip(), "stdout vazio com {}")
    mock = {"model": {"display_name": "Fable"}, "context_window": {"used_percentage": None, "current_usage": None},
            "cost": {"total_cost_usd": 0.1}, "session_id": "t", "session_name": None, "effort": None,
            "rate_limits": None, "prompt_cache": None}
    rc, out, err, ms = motor("statusline.py", [], stdin=json.dumps(mock), timeout=10)
    check(rc == 0 and out.strip(), "exit %s / stdout vazio com campos null" % rc)
    check("Gabriel" in out, "status line sem 'Gabriel'")
    rc, out, err, ms = motor("statusline.py", [], stdin="isto nao e json", timeout=10)
    check(rc == 0 and out.strip(), "stdin inválido: exit %s / stdout vazio" % rc)


def t_pause_cli():
    pausa = P["pausa"]
    if os.path.exists(pausa):
        os.unlink(pausa)
    rc, out, err, ms = motor("pause.py", ["--on"], timeout=10)
    check(rc == 0 and os.path.exists(pausa), "--on não criou PAUSA")
    rc, out, err, ms = motor("pause.py", ["--off"], timeout=10)
    check(rc == 0 and not os.path.exists(pausa), "--off não removeu PAUSA")
    rc, out, err, ms = motor("pause.py", ["--toggle"], timeout=10)
    check(rc == 0 and os.path.exists(pausa), "--toggle não criou PAUSA")
    motor("pause.py", ["--off"], timeout=10)
    check(not os.path.exists(pausa), "PAUSA ficou")


def t_rebuild():
    motor("refine.py", ["--state-only", "--trigger", "selftest", "--quiet"], timeout=30)
    before = dict((k, read_text(P[k]) or "") for k in ("retrato", "indice_completo"))
    st0 = state()
    c0, v0, g0 = st0.get("counts"), st0.get("version"), st0.get("generation")
    rc, out, err, ms = motor("rebuild.py", [], timeout=120)
    check(rc == 0 and "Traceback" not in err, "rebuild saiu %s" % rc)
    after = dict((k, read_text(P[k]) or "") for k in ("retrato", "indice_completo"))
    st1 = state()
    c1 = st1.get("counts")
    SUITE.add("motor: rebuild.py mantém as contagens", c0 == c1, "contagens mudaram: %s → %s" % (json.dumps(c0), json.dumps(c1)))
    check(st1.get("version") == v0 and st1.get("generation") == g0,
          "rebuild mudou versão/geração %s/%s → %s/%s (refino pós-rebuild tratou tudo como novo)" % (v0, g0, st1.get("version"), st1.get("generation")))
    check(strip_generated(before["retrato"]) == strip_generated(after["retrato"]), "retrato.md mudou após rebuild")
    check(strip_generated(before["indice_completo"]) == strip_generated(after["indice_completo"]), "INDICE-completo.md mudou após rebuild")


def t_snapshot():
    bdir = P["backups"]
    before = set(os.listdir(bdir))
    rc, out, err, ms = motor("snapshot.py", ["create", "--reason", "manual"], timeout=60)
    check(rc == 0 and "Traceback" not in err, "create saiu %s" % rc)
    novos = [f for f in set(os.listdir(bdir)) - before if f.endswith(".tar.gz")]
    check(len(novos) == 1, "esperava 1 tar.gz novo, achei %d" % len(novos))
    check(os.path.isfile(os.path.join(bdir, "last.json")), "backups/last.json ausente")
    rc, out, err, ms = motor("snapshot.py", ["--list"], timeout=30)
    check(rc == 0 and novos[0] in out, "--list não mostra o snapshot")
    iso, d = iso_days_ago(0)
    marker = write_doc("memorias", d + "-marcador-pos-snapshot", {"type": "fact", "title": "Marcador pós-snapshot",
                                                                  "tags": ["teste"], "created": iso, "updated": iso}, "Criado depois do snapshot.")
    listing = dict((f, fsize(os.path.join(bdir, f))) for f in os.listdir(bdir))
    rc, out, err, ms = motor("snapshot.py", ["--restore", novos[0]], timeout=120)
    check(rc == 0 and "Traceback" not in err, "--restore saiu %s" % rc)
    check(not os.path.exists(marker), "arquivo criado após o snapshot continua em memoria/ após o restore")
    lix = glob.glob(os.path.join(P["lixeira"], "memoria-*", "memorias", os.path.basename(marker)))
    check(lix, "o substrato anterior não foi para memoria/.lixeira/")
    check(dict((f, fsize(os.path.join(bdir, f))) for f in os.listdir(bdir)) == listing, "backups/ foi alterado pelo restore")
    check(os.path.isfile(P["perfil_marcelo"]) and os.path.isfile(doc_path("memorias", SEED["lp"])), "substrato não restaurado")


# --------------------------------------------------------------------------- 15. concorrência e rotação
def t_conc_post_20x50():
    n0 = count_lines(P["events"])
    snap = Snap()
    errors = []

    def worker(i):
        for j in range(50):
            pl = payload("PostToolUse", prompt_id="p_conc", tool_name="Read", tool_input={"file_path": os.path.join(BOX, "CLAUDE.md")},
                         tool_response={"type": "text", "file": {"filePath": "x", "content": "x", "numLines": 1}},
                         tool_use_id="toolu_%d_%d" % (i, j))
            try:
                rc, out, err, ms = run([PY, HOOK], stdin=json.dumps(pl), timeout=60)
                if rc != 0:
                    errors.append("exit %s" % rc)
            except Exception as e:
                errors.append(str(e))

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(20)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=600)
    check(not errors, "%d chamada(s) falharam: %s" % (len(errors), errors[0] if errors else ""))
    new = snap.new("events")
    check(not [l for l in new if "_invalid" in l], "linha partida/inválida em events.jsonl")
    mine = [l for l in new if l.get("event") == "PostToolUse"]
    check(len(mine) == 1000, "esperava 1.000 linhas PostToolUse novas, achei %d (total novo %d)" % (len(mine), len(new)))
    check(count_lines(P["events"]) >= n0 + 1000, "contagem final menor que a esperada")


LOCK_DRIVER = r'''
import os, sys, time
sys.path.insert(0, os.path.join(os.environ["BABEL_ROOT"], "motor"))
import common
path, start = sys.argv[1], float(sys.argv[2])
while time.time() < start:
    time.sleep(0.001)
def fn(o):
    n = o.get("n", 0)
    time.sleep(0.02)
    o["n"] = n + 1
common.update_json_locked(path, fn)
'''


def t_conc_update_json_locked():
    path = os.path.join(P["cache"], "turn-conc0000.json")
    write_json(path, {"n": 0})
    start = time.time() + 1.5
    procs = [subprocess.Popen([PY, "-c", LOCK_DRIVER, path, str(start)], env=ENV, cwd=BOX,
                              stdout=subprocess.DEVNULL, stderr=subprocess.PIPE) for _ in range(20)]
    for p in procs:
        p.wait(timeout=120)
    n = (read_json(path, {}) or {}).get("n")
    check(n == 20, "contador final = %s (esperado 20): lock lateral falhou" % n)


APPEND_DRIVER = r'''
import os, sys, time
sys.path.insert(0, os.path.join(os.environ["BABEL_ROOT"], "motor"))
import common
path, n = sys.argv[1], int(sys.argv[2])
for i in range(n):
    common.append_jsonl(path, {"ts": common.now_iso(), "session": "append00", "event": "PostToolUse", "tool": "Read", "summary": "concorrente %d" % i})
    time.sleep(0.02)
'''


def t_rotation():
    ev = P["events"]
    pr = P["prompts"]
    arch = P["log_archive"]
    os.makedirs(arch, exist_ok=True)
    pad = "x" * 10000
    line = json.dumps({"ts": common.now_iso(), "session": "bulk0000", "event": "PostToolUse", "tool": "Read",
                       "summary": "volume", "pad": pad}, separators=(",", ":")) + "\n"
    with io.open(ev, "a", encoding="utf-8") as f:
        for i in range(2200):
            f.write(line)
    check(fsize(ev) > 20 * 1024 * 1024, "não consegui inflar events.jsonl")
    n0 = count_lines(ev) + sum(count_lines(a) for a in glob.glob(os.path.join(arch, "events-*.jsonl")))
    big = "p" * 100000
    with io.open(pr, "a", encoding="utf-8") as f:
        for i in range(115):
            f.write(json.dumps({"ts": common.now_iso(), "session": "bulk0000", "prompt_id": "p_bulk_%d" % i, "text": "lp evento",
                                "chars": 9, "command": None, "terms": ["lp", "evento"], "injected": [], "pad": big},
                               separators=(",", ":")) + "\n")
    check(fsize(pr) > 10 * 1024 * 1024, "não consegui inflar prompts.jsonl")
    touch_md()
    quick_refine()
    appenders = [subprocess.Popen([PY, "-c", APPEND_DRIVER, ev, "100"], env=ENV, cwd=BOX, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL) for _ in range(10)]
    time.sleep(0.1)
    rc, out, err, ms = motor("maintenance.py", [], timeout=180)
    for a in appenders:
        a.wait(timeout=120)
    check(rc == 0 and "Traceback" not in err, "maintenance saiu %s" % rc)
    files = [ev] + glob.glob(os.path.join(arch, "events-*.jsonl"))
    total, bad, appended, bulk = 0, 0, 0, 0
    for fp in files:
        with io.open(fp, "r", encoding="utf-8", errors="replace") as f:
            for l in f:
                if not l.strip():
                    continue
                total += 1
                try:
                    o = json.loads(l)
                except Exception:
                    bad += 1
                    continue
                if o.get("session") == "append00":
                    appended += 1
                elif o.get("session") == "bulk0000":
                    bulk += 1
    check(bad == 0, "%d linha(s) partida(s) após a rotação" % bad)
    check(appended == 1000, "apêndices concorrentes: esperava 1.000, achei %d (linha perdida)" % appended)
    check(bulk == 2200, "linhas anteriores à rotação: esperava 2.200, achei %d" % bulk)
    check(total >= n0 + 1000, "linhas: antes %d + 1.000 apêndices, depois só %d" % (n0, total))
    check(fsize(ev) < 20 * 1024 * 1024, "events.jsonl não foi rotacionado (%.1f MB)" % (fsize(ev) / 1048576.0))
    check(fsize(pr) < 10 * 1024 * 1024, "prompts.jsonl não foi rotacionado")
    touch_md()
    quick_refine()
    off = read_json(P["offsets_json"], None)
    size = fsize(pr)
    check(off is not None and all(i <= size for i in ints_in(off)), "offsets.json não voltou a 0 após a rotação de prompts.jsonl")


# --------------------------------------------------------------------------- 16. settings, skills, plugin validate
def load_settings_timeouts():
    sp = os.path.join(LIVE_ROOT, ".claude", "settings.json")
    st = read_json(sp, None)
    if not isinstance(st, dict):
        return
    for ev, handlers in (st.get("hooks") or {}).items():
        for h in handlers or []:
            for hk in (h.get("hooks") or []):
                t = hk.get("timeout")
                if isinstance(t, (int, float)) and not hk.get("async"):
                    TIMEOUTS[ev] = min(TIMEOUTS.get(ev, t), t)


def t_settings_coverage():
    sp = os.path.join(LIVE_ROOT, ".claude", "settings.json")
    if not os.path.isfile(sp):
        return None
    rc, out, err, ms = run([PY, "-m", "json.tool", sp], timeout=20, cwd=LIVE_ROOT)
    check(rc == 0, "settings.json não é JSON estrito")
    st = read_json(sp, {})
    evs = list((st.get("hooks") or {}).keys())
    missing = [e for e in evs if e not in TESTED_EVENTS]
    check(not missing, "evento(s) no settings.json sem caso de teste: %s" % ", ".join(missing))
    check(evs, "settings.json sem hooks")


def skill_descriptions():
    out = []
    for sk in sorted(glob.glob(os.path.join(LIVE_ROOT, ".claude", "skills", "*", "SKILL.md"))):
        txt = read_text(sk) or ""
        m, _ = fm(txt)
        if not m:
            continue
        if str(m.get("disable-model-invocation")).lower() == "true":
            continue
        out.append((os.path.basename(os.path.dirname(sk)), str(m.get("description") or "")))
    return out


def t_skill_descriptions():
    longas = [(n, len(d)) for n, d in skill_descriptions() if len(d) > 260]
    check(not longas, "description > 260 chars: %s" % ", ".join("%s (%d)" % x for x in longas))


def t_plugin_validate(sub):
    d = os.path.join(LIVE_ROOT, ".claude", sub)
    if not os.path.isdir(d):
        return None
    exe = shutil.which("claude")
    if not exe:
        return None
    p = subprocess.run([exe, "plugin", "validate", os.path.join(".claude", sub)], stdin=subprocess.DEVNULL,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120, cwd=LIVE_ROOT, env=dict(os.environ))
    out = (p.stdout + p.stderr).decode("utf-8", "replace")
    check(p.returncode == 0, "claude plugin validate .claude/%s saiu %s: %s" % (sub, p.returncode, common.truncate(out.strip().replace("\n", " "), 120)))


# --------------------------------------------------------------------------- 17. cópia aprovada
def copy_approved_scripts():
    dest_root = os.path.join(LIVE_ROOT, "memoria", ".history", "motor")
    copied = []
    scripts = sorted(glob.glob(os.path.join(HERE, "*.py")))
    if os.path.isfile(HOOK):
        scripts.append(HOOK)
    for src in scripts:
        name = os.path.splitext(os.path.basename(src))[0]
        d = os.path.join(dest_root, name)
        os.makedirs(d, exist_ok=True)
        h = sha256_file(src)
        versions = []
        for f in os.listdir(d):
            m = re.match(r"^v(\d+)\.py$", f)
            if m:
                versions.append(int(m.group(1)))
        if versions:
            latest = os.path.join(d, "v%d.py" % max(versions))
            if sha256_file(latest) == h:
                continue
        n = (max(versions) + 1) if versions else 1
        target = os.path.join(d, "v%d.py" % n)
        tmp = target + ".tmp.%d" % os.getpid()
        shutil.copyfile(src, tmp)
        os.replace(tmp, target)
        copied.append(os.path.relpath(target, LIVE_ROOT))
    return copied


# --------------------------------------------------------------------------- main
def parse_args():
    ap = argparse.ArgumentParser(description="Suíte de testes do organismo Gabriel (§16.1)")
    ap.add_argument("--quick", action="store_true", help="pula concorrência, rotação e o refino completo")
    ap.add_argument("--json", action="store_true", help="saída JSON")
    ap.add_argument("--hook", default=None, help="caminho do hook.py a testar")
    return ap.parse_args()


def resolve_hook(arg):
    for cand in (arg, os.environ.get("BABEL_HOOK"), DEFAULT_HOOK, FALLBACK_HOOK):
        if cand and os.path.isfile(cand):
            return os.path.abspath(cand)
    return os.path.abspath(arg or DEFAULT_HOOK)


def run_suite(S):
    global HOOK
    if not S.as_json:
        print("selftest do Gabriel — caixa: %s" % BOX)
        print("hook: %s — modo: %s" % (HOOK, "rápido (--quick)" if S.quick else "completo"))
        sys.stdout.flush()
    load_settings_timeouts()

    # caixa primeiro (o py_compile grava o .pyc dentro dela)
    if not S.case("caixa de teste (memoria/.cache/test/root)", build_box):
        return
    S.case("sintaxe .claude/hooks/hook.py", t_compile, HOOK)
    for p in sorted(glob.glob(os.path.join(HERE, "*.py"))):
        S.case("sintaxe motor/%s" % os.path.basename(p), t_compile, p)
    S.case("hook.py presente", lambda: check(os.path.isfile(HOOK), "não encontrado: %s" % HOOK))

    # Setup
    S.case("Setup: trigger init sem state.json (verify --install + flag)", t_setup_init_install)
    S.case("Setup: trigger init com state.json (verify --repair)", t_setup_init_repair)
    S.case("Setup: trigger maintenance (--repair + maintenance)", t_setup_maintenance)
    S.case("preparar caixa: verify --repair + refine --full", t_prepare_box)

    # SessionStart
    S.case("SessionStart: dois startup seguidos → um só bump de minor", t_ss_bump_two_startups)
    S.case("SessionStart: resume preserva o turn cache e marca resumed", t_ss_resume_preserves)
    S.case("SessionStart: startup com flag de setup → init_only", t_ss_init_only)
    S.case("SessionStart: clear e fork (bump + counts_at_session_start)", t_ss_clear_fork)
    S.case("SessionStart: state.json ausente → recriado e JSON válido", t_ss_state_absent)

    # UserPromptSubmit / Expansion
    S.case("UserPromptSubmit: prompt normal (JSON ou vazio, prompts.jsonl, permission_mode)", t_ups_normal)
    S.case("UserPromptSubmit: 'oi' só loga", t_ups_oi)
    S.case("UserPromptSubmit: '/estado' só loga com command", t_ups_command)
    S.case("UserPromptSubmit: lembrete pendente + 'oi' → só o lembrete", t_ups_reminder_short)
    S.case("UserPromptSubmit: lembrete pendente + prompt longo → lembrete primeiro, ≤ 6.000", t_ups_reminder_long)
    S.case("UserPromptSubmit: segredos redigidos, e-mail preservado, sem @ solto", t_ups_secrets)
    S.case("UserPromptExpansion: log + turn.last_command", t_upe)

    # PreToolUse
    S.case("PreToolUse: rm -rf memoria → deny", t_pre_bash, "rm -rf memoria", True)
    S.case("PreToolUse: rm -rf memoria/.lixeira/x → livre", t_pre_bash, "rm -rf memoria/.lixeira/x", False)
    S.case("PreToolUse: rm -rf backups → deny", t_pre_bash, "rm -rf backups", True)
    S.case("PreToolUse: rm -rf entregas/sites/x.html → livre", t_pre_bash, "rm -rf entregas/sites/x.html", False)
    S.case("PreToolUse: ls memoria → livre", t_pre_bash, "ls memoria", False)
    S.case("PreToolUse: Write em memoria/INDICE.md → deny", t_pre_write, "memoria/INDICE.md", "x", True)
    S.case("PreToolUse: Write em backups/x → deny", t_pre_write, "backups/x", "x", True)
    S.case("PreToolUse: Write com segredo em memoria/memorias/x.md → deny", t_pre_write, "memoria/memorias/x.md", "token=abc123def456", True)
    S.case("PreToolUse: Edit externo em perfil/marcelo.md → .history e .cache/texts", t_pre_edit_external)
    S.case("PreToolUse: cópia de segurança falhando → silêncio + errors.jsonl", t_pre_edit_copy_fails)

    # PostToolUse
    S.case("PostToolUse: Write de 50 KB → linha ≤ 1.000 sem o conteúdo", t_post_write_big)
    S.case("PostToolUse: Read com 3 MB de resposta → exit 0 e linha", t_post_read_3mb)
    S.case("PostToolUse: SubagentHandback → relatório em relatorios/", t_post_handback)
    S.case("PostToolUse: Bash 'echo x > entregas/sites/a.html' marca a.html", t_post_bash_redirect)
    S.case("PostToolUse: Bash mv marca o destino, não a origem", t_post_bash_mv)
    S.case("PostToolUse: Bash sed -i marca o último caminho", t_post_bash_sed)
    S.case("PostToolUse: Bash 'cat x | grep y' não marca nada", t_post_bash_pipe)
    S.case("PostToolUse: permission_mode gravado no turn cache", t_post_permission_mode)

    # falhas e subagentes
    S.case("PostToolUseFailure: last-failure.json", t_failure, "PostToolUseFailure")
    S.case("StopFailure: last-failure.json", t_failure, "StopFailure")
    S.case("statusline.py avisa ⚠ API após falha recente", t_statusline_api_warning)
    S.case("SubagentStart: turn.subagents[id].start", t_subagent_start)
    S.case("SubagentStop: turn.subagents[id].end, sem decision", t_subagent_stop)

    # Stop
    S.case("Stop: Write em entregas/ sem memória → um {decision: block}", t_stop_block)
    S.case("Stop: stop_hook_active → vazio, followup: true, refino rodou", t_stop_followup)
    S.case("Stop: portão no máximo 1× por prompt_id", t_stop_once_per_prompt)
    S.case("Stop: com agent_id → vazio, sem linha em turns", t_stop_agent_id)
    S.case("Stop: hook_event_name SubagentStop → vazio", t_stop_as_subagentstop)
    S.case("Stop: 'nada novo a registrar' → vazio", t_stop_nothing_new)
    S.case("Stop: learning_gate false → vazio + pending_reminder", t_stop_gate_off)
    S.case("Stop: turn cache ausente → vazio", t_stop_no_turn_cache)
    S.case("Stop: turn cache corrompido → vazio + errors.jsonl com file", t_stop_corrupt_turn_cache)
    S.case("Stop: refine.lock ocupado → < 1 s, skipped: true", t_stop_lock_held)
    S.case("Stop: refine --quick dormindo 3 s → gancho sai ≤ 2,5 s com TimeoutExpired", t_stop_refine_sleeps)
    S.case("SessionStart: compact injeta só o delta", t_ss_compact)

    # compact, fim, config
    S.case("PreCompact: snapshot em backups/ + compact_delta", t_precompact)
    S.case("PostCompact: compactação integral em compactacoes/", t_postcompact)
    S.case("SessionEnd: < 300 ms, linha end e last-session.json", t_session_end)
    S.case("ConfigChange: 1 linha, stdout vazio", t_config_change)
    S.case("InstructionsLoaded: 1 linha, stdout vazio", t_instructions_loaded)

    # --maintenance
    S.case("hook.py --maintenance com refine.lock ocupado → sai sem tocar nada", t_maint_lock_held)
    S.case("hook.py --maintenance livre → refino full quando last_full > 24 h", t_maint_full)
    S.case("hook.py --maintenance conclui minor_pending", t_maint_minor_pending)

    # bordas
    S.case("borda: stdin vazio", t_border, "", 0)
    S.case("borda: stdin não-JSON", t_border, "abc", 3)
    S.case("borda: JSON sem hook_event_name", t_border, json.dumps({"session_id": SID}), None)
    S.case("borda: hook_event_name inventado", t_border, json.dumps(payload("Inventado")), None)
    S.case("Stop: nunca additionalContext", t_stop_never_additional_context)
    write_text(P["pausa"], "selftest\n")
    try:
        for pl in basic_payloads():
            S.case("PAUSA: %s → nada logado, stdout vazio" % pl["hook_event_name"], t_pausa_event, pl)
        S.case("PAUSA: statusline.py avisa a pausa", t_pausa_statusline)
    finally:
        try:
            os.unlink(P["pausa"])
        except Exception:
            pass

    # corrompidos
    S.case("corrompido: config.json", t_corrupt_config)
    S.case("corrompido: turn-<sid8>.json", t_corrupt_turn)
    S.case("corrompido: docs.json", t_corrupt_cache_file, "docs_json")
    S.case("corrompido: index.json", t_corrupt_cache_file, "index_json")
    S.case("corrompido: signature.json", t_corrupt_cache_file, "signature_json")
    S.case("corrompido: offsets.json", t_corrupt_cache_file, "offsets_json")
    S.case("corrompido: offsets.json com valor > tamanho de prompts.jsonl", t_corrupt_offsets_too_big)
    S.case("corrompido: last-session.json", t_corrupt_last_session)
    S.case("corrompido: state.json", t_corrupt_state_or_graph, "state")
    S.case("corrompido: graph.json", t_corrupt_state_or_graph, "graph")
    S.case("corrompido: memoria/ inteira ausente → SessionStart recria", t_memoria_absent)

    # motor
    S.case("motor: verify.py avisos (descrição > 260, conhecimento_antigo)", t_verify_warnings)
    if not S.quick:
        S.case("motor: refine --full (dedup, supersedes, @, inválidos, .history)", t_refine_full)
    S.case("motor: refine --quick idempotente e < 50 ms", t_refine_quick_idem)
    S.case("motor: refine --state-only --count-sessions (2 sessões, 1 bump)", t_refine_count_sessions)
    S.case("motor: recall.py --search 'LP do evento' --json", t_recall_search)
    S.case("motor: recall.py --budget 5700", t_recall_budget)
    S.case("motor: remember.py (frontmatter válido, similar_to)", t_remember_basic)
    S.case("motor: remember.py --type project (--next mescla, --files acumula)", t_remember_project)
    S.case("motor: correct.py --forget", t_correct_forget)
    S.case("motor: agenda.py new/list/done", t_agenda)
    S.case("motor: panel.py (window.BABEL, </script, deliveries relativos)", t_panel)
    S.case("motor: statusline.py com {} e campos null", t_statusline_basic)
    S.case("motor: pause.py --on/--off/--toggle", t_pause_cli)
    S.case("motor: rebuild.py (versão preservada, retrato/INDICE-completo byte a byte)", t_rebuild)
    S.case("motor: snapshot.py create/--list/--restore", t_snapshot)

    # concorrência e rotação
    if not S.quick:
        S.case("concorrência: 20 × 50 PostToolUse em paralelo", t_conc_post_20x50)
        S.case("concorrência: 20 processos em update_json_locked → 20", t_conc_update_json_locked)
        S.case("rotação: events.jsonl > 20 MB com 10 appends durante maintenance.py", t_rotation)

    # settings / skills / plugin validate
    S.case("settings.json: JSON estrito e todo evento com caso", t_settings_coverage)
    S.case("skills: description ≤ 260 chars (modelo-invocáveis)", t_skill_descriptions)
    S.case("claude plugin validate .claude/skills", t_plugin_validate, "skills")
    S.case("claude plugin validate .claude/agents", t_plugin_validate, "agents")


def main():
    global SUITE, HOOK
    args = parse_args()
    S = Suite(args.quick, args.json)
    SUITE = S
    HOOK = resolve_hook(args.hook)
    copied = []
    fatal = ""
    try:
        run_suite(S)
    except KeyboardInterrupt:
        fatal = "interrompido"
    except BaseException as e:
        fatal = "%s: %s" % (type(e).__name__, common.truncate(str(e), 200))
        S.add("selftest (erro interno)", False, fatal)
    total = len(S.items)
    passed = S.passed()
    ok = total > 0 and passed == total and not fatal
    if ok:
        try:
            copied = copy_approved_scripts()
        except Exception as e:
            S.add("cópia dos scripts aprovados para memoria/.history/motor/", False, str(e))
            ok = False
            total = len(S.items)
    if args.json:
        print(json.dumps({"ok": ok, "passed": passed, "total": total, "quick": args.quick, "box": BOX, "hook": HOOK,
                          "history_copied": copied, "items": S.items}, ensure_ascii=False, indent=2))
    else:
        print("%d/%d passaram" % (passed, total))
        if ok:
            if copied:
                print("100 %%: %d script(s) aprovado(s) copiado(s) para memoria/.history/motor/ (%s)" % (len(copied), ", ".join(copied)))
            else:
                print("100 %: scripts aprovados já estavam em memoria/.history/motor/ (hash igual)")
        else:
            print("nada copiado para memoria/.history/motor/ (só com 100 %)")
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except BaseException as e:
        try:
            common.log_error("selftest.py", e)
            sys.stdout.write("FALHOU selftest: %s\n" % common.truncate(str(e), 200))
        except Exception:
            pass
    sys.exit(0)
