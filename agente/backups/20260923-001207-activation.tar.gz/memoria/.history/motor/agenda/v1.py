#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
agenda.py — lembretes event-sourced em memoria/log/agenda.jsonl (spec §11.9, §3.5).

  agenda.py new --when <hoje|amanha|dd/mm|dd/mm/AAAA|AAAA-MM-DD> --text "…" [--session ID]
  agenda.py done <id> [--session ID]
  agenda.py list [--open] [--json]

O estado de cada id é o último evento (`new` → aberto; `done` → feito). Nada é reescrito. Sempre exit 0.
"""
import os, sys, re, json, time, argparse, datetime, unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

SCRIPT = "agenda.py"
_ID_RE = re.compile(r"^ag-(\d+)$")


def _fold(s):
    return "".join(c for c in unicodedata.normalize("NFKD", str(s or "")) if not unicodedata.combining(c)).lower().strip()


def parse_when(s):
    """Devolve AAAA-MM-DD ou None. Aceita hoje, amanha/amanhã, dd/mm, dd/mm/AAAA, AAAA-MM-DD."""
    if s is None:
        return None
    raw = _fold(s)
    today = common.now().date()
    if raw in ("hoje", "today"):
        return today.isoformat()
    if raw in ("amanha", "tomorrow"):
        return (today + datetime.timedelta(days=1)).isoformat()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", raw)
    if m:
        try:
            return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
        except Exception:
            return None
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?", raw)
    if m:
        d, mo = int(m.group(1)), int(m.group(2))
        y = m.group(3)
        try:
            if y:
                yi = int(y)
                if yi < 100:
                    yi += 2000
                return datetime.date(yi, mo, d).isoformat()
            cand = datetime.date(today.year, mo, d)
            if cand < today:
                cand = datetime.date(today.year + 1, mo, d)
            return cand.isoformat()
        except Exception:
            return None
    return None


def events():
    return common.read_jsonl(common.P["agenda"])


def resolve(evs=None):
    """Estado final por id: lista de {id, when, text, status, session, ts, done_ts} (ordem de criação)."""
    if evs is None:
        evs = events()
    items = {}
    order = []
    for e in evs:
        if not isinstance(e, dict):
            continue
        eid = e.get("id")
        ev = e.get("event")
        if not eid:
            continue
        if ev == "new":
            if eid not in items:
                order.append(eid)
            items[eid] = {"id": eid, "when": str(e.get("when") or ""), "text": str(e.get("text") or ""), "status": "open",
                          "session": e.get("session"), "ts": e.get("ts"), "done_ts": None}
        elif ev == "done" and eid in items:
            items[eid]["status"] = "done"
            items[eid]["done_ts"] = e.get("ts")
    return [items[i] for i in order]


def next_id(evs):
    mx = 0
    for e in evs:
        try:
            m = _ID_RE.match(str(e.get("id") or ""))
            if m:
                mx = max(mx, int(m.group(1)))
        except Exception:
            continue
    return "ag-%04d" % (mx + 1)


def sort_open(items):
    """Vencidos primeiro (mais antigos antes), depois por data crescente; empate por id."""
    today = common.today()
    return sorted(items, key=lambda x: (0 if x["when"] < today else 1, x["when"], x["id"]))


def fmt_when(when):
    try:
        d = datetime.date.fromisoformat(when)
        return d.strftime("%d/%m")
    except Exception:
        return when or "?"


def render_list(items, only_open=False):
    today = common.today()
    open_items = sort_open([i for i in items if i["status"] == "open"])
    done_items = [i for i in items if i["status"] == "done"]
    lines = []
    overdue = [i for i in open_items if i["when"] < today]
    lines.append("Lembretes — abertos: %d · vencidos: %d · feitos: %d" % (len(open_items), len(overdue), len(done_items)))
    if not open_items:
        lines.append("(nenhum lembrete aberto)")
    for i in open_items:
        if i["when"] < today:
            days = (datetime.date.fromisoformat(today) - datetime.date.fromisoformat(i["when"])).days if re.fullmatch(r"\d{4}-\d{2}-\d{2}", i["when"]) else 0
            tag = "⚠ vencido há %d dia%s (%s)" % (days, "" if days == 1 else "s", fmt_when(i["when"]))
        elif i["when"] == today:
            tag = "hoje"
        else:
            tag = fmt_when(i["when"])
        lines.append("- %s · %s (%s)" % (tag, i["text"], i["id"]))
    if not only_open and done_items:
        lines.append("Feitos:")
        for i in sorted(done_items, key=lambda x: (x.get("done_ts") or "", x["id"]), reverse=True)[:20]:
            lines.append("- ✓ %s · %s (%s)" % (fmt_when(i["when"]), i["text"], i["id"]))
    return "\n".join(lines)


def run_refine(trigger="agenda"):
    rc, _, _ = common.run_motor("refine.py", ["--quick", "--trigger", trigger, "--quiet"], timeout=3.0)
    return rc == 0


def cmd_new(when_raw, text, sid):
    when = parse_when(when_raw)
    if not when:
        return {"ok": False, "error": "data inválida '%s' (use hoje, amanha, dd/mm ou AAAA-MM-DD)" % (when_raw or "")}
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if not text:
        return {"ok": False, "error": "faltou --text"}
    if common.looks_secret(text):
        return {"ok": False, "error": "parece segredo"}
    text = common.truncate(common.redact(text), 300)
    evs = events()
    eid = next_id(evs)
    line = {"ts": common.now_iso(), "event": "new", "id": eid, "when": when, "text": text, "session": sid}
    if not common.append_jsonl(common.P["agenda"], line):
        return {"ok": False, "error": "não consegui gravar em %s" % common.rel(common.P["agenda"])}
    return {"ok": True, "id": eid, "when": when, "text": text, "action": "new"}


def cmd_done(eid, sid):
    eid = str(eid or "").strip().lower()
    if not _ID_RE.match(eid):
        return {"ok": False, "error": "id inválido '%s' (formato ag-NNNN)" % eid}
    items = {i["id"]: i for i in resolve()}
    it = items.get(eid)
    if not it:
        return {"ok": False, "error": "lembrete não encontrado: %s" % eid}
    if it["status"] == "done":
        return {"ok": True, "id": eid, "action": "done", "already": True, "text": it["text"]}
    line = {"ts": common.now_iso(), "event": "done", "id": eid, "session": sid}
    if not common.append_jsonl(common.P["agenda"], line):
        return {"ok": False, "error": "não consegui gravar em %s" % common.rel(common.P["agenda"])}
    return {"ok": True, "id": eid, "action": "done", "already": False, "text": it["text"]}


def build_parser():
    ap = argparse.ArgumentParser(prog="agenda.py")
    sub = ap.add_subparsers(dest="cmd")
    n = sub.add_parser("new")
    n.add_argument("--when", required=True)
    n.add_argument("--text", required=True)
    n.add_argument("--session", default=None)
    n.add_argument("--json", dest="as_json", action="store_true")
    n.add_argument("--no-refine", dest="no_refine", action="store_true", help=argparse.SUPPRESS)
    d = sub.add_parser("done")
    d.add_argument("id")
    d.add_argument("--session", default=None)
    d.add_argument("--json", dest="as_json", action="store_true")
    d.add_argument("--no-refine", dest="no_refine", action="store_true", help=argparse.SUPPRESS)
    l = sub.add_parser("list")
    l.add_argument("--open", dest="only_open", action="store_true")
    l.add_argument("--json", dest="as_json", action="store_true")
    return ap


def main():
    as_json = "--json" in sys.argv[1:]
    try:
        args = build_parser().parse_args()
        as_json = getattr(args, "as_json", False)
        t0 = time.monotonic()
        if args.cmd == "new":
            sid = common.sid8(args.session or common.session_id_fallback())
            r = cmd_new(args.when, args.text, sid)
            if r.get("ok") and not args.no_refine:
                run_refine()
            r["ms"] = int((time.monotonic() - t0) * 1000)
            if as_json:
                print(json.dumps(r, ensure_ascii=False))
            elif r.get("ok"):
                print("ok %s %s" % (r["id"], r["when"]))
            else:
                print("erro %s" % r["error"])
        elif args.cmd == "done":
            sid = common.sid8(args.session or common.session_id_fallback())
            r = cmd_done(args.id, sid)
            if r.get("ok") and not r.get("already") and not args.no_refine:
                run_refine()
            r["ms"] = int((time.monotonic() - t0) * 1000)
            if as_json:
                print(json.dumps(r, ensure_ascii=False))
            elif r.get("ok"):
                print("ok %s%s" % (r["id"], " (já estava concluído)" if r.get("already") else " concluído"))
            else:
                print("erro %s" % r["error"])
        elif args.cmd == "list":
            items = resolve()
            if args.only_open:
                items = [i for i in items if i["status"] == "open"]
            if as_json:
                today = common.today()
                out = sort_open([i for i in items if i["status"] == "open"]) + [i for i in items if i["status"] == "done"]
                print(json.dumps({"today": today, "items": out}, ensure_ascii=False))
            else:
                print(render_list(items, only_open=args.only_open))
        else:
            print("erro use: new --when D --text T | done <id> | list [--open]")
    except SystemExit:
        pass
    except BaseException as e:
        common.log_error(SCRIPT, e)
        if as_json:
            print(json.dumps({"ok": False, "error": type(e).__name__}, ensure_ascii=False))
        else:
            print("erro %s" % type(e).__name__)
    sys.exit(0)


if __name__ == "__main__":
    main()
