#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
report.py --state | --profile | --pending | --panel | --origin | --suggestions [--json]  (spec §11.14)

Textos em português (o que as skills /estado, /perfil, /pendencias, /painel, /origem e /evoluir mostram).
Só leitura (nunca escreve no substrato). Sempre exit 0.
"""
import os, sys, io, re, json, time, socket, datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

P = common.P
AUTO_MEMORY_MAX_LINES = 200
AUTO_MEMORY_MAX_BYTES = 25 * 1024
PANEL_PORT = 8765

WARN_PT = {
    "iterm_cc_status": "o anotador do iTerm2 (cc-status) aponta para pasta temporária do macOS; se aparecer 'hook error', não é o Gabriel — refaça a integração do iTerm2 (LEIA-ME, aviso 8a)",
    "hooks_desligados_global": "~/.claude/settings.json tem disableAllHooks: true — os hooks do organismo estão desligados",
    "block_reads_global": "~/.claude/settings.json bloqueia leituras fora da pasta — a memória automática fica inacessível",
    "settings_invalido": ".claude/settings.json inválido: nenhum hook está rodando",
    "settings_ausente": "não existe .claude/settings.json: os hooks não estão ligados",
    "hook_arquivo_ausente": "um hook do settings.json aponta para arquivo inexistente",
    "hook_fora_exec_form": "um hook do settings.json não está em exec form",
    "claude_dir_incompleto": "falta algo em .claude/ (hook, skills, agents ou rules); recrie com selftest.py antes",
    "motor_incompleto": "faltam scripts em motor/: /evoluir reparar",
    "frontmatter_invalido": "há memória com frontmatter inválido",
    "indice_grande": "o INDICE.md passou dos limites",
    "claude_md_import": "o CLAUDE.md não tem exatamente 1 @import relativo",
    "claude_md_linhas": "o CLAUDE.md passou de 180 linhas",
    "claude_md_ausente": "não existe CLAUDE.md",
    "skill_descricao_longa": "há skill com description > 260 chars (custa contexto em todo turno)",
    "memory_md_grande": "o MEMORY.md da memória automática passou do limite (200 linhas / 25 KB)",
    "auto_memory_ausente": "a pasta da memória automática não existe (git init ou CLAUDE_CONFIG_DIR?)",
    "config_corrompido": "config.json estava corrompido e foi recriado",
    "state_corrompido": "state.json estava corrompido e foi refeito",
    "graph_corrompido": "graph.json estava corrompido e foi refeito",
    "cache_regenerado": "um cache ilegível foi regenerado",
    "events_grande": "events.jsonl passou de 20 MB; a manutenção rotaciona",
    "offsets_zerado": "offsets.json foi zerado (reindexação dos prompts)",
    "conhecimento_antigo": "o conhecimento do Claude Code está velho: /pesquisar claude code atualiza",
    "cwd_diferente": "o claude não foi aberto de dentro de babel-os",
    "pausa": "arquivo PAUSA presente: hooks e linha de status parados",
    "template_ausente": "dashboard/template.html sumiu; painel mínimo em uso",
    "minor_pending": "versão minor pendente (a manutenção conclui)",
}


# --------------------------------------------------------------------------- dados

def _state():
    s = common.load_json(P["state"], {}, script="report.py")
    return s if isinstance(s, dict) else {}


def _docs():
    """[{id, title, type, collection, created, updated, tags, project, status, pinned, similar_to, path}] de todas as coleções."""
    out = []
    for path in common.list_docs():
        txt = common.read_text(path)
        if not txt:
            continue
        meta, body = common.read_frontmatter(txt)
        if not isinstance(meta, dict):
            continue
        out.append({"id": meta.get("id") or common.doc_id_from_path(path), "title": str(meta.get("title") or common.doc_id_from_path(path)),
                    "type": meta.get("type"), "collection": common.collection_of(path), "created": str(meta.get("created") or ""),
                    "updated": str(meta.get("updated") or ""), "tags": [str(t) for t in (meta.get("tags") or []) if t is not None],
                    "project": meta.get("project"), "status": meta.get("status") or "active", "pinned": meta.get("pinned") is True,
                    "similar_to": [str(x) for x in (meta.get("similar_to") or [])], "path": path, "body": body or "",
                    "situation": meta.get("situation"), "summary": meta.get("summary")})
    return out


def _projects(docs=None):
    docs = docs if docs is not None else _docs()
    out = []
    for d in docs:
        if d["collection"] != "projetos" or d["status"] != "active":
            continue
        open_items, done_items = [], []
        in_next = False
        for line in d["body"].split("\n"):
            s = line.strip()
            if s.startswith("## "):
                in_next = "próximos" in s.lower() or "proximos" in s.lower()
                continue
            if in_next and s.startswith("- [ ]"):
                open_items.append(s[5:].strip())
            elif in_next and s.startswith("- [x]"):
                done_items.append(s[5:].strip())
        out.append({"id": d["id"], "title": d["title"], "situation": d.get("situation") or "in-progress", "summary": d.get("summary") or "",
                    "next": open_items, "done": done_items, "updated": d["updated"], "tags": d["tags"]})
    order = {"in-progress": 0, "idea": 1, "paused": 2, "delivered": 3}
    out.sort(key=lambda p: (order.get(p["situation"], 9), p["updated"] and -len(p["updated"]), p["updated"], p["id"]))
    return out


SITUATION_PT = {"in-progress": "em andamento", "idea": "ideia", "paused": "parado", "delivered": "entregue"}


def agenda_items():
    items = {}
    for ev in common.read_jsonl(P["agenda"]):
        if not isinstance(ev, dict) or not ev.get("id"):
            continue
        if ev.get("event") == "new":
            items[ev["id"]] = {"id": ev["id"], "when": str(ev.get("when") or ""), "text": str(ev.get("text") or ""), "status": "open"}
        elif ev.get("event") == "done":
            items.pop(ev["id"], None)
    return sorted(items.values(), key=lambda x: (x["when"], x["id"]))


def auto_memory_gauge():
    p = os.path.join(P["auto_memory"], "MEMORY.md")
    txt = common.read_text(p)
    if txt is None:
        return {"exists": os.path.isdir(P["auto_memory"]), "lines": 0, "bytes": 0}
    return {"exists": True, "lines": txt.count("\n") + (0 if txt.endswith("\n") else 1), "bytes": len(txt.encode("utf-8"))}


def _fmt_age(days):
    if days is None:
        return "?"
    d = int(days)
    if d < 1:
        return "hoje"
    return "%d dia%s" % (d, "" if d == 1 else "s")


def _clean(s, n=120):
    return common.truncate(common.escape_at(common.redact(str(s or "").replace("\n", " ").strip())), n)


# --------------------------------------------------------------------------- --state

def report_state(as_json):
    st = _state()
    counts = st.get("counts") or {}
    health = st.get("health") or {}
    cc = st.get("context_cost") or {}
    docs = _docs()
    projects = _projects(docs)
    agenda = agenda_items()
    today = common.today()
    muts = common.read_jsonl(P["mutations"], last=3)
    am = auto_memory_gauge()
    warnings = [w for w in (health.get("warnings") or []) if isinstance(w, str)]
    last = st.get("last_session") if isinstance(st.get("last_session"), dict) else None
    if not last:
        for s in reversed(common.read_jsonl(P["sessions"], last=100)):
            if isinstance(s, dict) and s.get("event") == "end" and (s.get("prompts") or 0) > 0:
                last = {"id": s.get("session"), "end": s.get("ts"), "prompts": s.get("prompts"), "new_memories": s.get("new_memories")}
                break
    if as_json:
        print(json.dumps({"version": st.get("version"), "generation": st.get("generation"), "activated_at": st.get("activated_at"),
                          "age_days": common.dias_desde(st.get("activated_at") or ""), "counts": counts, "by_type": st.get("by_type") or {},
                          "projects": projects, "pending": st.get("pending") or [], "agenda": agenda, "health": health,
                          "warnings": warnings, "last_session": last, "mutations": muts, "context_cost": cc,
                          "auto_memory": am, "paused": common.paused()}, ensure_ascii=False, indent=2, default=str))
        return
    L = []
    age_days = common.dias_desde(st.get("activated_at") or "")
    L.append("Organismo Gabriel v%s · geração %s · %s (desde %s)%s" % (
        st.get("version") or "?", st.get("generation") or 0,
        "vivo desde hoje" if (age_days is not None and age_days < 1) else "vivo há %s" % _fmt_age(age_days),
        common.fmt_ddmm(st.get("activated_at") or ""), " · ⏸ EM PAUSA" if common.paused() else ""))
    L.append("Contagens: %d memórias · %d decisões · %d projetos · %d conhecimentos · %d compactações · %d relatórios · %d pedidos · %d sessões · %d tags" % tuple(
        int(counts.get(k) or 0) for k in ("memories", "decisions", "projects", "knowledge", "compactions", "reports", "prompts", "sessions", "tags")))
    bt = st.get("by_type") or {}
    if bt:
        L.append("Por tipo: " + " · ".join("%s %d" % (common.label_type(k), v) for k, v in sorted(bt.items(), key=lambda kv: (-kv[1], kv[0]))))
    if projects:
        L.append("Projetos:")
        for p in projects[:10]:
            nxt = ("próximo: " + _clean(p["next"][0], 80)) if p["next"] else "sem próximo passo aberto"
            L.append("- %s (%s) — %s · %s%s" % (p["id"], SITUATION_PT.get(p["situation"], p["situation"]), _clean(p["summary"] or p["title"], 90), nxt,
                                                 (" (+%d)" % (len(p["next"]) - 1)) if len(p["next"]) > 1 else ""))
    pend = [p for p in (st.get("pending") or []) if isinstance(p, dict)]
    if pend:
        L.append("Pendências abertas (%d):" % len(pend))
        for p in pend[:10]:
            since = p.get("since") or ""
            age = common.dias_desde(since) if since else None
            L.append("- [ ] %s: %s%s" % (p.get("project") or "?", _clean(p.get("item"), 100), (" · há %s" % _fmt_age(age)) if age is not None else ""))
    if agenda:
        over = [a for a in agenda if a["when"][:10] < today]
        L.append("Agenda: %d aberto(s), %d vencido(s)" % (len(agenda), len(over)))
        for a in agenda[:8]:
            L.append("- %s%s · %s (%s)" % (common.fmt_ddmm(a["when"]), " ⚠ vencido" if a["when"][:10] < today else "", _clean(a["text"], 90), a["id"]))
    L.append("Saúde: %d órfãs · %d duplicatas · %d similares · %d inválidas · índice %s linhas / %s bytes (máx %s) · logs %s MB · conhecimento Claude Code: %s" % (
        int(health.get("orphans") or 0), int(health.get("duplicates") or 0), int(health.get("similar") or 0), int(health.get("invalid") or 0),
        health.get("index_lines", "?"), health.get("index_bytes", "?"), health.get("index_max_lines", "?"), health.get("log_mb", "?"),
        ("%d dias" % int(health["knowledge_age_days"])) if isinstance(health.get("knowledge_age_days"), (int, float)) else "sem data"))
    if warnings:
        L.append("Avisos (%d):" % len(warnings))
        for w in warnings:
            base = w.split(":")[0]
            L.append("- ⚠ %s%s" % (WARN_PT.get(base, base), (" (%s)" % w.split(":", 1)[1]) if ":" in w and base in WARN_PT else ""))
    else:
        L.append("Avisos: nenhum.")
    if last:
        L.append("Última sessão: %s em %s · %s pedido(s) · %s memória(s) nova(s)%s" % (
            last.get("id") or "?", common.fmt_ddmm(last.get("end") or last.get("start") or "", hora=True), last.get("prompts", "?"),
            last.get("new_memories", "?"), (" · " + _clean(last.get("summary"), 120)) if last.get("summary") else ""))
    else:
        L.append("Última sessão: nenhuma sessão com pedidos registrada ainda.")
    if muts:
        L.append("Últimas mutações:")
        for m in muts:
            if not isinstance(m, dict):
                continue
            L.append("- %s · %s → %s · +%d novas, %d alteradas, %d superadas · %s%s" % (
                common.fmt_ddmm(m.get("ts") or "", hora=True), m.get("version_before", "?"), m.get("version_after", "?"),
                len(m.get("new") or []), len(m.get("changed") or []), len(m.get("superseded") or []), m.get("trigger") or "?",
                (" · " + _clean(m.get("reason"), 80)) if m.get("reason") else ""))
    L.append("Custo de contexto: CLAUDE.md %s linhas · INDICE %s linhas · %s rules sem paths · descrições de skills %s chars (máx %s por skill) · ≈ %s tokens por sessão, ≈ %s por turno" % (
        cc.get("claude_md_lines", "?"), cc.get("index_lines", "?"), cc.get("rules_without_paths", "?"), cc.get("skill_descriptions_chars", "?"),
        cc.get("skill_description_max_chars", 260), cc.get("tokens_per_session_est", "?"), cc.get("tokens_per_turn_est", "?")))
    L.append("Memória automática (só leitura): %s linhas/%d · %s bytes/%d KB%s" % (
        am["lines"], AUTO_MEMORY_MAX_LINES, am["bytes"], AUTO_MEMORY_MAX_BYTES // 1024, "" if am["exists"] else " · pasta ausente"))
    print("\n".join(L))


# --------------------------------------------------------------------------- --profile

def report_profile(as_json):
    st = _state()
    prof = st.get("profile") if isinstance(st.get("profile"), dict) else {}
    txt = common.read_text(P["retrato"])
    body = ""
    if txt:
        meta, body = common.read_frontmatter(txt)
        body = body or ""
    if as_json:
        print(json.dumps({"summary": prof.get("summary"), "portrait": body, "learned_today": prof.get("learned_today") or [],
                          "want_to_learn": prof.get("want_to_learn") or []}, ensure_ascii=False, indent=2))
        return
    L = []
    if body.strip():
        L.append(body.strip())
    else:
        mtxt = common.read_text(P["perfil_marcelo"])
        if mtxt:
            m, b = common.read_frontmatter(mtxt)
            L.append("Retrato ainda não compilado (o próximo refino gera perfil/retrato.md). O que sei, de perfil/marcelo.md:")
            cut = (b or "").strip()
            if len(cut) > 4000:
                cut = cut[:4000]
                cut = cut[:cut.rfind("\n")] + "\n…"
            L.append(common.escape_at(cut))
        else:
            L.append("Ainda não sei nada do Marcelo: perfil/marcelo.md não existe.")
    if prof.get("summary"):
        L.append("")
        L.append("Resumo: " + _clean(prof["summary"], 200))
    lt = prof.get("learned_today") or []
    L.append("")
    L.append("Aprendi hoje: " + ("; ".join(_clean(x, 100) for x in lt[:5]) if lt else "nada ainda hoje"))
    wl = prof.get("want_to_learn") or []
    if wl:
        L.append("Ainda quero aprender:")
        for i, q in enumerate(wl[:3], 1):
            L.append("%d. %s" % (i, _clean(q, 140)))
    print("\n".join(L))


# --------------------------------------------------------------------------- --pending

def report_pending(as_json):
    projects = [p for p in _projects() if p["next"]]
    agenda = agenda_items()
    today = common.today()
    if as_json:
        print(json.dumps({"projects": projects, "agenda": agenda}, ensure_ascii=False, indent=2))
        return
    L = []
    if projects:
        L.append("Pendências por projeto:")
        for p in projects:
            L.append("- %s (%s):" % (p["id"], SITUATION_PT.get(p["situation"], p["situation"])))
            for it in p["next"][:10]:
                L.append("  - [ ] %s" % _clean(it, 110))
    else:
        L.append("Nenhum projeto com próximo passo aberto.")
    if agenda:
        L.append("Agenda por data:")
        for a in agenda:
            L.append("- %s%s · %s (%s)" % (common.fmt_ddmm(a["when"]), " ⚠ vencido" if a["when"][:10] < today else (" · hoje" if a["when"][:10] == today else ""),
                                             _clean(a["text"], 100), a["id"]))
    else:
        L.append("Agenda vazia. Crie com /lembrete <quando> <texto>.")
    print("\n".join(L))


# --------------------------------------------------------------------------- --panel

def _port_open(port, timeout=0.3):
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect(("127.0.0.1", port))
        return True
    except Exception:
        return False
    finally:
        try:
            if s:
                s.close()
        except Exception:
            pass


def report_panel(as_json):
    url = "file://" + os.path.abspath(P["index_html"])
    age = None
    try:
        age = time.time() - os.path.getmtime(P["data_js"])
    except Exception:
        age = None
    serving = _port_open(PANEL_PORT)
    if as_json:
        print(json.dumps({"url": url, "index_exists": os.path.exists(P["index_html"]), "data_js_age_s": age,
                          "server": serving, "server_url": "http://127.0.0.1:%d/dashboard/" % PANEL_PORT}, ensure_ascii=False, indent=2))
        return
    L = []
    L.append("Painel do Gabriel: %s" % url)
    if not os.path.exists(P["index_html"]):
        L.append("O index.html ainda não existe: rode python3 motor/panel.py (ou espere o próximo refino).")
    if age is None:
        L.append("data.js ainda não foi gerado.")
    else:
        m = int(age // 60)
        L.append("Dados atualizados há %s%s." % ("%d min" % m if m < 120 else "%d h" % (m // 60),
                                                 " (organismo dormindo: abra uma sessão ou rode um refino)" if m > 30 else ""))
    L.append("Servidor local 127.0.0.1:%d: %s" % (PANEL_PORT, ("respondendo — http://127.0.0.1:%d/dashboard/" % PANEL_PORT) if serving
                                                   else "parado (opcional: bash dashboard/serve.sh liga; --stop desliga)"))
    L.append("Como abrir na lateral do VS Code: Cmd+Shift+P → 'Browser: Open Integrated Browser' → cole o endereço acima → Enter. A aba abre ao lado e atualiza sozinha.")
    L.append("Lembrete do Workspace Trust do VS Code: se aparecer a faixa 'Modo restrito / Confiar nos autores', clique em Confiar (Cmd+Shift+P → 'Workspaces: Gerenciar Workspace Trust'). Sem isso o navegador integrado devolve 403 para qualquer file://. É diferente do trust do Claude Code (esse já está ok).")
    print("\n".join(L))


# --------------------------------------------------------------------------- --origin

def report_origin(as_json):
    txt = common.read_text(P["pedido_original"])
    body = ""
    if txt:
        meta, body = common.read_frontmatter(txt)
        body = body or txt
    muts = common.read_jsonl(P["mutations"])
    first, last = muts[:10], muts[-10:] if len(muts) > 10 else []
    if as_json:
        print(json.dumps({"origin": body, "mutations_first": first, "mutations_last": last, "total": len(muts)}, ensure_ascii=False, indent=2))
        return
    L = []
    if body.strip():
        L.append(common.escape_at(body.strip()))
    else:
        L.append("O pedido original não está em memoria/origem/pedido-original.md (verify.py --repair recria se o CLAUDE.md ainda for o original).")
    L.append("")
    L.append("Linha do tempo (%d mutações registradas):" % len(muts))

    def _fmt(m):
        return "- %s · %s → %s · +%d novas, %d alteradas, %d superadas · %s%s" % (
            common.fmt_ddmm(m.get("ts") or "", hora=True), m.get("version_before", "?"), m.get("version_after", "?"),
            len(m.get("new") or []), len(m.get("changed") or []), len(m.get("superseded") or []), m.get("trigger") or "?",
            (" · " + _clean(m.get("reason"), 80)) if m.get("reason") else "")
    if not muts:
        L.append("- nenhuma ainda (a primeira nasce no primeiro refino com mudança)")
    for m in first:
        if isinstance(m, dict):
            L.append(_fmt(m))
    if last:
        L.append("- …")
        for m in last:
            if isinstance(m, dict):
                L.append(_fmt(m))
    print("\n".join(L))


# --------------------------------------------------------------------------- --suggestions

def suggestions():
    """6 regras em ordem de prioridade; devolve lista de {rule, text, ids}."""
    st = _state()
    health = st.get("health") or {}
    cfg = common.load_config()
    docs = _docs()
    out = []
    active = [d for d in docs if d["status"] == "active"]
    project_ids = set(d["id"] for d in active if d["collection"] == "projetos")
    project_tags = {d["id"]: set(d["tags"]) | set([d["id"]]) for d in active if d["collection"] == "projetos"}
    # 1. tag com ≥ 5 memórias sem project → criar projeto <tag>
    tag_count = {}
    for d in active:
        if d["collection"] not in ("memorias", "decisoes") or d.get("project"):
            continue
        for t in d["tags"]:
            if t in common.TYPE_LABELS or t in common.TYPES or t in project_ids or t in ("marcelo", "gabriel", "auto-memory"):
                continue
            tag_count[t] = tag_count.get(t, 0) + 1
    for t, n in sorted(tag_count.items(), key=lambda kv: (-kv[1], kv[0])):
        if n >= 5:
            out.append({"rule": "projeto-por-tag", "text": "criar projeto %s: %d memórias com essa tag não estão ligadas a nenhum projeto (python3 motor/remember.py --type project --id %s …)" % (t, n, t), "ids": [t]})
    # 2. órfãs → ligar <id> ao projeto mais próximo por tags
    graph = common.load_json(P["graph"], {}, script="report.py") or {}
    orphans = [o for o in (graph.get("orphans") or []) if isinstance(o, str)]
    by_id = dict((d["id"], d) for d in active)
    for oid in orphans[:5]:
        d = by_id.get(oid)
        best, best_n = None, 0
        if d:
            for pid, ptags in project_tags.items():
                n = len(set(d["tags"]) & ptags)
                if n > best_n:
                    best, best_n = pid, n
        if best:
            out.append({"rule": "orfa", "text": "ligar %s a %s (projeto mais próximo por tags)" % (oid, best), "ids": [oid, best]})
        else:
            out.append({"rule": "orfa", "text": "ligar %s a um projeto (está órfã: sem link nem project)" % oid, "ids": [oid]})
    # 3. similar_to → fundir via bibliotecário
    seen_pairs = set()
    for d in active:
        for s in d["similar_to"]:
            pair = tuple(sorted([d["id"], s]))
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            out.append({"rule": "similar", "text": "fundir %s e %s via bibliotecário (quase-duplicatas; python3 motor/correct.py --merge)" % pair, "ids": list(pair)})
    # 4. pendência > 14 dias → decidir ou concluir
    for p in (st.get("pending") or []):
        if not isinstance(p, dict):
            continue
        age = common.dias_desde(p.get("since") or "")
        if age is not None and age > 14:
            out.append({"rule": "pendencia-velha", "text": "decidir ou concluir: '%s' (%s) está aberta há %d dias" % (_clean(p.get("item"), 80), p.get("project") or "?", int(age)), "ids": [p.get("project")]})
    # 5. conhecimento antigo
    age = health.get("knowledge_age_days")
    if isinstance(age, (int, float)) and age > cfg.get("knowledge_max_age_days", 90):
        out.append({"rule": "conhecimento-antigo", "text": "o conhecimento do Claude Code tem %d dias: `/pesquisar claude code` (ou `/pesquisa-profunda`) atualiza" % int(age), "ids": []})
    # 6. INDICE > 120 linhas
    idx_lines = health.get("index_lines")
    if not isinstance(idx_lines, int):
        idx_lines = (common.read_text(P["indice"]) or "").count("\n")
    if idx_lines > 120:
        out.append({"rule": "indice-grande", "text": "fixar menos, arquivar mais: o INDICE.md tem %d linhas (o corte começa em %d)" % (idx_lines, cfg.get("index_max_lines", 150)), "ids": []})
    return out


def report_suggestions(as_json):
    s = suggestions()
    if as_json:
        print(json.dumps({"suggestions": s[:3], "all": s}, ensure_ascii=False, indent=2))
        return
    if not s:
        print("Nenhuma sugestão de evolução agora: sem órfãs, sem quase-duplicatas, sem pendência velha, conhecimento em dia e índice enxuto.")
        return
    print("Sugestões de evolução (%d encontradas, as 3 primeiras por prioridade):" % len(s))
    for i, item in enumerate(s[:3], 1):
        print("%d. %s" % (i, item["text"]))


# --------------------------------------------------------------------------- main

def main(argv):
    args = list(argv)
    as_json = "--json" in args
    handlers = {"--state": report_state, "--profile": report_profile, "--pending": report_pending, "--panel": report_panel,
                "--origin": report_origin, "--suggestions": report_suggestions}
    for a in args:
        if a in handlers:
            handlers[a](as_json)
            return
    print("uso: report.py --state | --profile | --pending | --panel | --origin | --suggestions [--json]")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BaseException as e:
        common.log_error("report.py", e)
        try:
            print("erro: report.py falhou (%s) — veja memoria/log/errors.jsonl" % type(e).__name__)
        except Exception:
            pass
    sys.exit(0)
