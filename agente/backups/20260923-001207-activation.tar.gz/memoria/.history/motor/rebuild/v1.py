#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
rebuild.py — refaz TODO derivado a partir dos .md + .jsonl (spec §11.12).

Backup dos derivados em memoria/.cache/derived-<ts>/; apaga INDICE.md, INDICE-completo.md, index.json,
graph.json, retrato.md, data.js, index.html, docs.json, offsets.json, signature.json; preserva de state.json só
version, generation, activated_at, imports, sessions_counted, warnings_shown (a versão nunca é recomputada de
trás para frente; sem state.json, vem da última linha de mutations.jsonl); recalcula contagens dos .jsonl;
roda refine.run("full"). Imprime um resumo. Sempre exit 0.
"""
import os, sys, json, time, shutil

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

SCRIPT = "rebuild.py"
P = common.P
DERIVED = ["indice", "indice_completo", "index_json", "graph", "retrato", "data_js", "index_html", "docs_json", "offsets_json", "signature_json"]
PRESERVE = ["version", "generation", "activated_at", "imports", "sessions_counted", "warnings_shown"]


def _version_from_mutations():
    rows = common.read_jsonl(P["mutations"])
    version, generation, first_ts = None, None, None
    for r in rows:
        if not isinstance(r, dict):
            continue
        if first_ts is None and r.get("ts"):
            first_ts = r["ts"]
        if r.get("version_after"):
            version = str(r["version_after"])
        if r.get("generation") is not None:
            generation = r.get("generation")
    return version, generation, first_ts


def _backup_derived(ts):
    dest = os.path.join(P["cache"], "derived-" + ts)
    saved = []
    for key in DERIVED + ["state"]:
        src = P[key]
        if os.path.exists(src):
            try:
                os.makedirs(dest, exist_ok=True)
                shutil.copy2(src, os.path.join(dest, os.path.basename(src)))
                saved.append(common.rel(src))
            except Exception as e:
                common.log_error(SCRIPT, e, extra={"file": common.rel(src)})
    return dest, saved


def _preserved_state():
    old = common.load_json(P["state"], None, script=SCRIPT)
    st = {}
    if isinstance(old, dict):
        for k in PRESERVE:
            if k in old:
                st[k] = old[k]
    else:
        if os.path.exists(P["state"]):
            try:
                os.replace(P["state"], P["state"] + ".corrupt-" + common.ts_compact())
            except Exception:
                pass
    version, generation, first_ts = _version_from_mutations()
    if not isinstance(st.get("version"), str) or not st.get("version"):
        st["version"] = version or "0.1.0"
    if not isinstance(st.get("generation"), int) or isinstance(st.get("generation"), bool):
        st["generation"] = generation if isinstance(generation, int) else 0
    if not st.get("activated_at"):
        st["activated_at"] = first_ts or common.now_iso()
    for k, default in (("imports", {}), ("sessions_counted", []), ("warnings_shown", {})):
        if not isinstance(st.get(k), type(default)):
            st[k] = default
    return st


def _jsonl_counts():
    sessions = set()
    for r in common.read_jsonl(P["sessions"]):
        if isinstance(r, dict) and r.get("event") == "start" and r.get("session") and not r.get("init_only"):
            sessions.add(common.sid8(r["session"]))
    return {"prompts": common.count_jsonl(P["prompts"]), "sessions": len(sessions), "events": common.count_jsonl(P["events"]),
            "turns": common.count_jsonl(P["turns"]), "recalls": common.count_jsonl(P["recalls"]), "mutations": common.count_jsonl(P["mutations"])}


def rebuild(quiet=False):
    t0 = time.monotonic()
    common.ensure_dirs()
    # espera o refinador soltar o lock (o refino completo abaixo pega o lock por conta própria)
    with common.exclusive_lock("refine", wait=5.0) as ok:
        if not ok:
            msg = "reconstrução adiada: refinador ocupado (tente de novo em instantes)"
            if not quiet:
                print(msg)
            return {"ok": False, "reason": "busy"}
    ts = common.ts_compact()
    backup_dir, saved = _backup_derived(ts)
    state = _preserved_state()
    before = common.load_json(P["state"], None, script=SCRIPT)
    before_counts = dict((before or {}).get("counts") or {}) if isinstance(before, dict) else {}
    removed = []
    for key in DERIVED:
        path = P[key]
        if os.path.exists(path):
            try:
                os.unlink(path)
                removed.append(common.rel(path))
            except Exception as e:
                common.log_error(SCRIPT, e, extra={"file": common.rel(path)})
    counts = _jsonl_counts()
    state["counts"] = {"prompts": counts["prompts"], "sessions": counts["sessions"]}
    state["health"] = {}
    common.save_json(P["state"], state)
    import refine
    result = None
    for attempt in range(3):
        result = refine.run("full", trigger="rebuild", quiet=True)
        if not result.get("skipped"):
            break
        time.sleep(0.5)
    st = refine.load_state()
    ms = int((time.monotonic() - t0) * 1000)
    out = {"ok": bool(result) and not result.get("skipped") and not result.get("error"), "ms": ms, "backup": common.rel(backup_dir),
           "removed": removed, "version": st.get("version"), "generation": st.get("generation"), "counts": st.get("counts"),
           "counts_before": before_counts, "jsonl": counts, "health": st.get("health"), "refine": {k: result.get(k) for k in ("ms", "partial", "docs", "skipped", "error")} if result else None}
    if not quiet:
        c = st.get("counts") or {}
        h = st.get("health") or {}
        print("Reconstrução dos derivados em %d ms" % ms)
        print("- backup dos derivados: %s (%d arquivos)" % (common.rel(backup_dir), len(saved)))
        print("- versão preservada: v%s · geração %s · ativado em %s" % (st.get("version"), st.get("generation"), str(st.get("activated_at") or "")[:10]))
        print("- contagens: %s memórias · %s decisões · %s projetos · %s conhecimento · %s compactações · %s relatórios"
              % (c.get("memories"), c.get("decisions"), c.get("projects"), c.get("knowledge"), c.get("compactions"), c.get("reports")))
        print("- jsonl: %s pedidos · %s sessões · %s eventos · %s turnos" % (counts["prompts"], counts["sessions"], counts["events"], counts["turns"]))
        print("- saúde: órfãs %s · duplicadas %s · similares %s · inválidas %s · índice %s linhas"
              % (h.get("orphans"), h.get("duplicates"), h.get("similar"), h.get("invalid"), h.get("index_lines")))
        if before_counts and before_counts.get("memories") is not None and before_counts.get("memories") != c.get("memories"):
            print("- atenção: memórias antes %s, agora %s" % (before_counts.get("memories"), c.get("memories")))
        if result and result.get("skipped"):
            print("- o refino completo não rodou (refinador ocupado): rode python3 motor/refine.py --full")
        elif result and result.get("partial"):
            print("- refino parcial: a manutenção completa o resto")
        else:
            print("- INDICE.md, INDICE-completo.md, graph.json, retrato.md, index.json e o painel foram refeitos")
    return out


def main(argv):
    r = rebuild(quiet=("--quiet" in argv or "--json" in argv))
    if "--json" in argv:
        print(json.dumps(r, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BaseException as e:
        common.log_error(SCRIPT, e)
    sys.exit(0)
