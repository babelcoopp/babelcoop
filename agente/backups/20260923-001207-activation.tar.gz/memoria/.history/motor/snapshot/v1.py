#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
snapshot.py create --reason <compact|daily|evolve|activation|manual> | --list | --restore <arquivo>  (spec §11.10)

- create: tar.gz de memoria/ (sem .cache/, .lixeira/, .restoring-*/) em ROOT/backups/AAAAMMDD-HHMMSS-<reason>.tar.gz
  + backups/last.json; rotação determinística; timeout interno 12 s (aborta e apaga o parcial).
- --list: lê backups/ e imprime em pt-BR.
- --restore <arquivo>: extrai em memoria/.restoring-<ts>/, move o atual para memoria/.lixeira/memoria-<ts>/,
  renomeia, roda refine.py --full. Nunca sobrescreve sem guardar; nunca toca em backups/.
Obedece BABEL_ROOT via common. Sempre exit 0.
"""
import os, sys, io, re, json, time, tarfile, shutil, datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

REASONS = ("compact", "daily", "evolve", "activation", "manual")
KEEP_FOREVER = ("evolve", "manual", "activation")
TIMEOUT = 12.0
NAME_RE = re.compile(r"^(\d{8})-(\d{6})-([a-z]+)\.tar\.gz$")


class _Deadline(Exception):
    pass


def _excluded(rel_path):
    parts = rel_path.split("/")
    for p in parts:
        if p in (".cache", ".lixeira") or p.startswith(".restoring-"):
            return True
    return False


def list_backups():
    """[{name, path, reason, ts (datetime), date, size}] ordenados por nome (= data)."""
    out = []
    bdir = common.P["backups"]
    try:
        names = sorted(os.listdir(bdir))
    except Exception:
        return out
    for n in names:
        m = NAME_RE.match(n)
        if not m:
            continue
        try:
            ts = datetime.datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
        except Exception:
            continue
        p = os.path.join(bdir, n)
        try:
            size = os.path.getsize(p)
        except Exception:
            size = 0
        out.append({"name": n, "path": p, "reason": m.group(3), "ts": ts, "date": m.group(1), "size": size})
    return out


def has_snapshot_today():
    today = common.now().strftime("%Y%m%d")
    return any(b["date"] == today for b in list_backups())


def prune():
    """Regra §11.10: mantém todos dos últimos 60 dias; antes disso, 1 por mês (o primeiro do mês);
    evolve/manual/activation nunca são podados. Devolve a lista dos nomes removidos."""
    removed = []
    cutoff = datetime.datetime.now() - datetime.timedelta(days=60)
    first_of_month = {}
    for b in list_backups():  # ordem crescente por nome = cronológica
        if b["reason"] in KEEP_FOREVER or b["ts"] >= cutoff:
            continue
        key = b["ts"].strftime("%Y%m")
        if key not in first_of_month:
            first_of_month[key] = b["name"]
            continue
        try:
            os.unlink(b["path"])
            removed.append(b["name"])
        except Exception as e:
            common.log_error("snapshot.py", e, extra={"file": b["name"]})
    return removed


def create(reason):
    reason = reason if reason in REASONS else "manual"
    t0 = time.monotonic()
    os.makedirs(common.P["backups"], exist_ok=True)
    mem = common.P["memoria"]
    if not os.path.isdir(mem):
        print("erro: memoria/ não existe")
        return None
    name = "%s-%s.tar.gz" % (common.ts_compact(), reason)
    target = os.path.join(common.P["backups"], name)
    tmp = target + ".tmp.%d" % os.getpid()
    deadline = t0 + TIMEOUT
    files = 0

    def _filter(ti):
        if time.monotonic() > deadline:
            raise _Deadline()
        rel_ = ti.name[len("memoria/"):] if ti.name.startswith("memoria/") else ti.name
        if rel_ and _excluded(rel_):
            return None
        base = os.path.basename(ti.name)
        if base.endswith(".tmp") or ".tmp." in base or base.endswith(".lock"):
            return None
        return ti

    try:
        with tarfile.open(tmp, "w:gz", compresslevel=6) as tar:
            tar.add(mem, arcname="memoria", filter=_filter)
        os.replace(tmp, target)
    except _Deadline:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        common.log_error("snapshot.py", TimeoutError("snapshot > %.0f s" % TIMEOUT), extra={"reason": reason})
        print("erro: snapshot passou de %.0f s e foi abortado" % TIMEOUT)
        return None
    except BaseException as e:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        raise
    try:
        size = os.path.getsize(target)
    except Exception:
        size = 0
    ms = int((time.monotonic() - t0) * 1000)
    try:
        with tarfile.open(target, "r:gz") as tar:
            files = len(tar.getmembers())
    except Exception:
        files = 0
    info = {"name": name, "reason": reason, "size": size, "ts": common.now_iso(), "files": files, "ms": ms,
            "path": common.rel(target)}
    try:
        common.save_json(os.path.join(common.P["backups"], "last.json"), info)
    except Exception as e:
        common.log_error("snapshot.py", e, extra={"file": "backups/last.json"})
    removed = prune()
    print("ok %s (%s, %d arquivos, %d ms)%s" % (common.rel(target), _fmt_size(size), files, ms,
                                                 (" · podados: %d" % len(removed)) if removed else ""))
    return target


def _fmt_size(n):
    try:
        n = float(n)
    except Exception:
        return "?"
    if n < 1024:
        return "%d B" % n
    if n < 1024 * 1024:
        return ("%.1f KB" % (n / 1024)).replace(".", ",")
    return ("%.1f MB" % (n / 1024 / 1024)).replace(".", ",")


def cmd_list(as_json=False):
    items = list_backups()
    if as_json:
        print(json.dumps([{"name": b["name"], "reason": b["reason"], "size": b["size"],
                           "ts": b["ts"].isoformat(timespec="seconds")} for b in items], ensure_ascii=False, indent=2))
        return
    if not items:
        print("Nenhum snapshot em %s ainda. Crie um com: python3 motor/snapshot.py create --reason manual" % common.rel(common.P["backups"]))
        return
    print("Snapshots em %s/ (%d):" % (common.rel(common.P["backups"]), len(items)))
    for b in reversed(items):
        print("- %s  %s  %s  (%s)" % (b["name"], b["ts"].strftime("%d/%m/%Y %H:%M"), b["reason"], _fmt_size(b["size"])))
    print("Restaurar: python3 motor/snapshot.py --restore <nome do arquivo>")


def restore(fname):
    t0 = time.monotonic()
    bdir = common.P["backups"]
    fname = os.path.basename(str(fname or ""))
    src = os.path.join(bdir, fname)
    if not fname or not os.path.isfile(src):
        print("erro: snapshot não encontrado em backups/: %s" % (fname or "(vazio)"))
        cmd_list()
        return False
    mem = common.P["memoria"]
    ts = common.ts_compact()
    staging = os.path.join(mem, ".restoring-" + ts)
    os.makedirs(staging, exist_ok=True)
    # 1. extrai ao lado (memoria/.restoring-<ts>/memoria/...)
    try:
        with tarfile.open(src, "r:gz") as tar:
            members = []
            for ti in tar.getmembers():
                n = ti.name
                if n.startswith("/") or ".." in n.split("/"):
                    continue
                if ti.issym() or ti.islnk():
                    continue
                members.append(ti)
            tar.extractall(staging, members=members)
    except Exception as e:
        common.log_error("snapshot.py", e, extra={"file": fname, "message": "falha ao extrair"})
        shutil.rmtree(staging, ignore_errors=True)
        print("erro: não consegui extrair %s (%s)" % (fname, type(e).__name__))
        return False
    extracted = os.path.join(staging, "memoria")
    if not os.path.isdir(extracted):
        shutil.rmtree(staging, ignore_errors=True)
        print("erro: o snapshot não contém a pasta memoria/")
        return False
    # 2. move o atual para .lixeira/memoria-<ts>/ (tudo menos .lixeira, .cache e .restoring-*)
    lix = os.path.join(common.P["lixeira"], "memoria-" + ts)
    os.makedirs(lix, exist_ok=True)
    moved = 0
    for n in sorted(os.listdir(mem)):
        if n in (".lixeira", ".cache") or n.startswith(".restoring-"):
            continue
        try:
            shutil.move(os.path.join(mem, n), os.path.join(lix, n))
            moved += 1
        except Exception as e:
            common.log_error("snapshot.py", e, extra={"file": n, "message": "falha ao mover para lixeira"})
    # 3. renomeia o extraído para o lugar
    restored = 0
    for n in sorted(os.listdir(extracted)):
        if n in (".lixeira", ".cache") or n.startswith(".restoring-"):
            continue
        try:
            shutil.move(os.path.join(extracted, n), os.path.join(mem, n))
            restored += 1
        except Exception as e:
            common.log_error("snapshot.py", e, extra={"file": n, "message": "falha ao restaurar"})
    shutil.rmtree(staging, ignore_errors=True)
    # 4. derivados: assinatura zerada para o refino completo refazer tudo
    for k in ("signature_json",):
        try:
            if os.path.exists(common.P[k]):
                os.unlink(common.P[k])
        except Exception:
            pass
    common.append_jsonl(common.P["events"], {"ts": common.now_iso(), "session": common.sid8(common.session_id_fallback()),
                                              "event": "restore", "summary": "snapshot %s restaurado; anterior em %s" % (fname, common.rel(lix))})
    rc, out, err = common.run_motor("refine.py", ["--full", "--trigger", "restore"], timeout=30)
    ms = int((time.monotonic() - t0) * 1000)
    print("ok restaurado %s (%d itens) em %d ms · o que havia antes ficou em %s · refino completo: %s"
          % (fname, restored, ms, common.rel(lix), "ok" if rc == 0 else "não rodou (rode python3 motor/refine.py --full)"))
    return True


def main(argv):
    args = list(argv)
    as_json = "--json" in args
    if "--list" in args:
        cmd_list(as_json)
        return
    if "--restore" in args:
        i = args.index("--restore")
        restore(args[i + 1] if i + 1 < len(args) else "")
        return
    if args and args[0] == "create":
        reason = "manual"
        if "--reason" in args:
            i = args.index("--reason")
            if i + 1 < len(args):
                reason = args[i + 1]
        create(reason)
        return
    print("uso: snapshot.py create --reason <compact|daily|evolve|activation|manual> | --list | --restore <arquivo>")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BaseException as e:
        common.log_error("snapshot.py", e)
        try:
            print("erro: %s" % type(e).__name__)
        except Exception:
            pass
    sys.exit(0)
