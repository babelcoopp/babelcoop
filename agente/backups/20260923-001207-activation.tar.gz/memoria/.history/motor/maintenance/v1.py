#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
maintenance.py  (spec §11.11) — manutenção assíncrona do SessionStart (só startup/resume) e do `claude -p --maintenance`.

Fase A (sob exclusive_lock("refine") não bloqueante; ocupado → sai sem tocar nada):
  rotação de events.jsonl > 20 MB e prompts.jsonl > 10 MB (rename sob flock do próprio arquivo + arquivo novo),
  poda de snapshots (regra §11.10), poda de turn-*.json > 7 dias, cópia dos scripts em .history/motor/ se ausente.
Fase B (lock liberado: cada script do motor pega o seu):
  conclui minor_pending (refine --state-only --count-sessions), refine --full se last_full_refinement > 24 h ou
  partial, snapshot diário pendente, verify --quiet.
Nunca imprime. Limite interno 60 s. Sempre exit 0.
"""
import os, sys, io, re, time, fcntl, shutil, glob

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

P = common.P
LIMIT = 60.0
EVENTS_MAX = 20 * 1024 * 1024
PROMPTS_MAX = 10 * 1024 * 1024
TURN_MAX_AGE = 7 * 86400
SCRIPTS = ["common.py", "verify.py", "wake.py", "recall.py", "refine.py", "remember.py", "correct.py", "agenda.py",
           "snapshot.py", "maintenance.py", "rebuild.py", "report.py", "panel.py", "statusline.py", "pause.py", "selftest.py"]


def _left(t0):
    return LIMIT - (time.monotonic() - t0)


def rotate(path, max_bytes, prefix):
    """Rename sob flock do próprio arquivo + arquivo novo vazio. Devolve o caminho do arquivo arquivado ou None."""
    try:
        if not os.path.exists(path) or os.path.getsize(path) <= max_bytes:
            return None
        os.makedirs(P["log_archive"], exist_ok=True)
        stamp = common.now().strftime("%Y%m")
        target = os.path.join(P["log_archive"], "%s-%s.jsonl" % (prefix, stamp))
        n = 1
        while os.path.exists(target):
            n += 1
            target = os.path.join(P["log_archive"], "%s-%s-%d.jsonl" % (prefix, stamp, n))
        with io.open(path, "a", encoding="utf-8") as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            try:
                os.rename(path, target)
                with io.open(path, "a", encoding="utf-8"):
                    pass
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        common.append_jsonl(P["events"], {"ts": common.now_iso(), "session": common.sid8(common.session_id_fallback()),
                                          "event": "rotation", "summary": "%s → %s" % (common.rel(path), common.rel(target))})
        return target
    except Exception as e:
        common.log_error("maintenance.py", e, extra={"file": common.rel(path), "message": "rotacao"})
        return None


def prune_turn_caches():
    now = time.time()
    cur = common.session_id_fallback()
    cur8 = common.sid8(cur) if cur else None
    for p in glob.glob(os.path.join(P["cache"], "turn-*.json")) + glob.glob(os.path.join(P["cache"], "turn-*.lock")) \
            + glob.glob(os.path.join(P["cache"], "heartbeat-*.txt")) + glob.glob(os.path.join(P["cache"], "setup-*.flag")):
        try:
            base = os.path.basename(p)
            if cur8 and cur8 in base:
                continue
            if now - os.path.getmtime(p) > TURN_MAX_AGE:
                os.unlink(p)
        except Exception:
            pass


def keep_motor_history():
    """Guarda em .history/motor/<script>/v1.py a cópia de cada script se ainda não há nenhuma versão."""
    try:
        os.makedirs(P["history_motor"], exist_ok=True)
        items = [(s, os.path.join(P["motor"], s)) for s in SCRIPTS] + [("hook.py", P["hook"])]
        for name, src in items:
            if not os.path.exists(src):
                continue
            d = os.path.join(P["history_motor"], name)
            if os.path.isdir(d) and any(f.startswith("v") for f in os.listdir(d)):
                continue
            os.makedirs(d, exist_ok=True)
            shutil.copy2(src, os.path.join(d, "v1.py"))
    except Exception as e:
        common.log_error("maintenance.py", e, extra={"message": "history motor"})


def phase_a(t0):
    rotated = rotate(P["events"], EVENTS_MAX, "events")
    rotate(P["prompts"], PROMPTS_MAX, "prompts")
    try:
        import snapshot
        snapshot.prune()
    except Exception as e:
        common.log_error("maintenance.py", e, extra={"message": "poda de snapshots"})
    prune_turn_caches()
    keep_motor_history()
    return rotated


def phase_b(t0):
    state = common.load_json(P["state"], {}, script="maintenance.py") or {}
    if not isinstance(state, dict):
        state = {}
    health = state.get("health") or {}
    cfg = common.load_config()
    has_refine = os.path.exists(os.path.join(P["motor"], "refine.py"))
    # minor pendente
    if has_refine and health.get("minor_pending") and _left(t0) > 5:
        common.run_motor("refine.py", ["--state-only", "--count-sessions", "--session", common.sid8(common.session_id_fallback()),
                                       "--trigger", "maintenance", "--quiet"], timeout=min(10.0, _left(t0) - 1))
    # refino completo
    need_full = False
    lf = state.get("last_full_refinement")
    d = common.dias_desde(lf) if lf else None
    if d is None or d * 24.0 > 24.0:
        need_full = True
    lr = state.get("last_refinement") if isinstance(state.get("last_refinement"), dict) else {}
    if lr.get("partial"):
        need_full = True
    if has_refine and need_full and _left(t0) > 8:
        common.run_motor("refine.py", ["--full", "--trigger", "maintenance", "--quiet"], timeout=min(25.0, _left(t0) - 2))
    # snapshot diário pendente
    if cfg.get("daily_snapshot") and _left(t0) > 14 and os.path.exists(os.path.join(P["motor"], "snapshot.py")):
        today_prefix = common.now().strftime("%Y%m%d")
        try:
            has_today = any(f.startswith(today_prefix) and f.endswith(".tar.gz") for f in os.listdir(P["backups"]))
        except Exception:
            has_today = False
        flag = os.path.join(P["cache"], "snapshot-pending.flag")
        if not has_today or os.path.exists(flag):
            rc, out, err = common.run_motor("snapshot.py", ["create", "--reason", "daily"], timeout=min(13.0, _left(t0) - 1))
            if rc == 0:
                try:
                    os.unlink(flag)
                except Exception:
                    pass
    # verificação silenciosa
    if _left(t0) > 4 and os.path.exists(os.path.join(P["motor"], "verify.py")):
        common.run_motor("verify.py", ["--repair", "--quiet"], timeout=min(5.0, _left(t0) - 1))


def main():
    t0 = time.monotonic()
    if common.paused():
        return
    common.ensure_dirs()
    with common.exclusive_lock("refine") as ok:
        if not ok:
            return
        phase_a(t0)
    phase_b(t0)


if __name__ == "__main__":
    try:
        main()
    except BaseException as e:
        common.log_error("maintenance.py", e)
    sys.exit(0)
