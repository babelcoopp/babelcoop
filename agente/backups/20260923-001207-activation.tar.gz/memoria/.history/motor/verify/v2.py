#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
verify.py [--repair] [--install [--dossier <dir>]] [--quiet] [--json]  (spec §11.3)

- Sem flags: só checa e imprime (pt-BR).
- --repair: cria tudo que falta (pastas, config, skill-heads, state 0.1.0, graph, INDICE mínimo, INDICE-completo,
  painel, perfil/marcelo.md mínimo, pedido-original.md condicional, current-session.json). Nunca apaga, nunca
  sobrescreve conteúdo. Alvo < 300 ms.
- --install: primeira ativação (idempotente): já ativado → mensagem + --repair; senão tudo + importa a memória
  automática + registra o dossiê + refine --full + snapshot activation + imprime o que nasceu.
- Valida sem consertar .claude/ (só avisa). Avisos vão para state.health.warnings via refine.py --state-only.
- --quiet só imprime se houver erro. --json imprime um objeto. Sempre exit 0.
"""
import os, sys, io, re, json, time, glob, shutil

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common

P = common.P
SKILL_DESC_MAX = 260
CLAUDE_MD_MAX_LINES = 180
EVENTS_MAX_MB = 20
MEMORY_MD_MAX_LINES = 180
MEMORY_MD_MAX_BYTES = 22 * 1024
DOSSIER_MAX_BYTES = 12 * 1024

WARNING_TEXTS = {
    "settings_invalido": "o .claude/settings.json não é JSON válido: nenhum hook está rodando",
    "settings_ausente": "não existe .claude/settings.json: os hooks do organismo não estão ligados",
    "hook_arquivo_ausente": "um hook do settings.json aponta para arquivo que não existe",
    "hook_fora_exec_form": "um hook do settings.json não está em exec form (command + args)",
    "hook_py_ausente": "falta .claude/hooks/hook.py; peça ao Gabriel para recriar com selftest.py antes",
    "frontmatter_invalido": "há memória com frontmatter inválido (veja errors.jsonl / /estado)",
    "indice_grande": "o INDICE.md passou dos limites (linhas ou tamanho); o refinador corta no próximo refino",
    "indice_arroba": "o INDICE.md tem @ solto fora de crase (viraria import); o refinador escapa no próximo refino",
    "claude_md_linhas": "o CLAUDE.md passou de %d linhas" % CLAUDE_MD_MAX_LINES,
    "claude_md_import": "o CLAUDE.md precisa ter exatamente 1 @import relativo (@memoria/INDICE.md) e nenhum outro @ solto",
    "skill_descricao_longa": "há skill com description acima de %d chars (custa contexto em todo turno)" % SKILL_DESC_MAX,
    "events_grande": "memoria/log/events.jsonl passou de %d MB; a manutenção vai rotacionar" % EVENTS_MAX_MB,
    "offsets_zerado": "offsets.json apontava além do prompts.jsonl e foi zerado",
    "conhecimento_antigo": "o que sei de configuração do Claude Code está velho; /pesquisar claude code atualiza",
    "auto_memory_ausente": "a pasta da memória automática não existe (git init ou CLAUDE_CONFIG_DIR mudaram a derivação?)",
    "iterm_cc_status": "o cc-status do iTerm2 aponta para pasta temporária (AppTranslocation) ou alvo inexistente; hooks globais podem falhar (veja LEIA-ME)",
    "hooks_desligados_global": "~/.claude/settings.json tem disableAllHooks: true — os hooks do organismo estão desligados",
    "block_reads_global": "~/.claude/settings.json tem permissions.blockReadsOutsideWorkingDirectories: true — a memória automática fica inacessível",
    "memory_md_grande": "o MEMORY.md da memória automática passou de %d linhas ou %d KB (só os primeiros 200/25 KB carregam)" % (MEMORY_MD_MAX_LINES, MEMORY_MD_MAX_BYTES // 1024),
    "pausa": "arquivo PAUSA presente: hooks e linha de status estão parados",
    "cwd_diferente": "o claude não foi aberto dentro de babel-os (cwd diferente da raiz do organismo)",
    "config_corrompido": "config.json estava corrompido e foi recriado com defaults (.corrupt-<ts> guardado)",
    "state_corrompido": "state.json estava corrompido: renomeado .corrupt-<ts> e refeito",
    "graph_corrompido": "graph.json estava corrompido: renomeado .corrupt-<ts> e refeito",
    "template_ausente": "dashboard/template.html sumiu: painel gerado com template mínimo",
    "motor_incompleto": "faltam scripts em motor/: rode /evoluir reparar",
    "claude_dir_incompleto": "falta algo em .claude/ (skills, agents, rules ou hooks); peça ao Gabriel para recriar com selftest.py antes",
    "claude_md_ausente": "não existe CLAUDE.md na raiz",
}

MOTOR_SCRIPTS = ["common.py", "verify.py", "wake.py", "recall.py", "refine.py", "remember.py", "correct.py", "agenda.py",
                 "snapshot.py", "maintenance.py", "rebuild.py", "report.py", "panel.py", "statusline.py", "pause.py", "selftest.py"]


class Report(object):
    def __init__(self):
        self.created = []
        self.warnings = []   # códigos
        self.details = []    # textos pt-BR (avisos com detalhe)
        self.errors = []
        self.ok = []
        self.t0 = time.monotonic()

    def warn(self, code, detail=None):
        if code not in self.warnings:
            self.warnings.append(code)
        txt = WARNING_TEXTS.get(code, code)
        if detail:
            txt = "%s — %s" % (txt, detail)
        if txt not in self.details:
            self.details.append(txt)

    def ms(self):
        return int((time.monotonic() - self.t0) * 1000)


# --------------------------------------------------------------------------- helpers

def _has_docs():
    for col in common.COLLECTIONS:
        base = P[col]
        if not os.path.isdir(base):
            continue
        for dp, dn, fn in os.walk(base):
            dn[:] = [d for d in dn if not d.startswith(".")]
            for f in fn:
                if f.endswith(".md") and f != "retrato.md" and not f.upper().startswith("INDICE"):
                    return True
    return False


def _last_version_from_mutations():
    try:
        for m in reversed(common.read_jsonl(P["mutations"], last=50)):
            v = m.get("version_after")
            if isinstance(v, str) and re.fullmatch(r"\d+\.\d+\.\d+", v):
                return v
    except Exception:
        pass
    return None


def state_skeleton(version=None):
    now = common.now_iso()
    return {
        "version": version or "0.1.0", "generation": 0, "activated_at": now,
        "counts": {"memories": 0, "decisions": 0, "projects": 0, "knowledge": 0, "compactions": 0, "reports": 0,
                   "prompts": 0, "sessions": 0, "tags": 0},
        "by_type": {}, "last_session": None, "counts_at_session_start": None,
        "last_refinement": None, "last_full_refinement": None, "last_snapshot": None,
        "sessions_counted": [],
        "profile": {"summary": "", "learned_today": [], "want_to_learn": []},
        "pending": [], "agenda_open": 0, "agenda_overdue": 0,
        "health": {"orphans": 0, "duplicates": 0, "similar": 0, "invalid": 0, "index_lines": 0, "index_bytes": 0,
                   "index_max_lines": common.CONFIG_DEFAULTS["index_max_lines"], "log_mb": 0.0,
                   "auto_memory_lines": 0, "auto_memory_bytes": 0, "knowledge_age_days": None,
                   "minor_pending": False, "warnings": []},
        "warnings_shown": {"iterm_cc_status": None, "knowledge_age": None},
        "imports": {},
        "context_cost": {"claude_md_lines": 0, "index_lines": 0, "rules_without_paths": 0, "skill_descriptions_chars": 0,
                         "skill_description_max_chars": SKILL_DESC_MAX, "tokens_per_session_est": 0, "tokens_per_turn_est": 0},
        "paused": common.paused(),
    }


def _log_corrupt(path):
    """1 linha em errors.jsonl com o nome do arquivo (§3.5 / §16.1) — nunca lança."""
    name = common.rel(path) or os.path.basename(path)
    exc = None
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if not isinstance(obj, dict):
            exc = TypeError("JSON nao e objeto: " + type(obj).__name__)
    except Exception as e:
        exc = e
    common.log_error("verify.py", exc or ValueError("JSON ilegivel"), extra={"file": name, "message": "arquivo ilegivel"})


def _corrupt_rename(path):
    _log_corrupt(path)
    try:
        os.replace(path, path + ".corrupt-" + common.ts_compact())
        return True
    except Exception as e:
        common.log_error("verify.py", e, extra={"file": common.rel(path) or os.path.basename(path)})
        return False


def _json_status(path):
    """'absent' | 'ok' | 'corrupt'"""
    if not os.path.exists(path):
        return "absent"
    try:
        with io.open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        return "ok" if isinstance(obj, dict) else "corrupt"
    except Exception:
        return "corrupt"


def skill_heads():
    heads = {}
    for sk in sorted(glob.glob(os.path.join(P["skills"], "*", "SKILL.md"))):
        txt = common.read_text(sk)
        if txt is None:
            continue
        meta, body = common.read_frontmatter(txt)
        name = (meta or {}).get("name") or os.path.basename(os.path.dirname(sk))
        first = ""
        for line in (body or "").split("\n"):
            if line.strip():
                first = line.strip()
                break
        heads[str(name)] = first[:200]
    return heads


def minimal_index(state):
    v = (state or {}).get("version") or "0.1.0"
    g = (state or {}).get("generation") or 0
    return ("<!-- gerado por motor/verify.py em %s — não edite; use /lembrar, /esquecer e /evoluir -->\n"
            "# Índice vivo do Gabriel — v%s · geração %s · 0 memórias ativas · 0 projetos · 0 pendências\n"
            "_Índice ainda vazio: o próximo refino (Stop ou /evoluir) preenche. `/consultar <tema>` acha tudo._\n" % (common.now_iso(), v, g))


def minimal_profile():
    meta = {"id": "marcelo", "type": "profile", "title": "Marcelo Rocha (Maximus): fundador do Reino, líder de grupos, não-dev",
            "summary": "Marcelo Rocha (Maximus), fundador do Reino (network + IA Babel); lidera grandes grupos; não-dev; quer tudo pronto, em português, estilo WhatsApp; Diego é sócio (não confundir).",
            "tags": ["marcelo", "perfil", "reino"], "confidence": 0.9, "status": "active", "source": "marcelo-said",
            "pinned": True, "created": common.now_iso(), "updated": common.now_iso(), "version": 1}
    body = ("# Marcelo Rocha (Marcelo Maximus) — o que o Gabriel sabe\n\n"
            "- Fundador do Reino, clube de network entre empresários com a IA Babel; Diego é sócio (não confundir os dois).\n"
            "- Lidera grandes grupos de pessoas; tudo que o Gabriel entrega tem que deixá-lo liderando melhor.\n"
            "- Não é desenvolvedor: quer resultado pronto, em português do Brasil, estilo WhatsApp, e ver antes de ler.\n")
    meta["hash"] = common.body_hash(body)
    return common.write_frontmatter(meta, body)


def _claude_md_is_original(txt):
    """O CLAUDE.md ainda é o original do Marcelo se não tem a linha de import do índice."""
    for line in (txt or "").split("\n"):
        if line.strip() == "@memoria/INDICE.md":
            return False
    return True


def pedido_original_from(txt):
    body = ("# Pedido original do Marcelo\n\n"
            "> Texto integral do `CLAUDE.md` escrito pelo Marcelo, guardado intacto antes da primeira ativação do organismo. "
            "Nada aqui é editado; é a fonte da intenção.\n\n```text\n" + (txt or "").rstrip("\n") + "\n```\n")
    meta = {"id": "pedido-original", "type": "reference", "title": "Pedido original do Marcelo (CLAUDE.md de nascimento do Gabriel)",
            "tags": ["gabriel", "marcelo", "origem", "pedido"], "confidence": 1.0, "status": "active", "source": "marcelo-said",
            "pinned": True, "created": common.now_iso(), "updated": common.now_iso(), "version": 1, "hash": common.body_hash(body)}
    return common.write_frontmatter(meta, body)


MINI_TEMPLATE = ("<!doctype html><html lang=\"pt-BR\"><head><meta charset=\"utf-8\"><title>Gabriel — painel</title>"
                 "<style>body{background:#030817;color:#e8ecf8;font-family:Inter,system-ui,sans-serif;padding:24px}"
                 "h1{color:#f5c76a}code{color:#3fe3ff}</style></head><body><h1>Gabriel — painel mínimo</h1>"
                 "<p>O template do painel (dashboard/template.html) não foi encontrado. Os dados estão em <code>data.js</code>.</p>"
                 "<pre id=\"out\"></pre><script id=\"babel-data\">/*__BABEL_DADOS__*/</script>"
                 "<script>try{document.getElementById('out').textContent=JSON.stringify(window.BABEL||{},null,2).slice(0,4000)}catch(e){}</script>"
                 "</body></html>")


def panel_fallback(state, rep):
    """Painel mínimo quando panel.py não está disponível."""
    obj = {"generatedAt": common.now_iso(), "identity": {"name": "Gabriel", "version": (state or {}).get("version"),
                                                        "generation": (state or {}).get("generation"),
                                                        "since": ((state or {}).get("activated_at") or "")[:10]},
           "state": state or {}, "warnings": [{"level": "warn", "text": WARNING_TEXTS.get(w, w)} for w in rep.warnings]}
    js = json.dumps(obj, ensure_ascii=False).replace("</script", "<\\/script").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    line = "window.BABEL = %s;" % js
    tpl = common.read_text(P["template"])
    if tpl is None or "/*__BABEL_DADOS__*/" not in tpl:
        tpl = MINI_TEMPLATE
        rep.warn("template_ausente")
    common.write_atomic(P["data_js"], line + "\n")
    common.write_atomic(P["index_html"], tpl.replace("/*__BABEL_DADOS__*/", line))


# --------------------------------------------------------------------------- reparo

def repair(rep, install=False):
    common.ensure_dirs()
    # config.json
    st = _json_status(P["config"])
    if st == "absent":
        common.save_json(P["config"], common.CONFIG_DEFAULTS)
        rep.created.append(common.rel(P["config"]))
    elif st == "corrupt":
        common.load_config()  # renomeia .corrupt-<ts> e recria
        rep.warn("config_corrompido")
        rep.created.append(common.rel(P["config"]))
    # skill-heads.json
    try:
        heads = skill_heads()
        if not os.path.exists(P["skill_heads"]):
            rep.created.append(common.rel(P["skill_heads"]))
        common.write_if_changed(P["skill_heads"], json.dumps(heads, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    except Exception as e:
        common.log_error("verify.py", e, extra={"file": "skill-heads.json"})
    # state.json / graph.json — detecta a corrupção dos DOIS antes de qualquer rebuild
    # (rebuild.py regrava graph.json; sem isto um graph.json corrompido junto com o
    #  state.json sumiria sem .corrupt-<ts> e sem linha em errors.jsonl)
    st = _json_status(P["state"])
    gst = _json_status(P["graph"])
    if gst == "corrupt":
        _corrupt_rename(P["graph"])
        rep.warn("graph_corrompido")
        gst = "absent"
    state = None
    if st == "corrupt":
        _corrupt_rename(P["state"])
        rep.warn("state_corrompido")
        st = "absent"
    if st == "absent":
        state = state_skeleton(_last_version_from_mutations())
        common.save_json(P["state"], state)
        rep.created.append(common.rel(P["state"]))
        if not install and _has_docs() and os.path.exists(os.path.join(P["motor"], "rebuild.py")):
            rc, out, err = common.run_motor("rebuild.py", [], timeout=20)
            if rc == 0:
                rep.ok.append("state.json refeito por rebuild.py")
            state = common.load_json(P["state"], state, script="verify.py") or state
    else:
        state = common.load_json(P["state"], {}, script="verify.py") or {}
        if not state.get("activated_at"):
            def _fix(o):
                o.setdefault("activated_at", common.now_iso())
                o.setdefault("version", "0.1.0")
            common.update_json_locked(P["state"], _fix, script="verify.py")
    # graph.json (pode já ter sido refeito pelo rebuild.py acima)
    if gst == "absent" and not os.path.exists(P["graph"]):
        common.save_json(P["graph"], {"generated": common.now_iso(), "nodes": [], "edges": [], "orphans": []})
        rep.created.append(common.rel(P["graph"]))
    # INDICE.md mínimo (3 linhas) e INDICE-completo.md
    if not os.path.exists(P["indice"]):
        common.write_atomic(P["indice"], minimal_index(state))
        rep.created.append(common.rel(P["indice"]))
    if not os.path.exists(P["indice_completo"]):
        common.write_atomic(P["indice_completo"], minimal_index(state))
        rep.created.append(common.rel(P["indice_completo"]))
    # perfil/marcelo.md mínimo
    if not os.path.exists(P["perfil_marcelo"]):
        common.write_atomic(P["perfil_marcelo"], minimal_profile())
        rep.created.append(common.rel(P["perfil_marcelo"]))
    # origem/pedido-original.md só se o CLAUDE.md ainda for o original
    if not os.path.exists(P["pedido_original"]):
        txt = common.read_text(P["claude_md"])
        if txt and _claude_md_is_original(txt):
            common.write_atomic(P["pedido_original"], pedido_original_from(txt))
            rep.created.append(common.rel(P["pedido_original"]))
    # current-session.json
    if not os.path.exists(P["current_session"]):
        common.save_json(P["current_session"], {"session": common.sid8(os.environ.get("CLAUDE_CODE_SESSION_ID") or "unknown"),
                                                "ts": common.now_iso()})
        rep.created.append(common.rel(P["current_session"]))
    # painel
    if not os.path.exists(P["index_html"]) or not os.path.exists(P["data_js"]):
        done = False
        if os.path.exists(os.path.join(P["motor"], "panel.py")):
            rc, out, err = common.run_motor("panel.py", [], timeout=3)
            done = rc == 0 and os.path.exists(P["index_html"]) and os.path.exists(P["data_js"])
        if not done:
            panel_fallback(state, rep)
        rep.created.append("dashboard/index.html + data.js")
    return state


# --------------------------------------------------------------------------- validação

def _settings_check(rep):
    if not os.path.exists(P["settings"]):
        rep.warn("settings_ausente")
        return
    try:
        with io.open(P["settings"], "r", encoding="utf-8") as f:
            s = json.load(f)
    except Exception as e:
        rep.warn("settings_invalido", str(e)[:80])
        return
    hooks = s.get("hooks") if isinstance(s, dict) else None
    if not isinstance(hooks, dict):
        return
    for ev, groups in hooks.items():
        if not isinstance(groups, list):
            continue
        for g in groups:
            for h in (g.get("hooks") if isinstance(g, dict) else None) or []:
                if not isinstance(h, dict) or h.get("type") != "command":
                    continue
                cmd = h.get("command")
                args = h.get("args")
                if not isinstance(args, list) or not isinstance(cmd, str):
                    rep.warn("hook_fora_exec_form", ev)
                    continue
                for a in args:
                    if not isinstance(a, str) or not a.endswith(".py"):
                        continue
                    pth = a.replace("${CLAUDE_PROJECT_DIR}", common.ROOT).replace("$CLAUDE_PROJECT_DIR", common.ROOT)
                    if not os.path.isabs(pth):
                        pth = os.path.join(common.ROOT, pth)
                    if not os.path.exists(pth):
                        rep.warn("hook_arquivo_ausente", "%s: %s" % (ev, a))


def _frontmatters_check(rep):
    bad = []
    for path in common.list_docs():
        txt = common.read_text(path)
        if txt is None:
            bad.append(common.doc_id_from_path(path)); continue
        meta, body = common.read_frontmatter(txt)
        if meta is None or not isinstance(meta, dict) or not meta.get("id") or not meta.get("type"):
            bad.append(common.doc_id_from_path(path))
    if bad:
        rep.warn("frontmatter_invalido", ", ".join(bad[:5]) + (" …" if len(bad) > 5 else ""))
    return bad


def _index_check(rep, cfg):
    txt = common.read_text(P["indice"])
    if txt is None:
        return
    lines = txt.count("\n") + (0 if txt.endswith("\n") else 1)
    if lines > cfg.get("index_max_lines", 150) or len(txt) > cfg.get("index_max_chars", 12000):
        rep.warn("indice_grande", "%d linhas, %d chars" % (lines, len(txt)))
    if common.bare_at_lines(txt):
        rep.warn("indice_arroba", "linhas %s" % common.bare_at_lines(txt)[:5])


def _claude_md_check(rep):
    txt = common.read_text(P["claude_md"])
    if txt is None:
        rep.warn("claude_md_ausente")
        return
    n = txt.count("\n") + (0 if txt.endswith("\n") else 1)
    if n > CLAUDE_MD_MAX_LINES:
        rep.warn("claude_md_linhas", "%d linhas" % n)
    # conta tokens @ soltos fora de crase/fence
    imports = []
    others = 0
    in_fence = False
    for line in txt.split("\n"):
        s = line.strip()
        if s.startswith("```") or s.startswith("~~~"):
            in_fence = not in_fence
            continue
        if in_fence or "@" not in line:
            continue
        parts = line.split("`")
        balanced = len(parts) % 2 == 1
        for i, part in enumerate(parts):
            if balanced and i % 2 == 1:
                continue
            for m in re.finditer(r"(?:^|\s)@(\S+)", part):
                tok = m.group(1)
                if tok.startswith("/") or tok.startswith("~"):
                    others += 1          # caminho absoluto/externo: dispara o diálogo de import externo
                elif re.match(r"^[\w.\-/]+$", tok) and ("/" in tok or tok.endswith(".md")):
                    imports.append(tok)  # @import relativo (ex.: @memoria/INDICE.md)
                else:
                    others += 1          # handle (@diego), e-mail ou outro @ solto
            # @ colado em palavra (e-mail/handle) fora de crase
            if re.search(r"[^\s`]@[^\s`]", part):
                others += 1
    if len(imports) != 1 or others:
        rep.warn("claude_md_import", "imports: %s, outros @ soltos: %d" % (imports or "nenhum", others))


def _skills_check(rep):
    total = 0
    for sk in sorted(glob.glob(os.path.join(P["skills"], "*", "SKILL.md"))):
        txt = common.read_text(sk)
        if not txt:
            continue
        meta, body = common.read_frontmatter(txt)
        if not isinstance(meta, dict):
            continue
        if meta.get("disable-model-invocation") is True:
            continue
        desc = str(meta.get("description") or "")
        total += len(desc)
        if len(desc) > SKILL_DESC_MAX:
            rep.warn("skill_descricao_longa", "%s (%d chars)" % (meta.get("name") or os.path.basename(os.path.dirname(sk)), len(desc)))
    return total


def _logs_check(rep):
    try:
        mb = os.path.getsize(P["events"]) / (1024.0 * 1024.0)
        if mb > EVENTS_MAX_MB:
            rep.warn("events_grande", "%.1f MB" % mb)
    except Exception:
        pass
    # offsets.json ≤ tamanho de prompts.jsonl (senão zera)
    try:
        if os.path.exists(P["offsets_json"]):
            size = os.path.getsize(P["prompts"]) if os.path.exists(P["prompts"]) else 0
            off = common.load_json(P["offsets_json"], None, script="verify.py")
            changed = False
            if isinstance(off, dict):
                for k, v in list(off.items()):
                    if isinstance(v, (int, float)) and not isinstance(v, bool) and v > size:
                        off[k] = 0; changed = True
            elif isinstance(off, (int, float)) and off > size:
                off = {"offset": 0}; changed = True
            if changed:
                common.save_json(P["offsets_json"], off)
                rep.warn("offsets_zerado")
    except Exception as e:
        common.log_error("verify.py", e, extra={"file": "offsets.json"})


def knowledge_age_days():
    """Dias desde o `updated` (ou mtime) mais novo em conhecimento/claude-code/; None se vazio."""
    base = os.path.join(P["conhecimento"], "claude-code")
    newest = None
    try:
        for f in os.listdir(base):
            if not f.endswith(".md"):
                continue
            p = os.path.join(base, f)
            d = None
            txt = common.read_text(p)
            if txt:
                meta, _ = common.read_frontmatter(txt)
                if isinstance(meta, dict):
                    d = common.parse_iso(meta.get("updated") or meta.get("created") or "")
            if d is None:
                try:
                    import datetime
                    d = datetime.datetime.fromtimestamp(os.path.getmtime(p)).astimezone()
                except Exception:
                    d = None
            if d and (newest is None or d > newest):
                newest = d
    except Exception:
        return None
    if newest is None:
        return None
    return max(0, (common.now() - newest).total_seconds() / 86400.0)


def _knowledge_check(rep, cfg):
    age = knowledge_age_days()
    if age is not None and age > cfg.get("knowledge_max_age_days", 90):
        rep.warn("conhecimento_antigo", "%d dias" % int(age))
    return age


def _auto_memory_check(rep):
    am = P["auto_memory"]
    if not os.path.isdir(am):
        rep.warn("auto_memory_ausente", common.truncate(am, 80))
        return
    mm = os.path.join(am, "MEMORY.md")
    txt = common.read_text(mm)
    if txt is not None:
        lines = txt.count("\n") + (0 if txt.endswith("\n") else 1)
        b = len(txt.encode("utf-8"))
        if lines > MEMORY_MD_MAX_LINES or b > MEMORY_MD_MAX_BYTES:
            rep.warn("memory_md_grande", "%d linhas, %d bytes" % (lines, b))


def _iterm_check(rep):
    link = os.path.join(os.path.expanduser("~"), ".config", "iterm2", "cc-status")
    try:
        if os.path.islink(link):
            target = os.readlink(link)
            if "AppTranslocation" in target or not os.path.exists(os.path.realpath(link)):
                rep.warn("iterm_cc_status")
    except Exception:
        pass


def _user_settings_check(rep):
    config_dir = os.environ.get("CLAUDE_CONFIG_DIR") or os.path.join(os.path.expanduser("~"), ".claude")
    p = os.path.join(config_dir, "settings.json")
    if not os.path.exists(p):
        return
    try:
        with io.open(p, "r", encoding="utf-8") as f:
            s = json.load(f)
    except Exception:
        return
    if not isinstance(s, dict):
        return
    if s.get("disableAllHooks") is True:
        rep.warn("hooks_desligados_global")
    perm = s.get("permissions") if isinstance(s.get("permissions"), dict) else {}
    if perm.get("blockReadsOutsideWorkingDirectories") is True:
        rep.warn("block_reads_global")


def _claude_dir_check(rep):
    missing = []
    if not os.path.exists(P["hook"]):
        missing.append("hooks/hook.py")
    for k in ("skills", "agents", "rules"):
        if not os.path.isdir(P[k]):
            missing.append(k + "/")
    if missing:
        rep.warn("claude_dir_incompleto", ", ".join(missing))
    miss_motor = [s for s in MOTOR_SCRIPTS if not os.path.exists(os.path.join(P["motor"], s))]
    if miss_motor:
        rep.warn("motor_incompleto", ", ".join(miss_motor))


def validate(rep, cfg):
    _settings_check(rep)
    _claude_dir_check(rep)
    for k in ("state", "graph"):
        if _json_status(P[k]) == "corrupt":
            _log_corrupt(P[k])
            rep.errors.append("%s corrompido (rode --repair)" % common.rel(P[k]))
    _frontmatters_check(rep)
    _index_check(rep, cfg)
    _claude_md_check(rep)
    _skills_check(rep)
    _logs_check(rep)
    _knowledge_check(rep, cfg)
    _auto_memory_check(rep)
    _iterm_check(rep)
    _user_settings_check(rep)
    if common.paused():
        rep.warn("pausa")
    try:
        cwd = os.path.realpath(os.getcwd())
        if cwd not in (os.path.realpath(common.ROOT), os.path.realpath(common.ROOT_REAL)):
            rep.warn("cwd_diferente", common.truncate(cwd, 60))
    except Exception:
        pass
    if cfg.get("_warnings"):
        for w in cfg["_warnings"]:
            rep.warn(w.split(":")[0] if w.startswith("config_") else w)


def persist_warnings(rep):
    """Grava os avisos: .cache/verify.json (fonte para o refinador) + refine.py --state-only; se o refinador não
    incorporou, mescla em state.health.warnings sob o lock lateral (sem apagar avisos do próprio refinador)."""
    try:
        common.save_json(os.path.join(P["cache"], "verify.json"),
                         {"ts": common.now_iso(), "warnings": rep.warnings, "details": rep.details, "errors": rep.errors})
    except Exception as e:
        common.log_error("verify.py", e, extra={"file": "verify.json"})
    if not os.path.exists(P["state"]):
        return
    rc = None
    if os.path.exists(os.path.join(P["motor"], "refine.py")):
        rc, out, err = common.run_motor("refine.py", ["--state-only", "--trigger", "verify", "--quiet"], timeout=2.5)
    state = common.load_json(P["state"], {}, script="verify.py") or {}
    have = set(((state.get("health") or {}).get("warnings") or []))
    mine = set(rep.warnings)
    if mine <= have and rc == 0:
        return

    def _merge(o):
        h = o.get("health")
        if not isinstance(h, dict):
            h = {}
            o["health"] = h
        cur = [w for w in (h.get("warnings") or []) if isinstance(w, str)]
        for w in rep.warnings:
            if w not in cur:
                cur.append(w)
        h["warnings"] = cur
        o["paused"] = common.paused()
    common.update_json_locked(P["state"], _merge, script="verify.py")


# --------------------------------------------------------------------------- instalação

AUTO_TYPE_MAP = {"user": "profile", "feedback": "preference", "project": "fact", "reference": "reference"}


def _auto_meta_type(txt):
    """Lê `type:` (inclusive aninhado em metadata:) do frontmatter da memória automática."""
    m = re.search(r"^\s*type:\s*([A-Za-z_-]+)\s*$", txt.split("\n---", 1)[0] if txt.startswith("---") else "", re.M)
    return m.group(1).strip().lower() if m else "fact"


def import_auto_memory(rep, state):
    am = P["auto_memory"]
    born = []
    if not os.path.isdir(am):
        rep.warn("auto_memory_ausente", common.truncate(am, 80))
        return born
    today = common.today()
    files = [f for f in sorted(os.listdir(am)) if f.endswith(".md") and f != "MEMORY.md"]
    # mapa [[nome]] → id novo (perfil-marcelo → marcelo; os demais → AAAA-MM-DD-slug)
    link_map = {}
    for f in files:
        stem = os.path.splitext(f)[0]
        link_map[stem] = "marcelo" if stem == "perfil-marcelo" else "%s-%s" % (today, common.slug(stem, 48))

    def _relink(text):
        return re.sub(r"\[\[([^\]]+)\]\]", lambda m: "[[%s]]" % link_map.get(m.group(1).strip(), m.group(1).strip()), text)

    for f in files:
        txt = common.read_text(os.path.join(am, f))
        if not txt:
            continue
        meta, body = common.read_frontmatter(txt)
        meta = meta if isinstance(meta, dict) else {}
        body = common.escape_at(common.redact(_relink((body or "").strip())))
        if not body or common.looks_secret(body):
            continue
        name = str(meta.get("name") or os.path.splitext(f)[0])
        title = common.truncate(str(meta.get("description") or name).replace('"', "'"), 90)
        if f == "perfil-marcelo.md" or name == "perfil-marcelo":
            cur = common.read_text(P["perfil_marcelo"])
            marker = "## Importado da memória automática"
            if cur is None:
                common.write_atomic(P["perfil_marcelo"], minimal_profile())
                cur = common.read_text(P["perfil_marcelo"]) or ""
            if marker not in cur:
                pm, pb = common.read_frontmatter(cur)
                pm = pm if isinstance(pm, dict) else {}
                pb = (pb or "").rstrip("\n") + "\n\n%s (%s)\n%s\n" % (marker, common.fmt_ddmm(common.now_iso()), body)
                pm["hash"] = common.body_hash(pb)
                pm["updated"] = common.now_iso()
                try:
                    pm["version"] = int(pm.get("version") or 1) + 1
                except Exception:
                    pm["version"] = 2
                common.history_snapshot("marcelo", cur, pm["version"] - 1)
                common.write_atomic(P["perfil_marcelo"], common.write_frontmatter(pm, pb))
                born.append(common.rel(P["perfil_marcelo"]) + " (alimentado)")
            continue
        mtype = AUTO_TYPE_MAP.get(_auto_meta_type(txt), "fact")
        doc_id = link_map.get(os.path.splitext(f)[0]) or "%s-%s" % (today, common.slug(name, 48))
        path = os.path.join(P["memorias"], doc_id + ".md")
        if os.path.exists(path):
            continue
        tags = sorted(set(["auto-memory", mtype] + [t for t in common.slug(name).split("-") if len(t) > 3][:3]))
        fm = {"id": doc_id, "type": mtype, "title": common.escape_at(title), "tags": tags, "confidence": 0.8,
              "status": "active", "source": "auto-memory", "pinned": False, "created": common.now_iso(),
              "updated": common.now_iso(), "version": 1, "hash": common.body_hash(body)}
        common.write_atomic(path, common.write_frontmatter(fm, body))
        born.append(common.rel(path))
    return born


def import_dossier(rep, dossier_dir):
    dest = os.path.join(P["conhecimento"], "claude-code")
    os.makedirs(dest, exist_ok=True)
    copied, refused = [], []
    if dossier_dir:
        for f in sorted(glob.glob(os.path.join(dossier_dir, "*.md"))):
            try:
                size = os.path.getsize(f)
            except Exception:
                continue
            if size > DOSSIER_MAX_BYTES:
                refused.append("%s (%d KB > 12 KB)" % (os.path.basename(f), size // 1024)); continue
            txt = common.read_text(f)
            meta, body = common.read_frontmatter(txt or "")
            if not isinstance(meta, dict) or not meta.get("id") or meta.get("type") != "knowledge" or not meta.get("title"):
                refused.append("%s (frontmatter inválido: precisa de id, type: knowledge, title)" % os.path.basename(f)); continue
            target = os.path.join(dest, os.path.basename(f))
            if not os.path.exists(target):
                common.write_atomic(target, txt)
                copied.append(common.rel(target))
    present = [f for f in os.listdir(dest) if f.endswith(".md")] if os.path.isdir(dest) else []
    for r in refused:
        rep.details.append("dossiê recusado: " + r)
    return copied, len(present)


def install(rep, dossier_dir):
    if os.path.exists(P["state"]) and _json_status(P["state"]) == "ok":
        st = common.load_json(P["state"], {}, script="verify.py") or {}
        print("já ativado v%s em %s — caindo em --repair" % (st.get("version", "?"), common.fmt_ddmm(st.get("activated_at") or "", hora=True)))
        return repair(rep, install=False), False
    state = repair(rep, install=True)
    born = import_auto_memory(rep, state)
    copied, present = import_dossier(rep, dossier_dir)
    born += copied
    now = common.now_iso()

    def _imports(o):
        imp = o.get("imports") if isinstance(o.get("imports"), dict) else {}
        if os.path.isdir(P["auto_memory"]):
            imp.setdefault("auto-memory", now)
        if present:
            imp.setdefault("dossier-claude-code", now)
        o["imports"] = imp
        o.setdefault("activated_at", now)
    common.update_json_locked(P["state"], _imports, script="verify.py")
    if os.path.exists(os.path.join(P["motor"], "refine.py")):
        rc, out, err = common.run_motor("refine.py", ["--full", "--trigger", "install"], timeout=30)
        rep.ok.append("refino completo: %s" % ("ok" if rc == 0 else "não rodou"))
    if os.path.exists(os.path.join(P["motor"], "snapshot.py")):
        rc, out, err = common.run_motor("snapshot.py", ["create", "--reason", "activation"], timeout=15)
        rep.ok.append("snapshot de ativação: %s" % ((out or "").strip() or "não rodou"))
    rep.created += born
    st = common.load_json(P["state"], {}, script="verify.py") or {}
    rep.ok.append("dossiê claude-code: %d arquivo(s) em memoria/conhecimento/claude-code/" % present)
    rep.ok.append("memória automática importada: %d item(ns)" % len(born))
    rep.ok.append("organismo ativado v%s em %s" % (st.get("version", "0.1.0"), common.fmt_ddmm(st.get("activated_at") or now, hora=True)))
    return st, True


# --------------------------------------------------------------------------- main

def main(argv):
    args = list(argv)
    quiet = "--quiet" in args
    as_json = "--json" in args
    do_repair = "--repair" in args
    do_install = "--install" in args
    dossier = None
    if "--dossier" in args:
        i = args.index("--dossier")
        if i + 1 < len(args):
            dossier = args[i + 1]
    rep = Report()
    cfg = common.load_config()
    if do_install:
        install(rep, dossier)
    elif do_repair:
        repair(rep)
    validate(rep, cfg)
    if do_repair or do_install:
        persist_warnings(rep)
    ms = rep.ms()
    if as_json:
        print(json.dumps({"ok": not rep.errors, "created": rep.created, "warnings": rep.warnings, "details": rep.details,
                          "errors": rep.errors, "notes": rep.ok, "ms": ms}, ensure_ascii=False, indent=2))
        return
    if quiet:
        for e in rep.errors:
            print("erro: %s" % e)
        return
    print("Gabriel · verificação em %d ms · %s" % (ms, "reparo" if (do_repair or do_install) else "só checagem"))
    for c in rep.created:
        print("criado: %s" % c)
    for n in rep.ok:
        print("ok: %s" % n)
    for d in rep.details:
        print("aviso: %s" % d)
    for e in rep.errors:
        print("erro: %s" % e)
    if not rep.created and not rep.details and not rep.errors:
        print("tudo no lugar: nada a criar, nenhum aviso.")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BaseException as e:
        common.log_error("verify.py", e)
        try:
            print("erro: verify.py falhou (%s) — detalhes em memoria/log/errors.jsonl" % type(e).__name__)
        except Exception:
            pass
    sys.exit(0)
